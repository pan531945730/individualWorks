<?php
class Pc_Ad_BottomBannerComponent extends User_Component_AbstractComponent {
    public function getView () {
        return "BottomBanner";
    }

    public static function use_boundable_javascripts() {
        $path = apf_classname_to_path(__CLASS__);
        return array_merge(
            parent::use_boundable_javascripts(),
            array($path . "BottomBanner.js")
        );
    }

    public static function use_boundable_styles() {
        $path = apf_classname_to_path(__CLASS__);
        return array_merge(
            parent::use_boundable_styles(),
            array($path . "BottomBanner.css")
        );
    }

    public static function use_component() {
        return array_merge(
            parent::use_component(),
            array(

            )
        );
    }

}
