/**
* == 底部banner，包括打开、关闭、自动开关 ==
* !如果要兼容ie6，组件需要作为body直接子元素
* 入參：@shouldAutoOpanAndClose: 是否要自动打开，然后自动关闭（1:是，其它：否）
*      &参见@defaults
* created by yaohuiwang@anjuke.com 16-07-21
*/
APF.Namespace.register("ajk.comp");
;(function($, ns) {
  ns.BottomBanner = function(op) {
    this.defaults = {
      visibleClass : "ad-view",
      autoCloseInterval : 3000 // 自动关闭的时间
    };
    this.ops = $.extend({},this.defaults,op);
    this.comp = $("#bottomBanner");
    this.nodes = {
      ad       : this.comp.find(".actbtmBanner"),
      btnClose : this.comp.find(".closeBtn"),
      btnOpen  : this.comp.find(".actBar"),
    };
    this.init();
  }

  ns.BottomBanner.prototype.init = function() {
    var self = this;
    self.bindEvent();
  }

  ns.BottomBanner.prototype.bindEvent = function() {
    var self = this;

    // 先展开,后自动关闭
    if ( +self.ops.shouldAutoOpanAndClose === 1 ) {
      self.openAndAutoClose();
    }

    // 绑定：打开
    self.nodes.btnOpen.on("click", function(e) {
      self.open();
    });

    // 绑定： 关闭
    self.nodes.btnClose.on("click", function(e) {
      self.close();
    });
  }

  ns.BottomBanner.prototype.open = function() {
    var self = this;
    self.nodes.ad.addClass( self.ops.visibleClass );
    self.nodes.btnOpen.removeClass( self.ops.visibleClass );
  }

  ns.BottomBanner.prototype.close = function() {
    var self = this;
    self.nodes.ad.removeClass( self.ops.visibleClass );
    self.nodes.btnOpen.addClass( self.ops.visibleClass );
  }

  ns.BottomBanner.prototype.openAndAutoClose = function() {
    var self = this;
    self.open();
    setTimeout(function() {
      self.close();
    }, self.ops.autoCloseInterval);
  }

})(jQuery, ajk.comp);


















