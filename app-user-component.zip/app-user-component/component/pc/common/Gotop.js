/* <?php $pages = User_Common_Util_PageHelper::getPureStaticUrl(); ?> */
APF.Namespace.register('ajk.pc');
(function(){
    var Footer;
    ajk.pc.Footer = Footer = function(op){
        var self = this;
        self._op = $.extend({},{
            wchatOpener:'<?= $pages."/js/chat/1.0.js" ?>',
            minWidth:1380,
            minTop:400,
            chatInterval:20000
        },op||{});

        self._init();
    };

    Footer.prototype._init = function() {
        var self = this;

        self.checkVisible();
        $(window).on('scroll resize',function(){
            self.checkVisible();
        });

        if( $('#open_chat').length > 0 ){
            var loopGetChat = function(){
                self._op.getChatMsg({},function(r){
                    self.upDateChatMsg(r)
                });
                setTimeout(loopGetChat,self._op.chatInterval);
            }
            loopGetChat();

            jQuery.getScript(self._op.wchatOpener,function(){
                $('#open_chat').click(function(e){
                    e.preventDefault();
                    window.chat.open();
                });
            });
        }

        $('#to_top').click(function(e){
            e.preventDefault();
            $(window).scrollTop(0);
        });

        
    };

    Footer.prototype.checkVisible = function(){
        var self = this,
            winWidth = $(window).width(),
            scrollTop = $(window).scrollTop();

        if( winWidth > self._op.minWidth ){
            $('.toTop>a').not('#to_top').show();
        }else{
            $('.toTop>a').not('#to_top').hide();
        }

        if( scrollTop > self._op.minTop ){
            $('#to_top').css({"visibility":"visible"});
        }else{
            $('#to_top').css({"visibility":"hidden"});
        }

    };

    Footer.prototype.upDateChatMsg = function(data){
        if (data.retcode == 0 && data.retdata && data.retdata.unreadMsgNum) {
            var count = data.retdata.unreadMsgNum;
            var dom = $('#open_chat .icon-point');
            if (count > 0) {
                count = (parseInt(count) > 99) ? '99+' : count;
                dom.html(count);
                dom.show();
            } else {
                dom.hide();
            }
        }
    }
})();