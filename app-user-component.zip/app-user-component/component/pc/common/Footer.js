$(function(){
    var hideLink = function(dom){
        var _this = dom;
        var timer = setTimeout(function(){
            _this.hide()
        },500);
        _this.data('hiddenTimer',timer);
    }

    $('#footer').on('click','[data-target]',function(e){
        e.preventDefault();
        var target = $(this).data('target');
        $('#'+target).toggle();
    });

    $('#footer').on('mouseout','[data-target]',function(){
        var target = $(this).data('target');
        hideLink($('#'+target))
    });

    $('#other_city,#community_link,#map_link,#house_link').hover(function(){
        var timer = $(this).data('hiddenTimer');
        clearTimeout(timer);
    },function(){
        hideLink($(this));
    });
});