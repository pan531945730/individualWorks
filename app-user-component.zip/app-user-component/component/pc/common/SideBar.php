<?php
/**
 * 二手房源的footer
 */
class Pc_Common_SideBarComponent extends User_Component_AbstractComponent {

    public function getView() {
        return "SideBar";
    }

    public static function use_boundable_styles()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "SideBar.css");
    }

    public static function use_boundable_javascripts()
    {
        $path = apf_classname_to_path(__CLASS__);
        $js = array_merge(
            parent::use_boundable_javascripts(),
            array($path . "SideBar.js"),
            array($path . "Logger.js")
        );
        return $js;
    }

}
