<?php

class Pc_Common_CitySelectorComponent extends User_Component_AbstractComponent
{

    private static $city_pinyin_name;

    public static function use_boundable_styles()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array_merge(
            parent::use_boundable_styles(),
            array($path . "CitySelector.css")
        );
    }

    public static function use_boundable_javascripts()
    {
        return parent::use_boundable_javascripts();
    }


    public static function use_component()
    {
        $components = array_merge(
            parent::use_component(),
            array(
                'Pc_Ui_DropDown',
            )
        );
        return $components;
    }

    public function getView()
    {
        $this->assign_data('base_domain', APF::get_instance()->get_config("base_domain"));
        $this->assign_data('more_city_url', User_Common_Util_Url::buildMoreCity());
        return "CitySelector";
    }

    /**
     * 获取城市切换tab配置
     * @return array
     */
    public function getCityList()
    {

        apf_require_class("User_Common_Const_MultiCity");
        $cities = APF::get_instance()->get_config("cities", "multicity");
        $city_lists = array(
            "华北东北" => array(
                User_Common_Const_MultiCity::CITY_ID_BEIJING => $cities[User_Common_Const_MultiCity::CITY_ID_BEIJING],
                User_Common_Const_MultiCity::CITY_ID_TIANJIN => $cities[User_Common_Const_MultiCity::CITY_ID_TIANJIN],
                User_Common_Const_MultiCity::CITY_ID_DALIAN => $cities[User_Common_Const_MultiCity::CITY_ID_DALIAN],
                User_Common_Const_MultiCity::CITY_ID_SHIJIAZHUANG => $cities[User_Common_Const_MultiCity::CITY_ID_SHIJIAZHUANG],
                User_Common_Const_MultiCity::CITY_ID_HAERBIN => $cities[User_Common_Const_MultiCity::CITY_ID_HAERBIN],
                User_Common_Const_MultiCity::CITY_ID_SHENYANG => $cities[User_Common_Const_MultiCity::CITY_ID_SHENYANG],
                User_Common_Const_MultiCity::CITY_ID_TAIYUAN => $cities[User_Common_Const_MultiCity::CITY_ID_TAIYUAN],
                User_Common_Const_MultiCity::CITY_ID_CHANGCHUN => $cities[User_Common_Const_MultiCity::CITY_ID_CHANGCHUN],
                User_Common_Const_MultiCity::CITY_ID_WEIHAI => $cities[User_Common_Const_MultiCity::CITY_ID_WEIHAI],
                User_Common_Const_MultiCity::CITY_ID_WEIFANG => $cities[User_Common_Const_MultiCity::CITY_ID_WEIFANG],
                User_Common_Const_MultiCity::CITY_ID_HUHEHAOTE => $cities[User_Common_Const_MultiCity::CITY_ID_HUHEHAOTE],
                User_Common_Const_MultiCity::CITY_ID_BAOTOU => $cities[User_Common_Const_MultiCity::CITY_ID_BAOTOU],
            ),
            "华东地区" => array(
                User_Common_Const_MultiCity::CITY_ID_SHANGHAI => $cities[User_Common_Const_MultiCity::CITY_ID_SHANGHAI],
                User_Common_Const_MultiCity::CITY_ID_HANGZHOU => $cities[User_Common_Const_MultiCity::CITY_ID_HANGZHOU],
                User_Common_Const_MultiCity::CITY_ID_SUZHOU => $cities[User_Common_Const_MultiCity::CITY_ID_SUZHOU],
                User_Common_Const_MultiCity::CITY_ID_NANJING => $cities[User_Common_Const_MultiCity::CITY_ID_NANJING],
                User_Common_Const_MultiCity::CITY_ID_WUXI => $cities[User_Common_Const_MultiCity::CITY_ID_WUXI],
                User_Common_Const_MultiCity::CITY_ID_JINAN => $cities[User_Common_Const_MultiCity::CITY_ID_JINAN],
                User_Common_Const_MultiCity::CITY_ID_QINGDAO => $cities[User_Common_Const_MultiCity::CITY_ID_QINGDAO],
                User_Common_Const_MultiCity::CITY_ID_KUNSHAN => $cities[User_Common_Const_MultiCity::CITY_ID_KUNSHAN],
                User_Common_Const_MultiCity::CITY_ID_NINGBO => $cities[User_Common_Const_MultiCity::CITY_ID_NINGBO],
                User_Common_Const_MultiCity::CITY_ID_NANCHANG => $cities[User_Common_Const_MultiCity::CITY_ID_NANCHANG],
                User_Common_Const_MultiCity::CITY_ID_FUZHOU => $cities[User_Common_Const_MultiCity::CITY_ID_FUZHOU],
                User_Common_Const_MultiCity::CITY_ID_HEFEI => $cities[User_Common_Const_MultiCity::CITY_ID_HEFEI],
                User_Common_Const_MultiCity::CITY_ID_XUZHOU => $cities[User_Common_Const_MultiCity::CITY_ID_XUZHOU],
                User_Common_Const_MultiCity::CITY_ID_ZIBO => $cities[User_Common_Const_MultiCity::CITY_ID_ZIBO],
            ),
            "华南地区" => array(
                User_Common_Const_MultiCity::CITY_ID_SHENZHEN => $cities[User_Common_Const_MultiCity::CITY_ID_SHENZHEN],
                User_Common_Const_MultiCity::CITY_ID_GUANGZHOU => $cities[User_Common_Const_MultiCity::CITY_ID_GUANGZHOU],
                User_Common_Const_MultiCity::CITY_ID_FOSHAN => $cities[User_Common_Const_MultiCity::CITY_ID_FOSHAN],
                User_Common_Const_MultiCity::CITY_ID_CHANGSHA => $cities[User_Common_Const_MultiCity::CITY_ID_CHANGSHA],
                User_Common_Const_MultiCity::CITY_ID_SANYA => $cities[User_Common_Const_MultiCity::CITY_ID_SANYA],
                User_Common_Const_MultiCity::CITY_ID_HUIZHOU => $cities[User_Common_Const_MultiCity::CITY_ID_HUIZHOU],
                User_Common_Const_MultiCity::CITY_ID_DONGGUAN => $cities[User_Common_Const_MultiCity::CITY_ID_DONGGUAN],
                User_Common_Const_MultiCity::CITY_ID_HAIKOU => $cities[User_Common_Const_MultiCity::CITY_ID_HAIKOU],
                User_Common_Const_MultiCity::CITY_ID_ZHUHAI => $cities[User_Common_Const_MultiCity::CITY_ID_ZHUHAI],
                User_Common_Const_MultiCity::CITY_ID_ZHONGSHAN => $cities[User_Common_Const_MultiCity::CITY_ID_ZHONGSHAN],
                User_Common_Const_MultiCity::CITY_ID_XIAMEN => $cities[User_Common_Const_MultiCity::CITY_ID_XIAMEN],
                User_Common_Const_MultiCity::CITY_ID_NANNING => $cities[User_Common_Const_MultiCity::CITY_ID_NANNING],
                User_Common_Const_MultiCity::CITY_ID_QUANZHOU => $cities[User_Common_Const_MultiCity::CITY_ID_QUANZHOU],
                User_Common_Const_MultiCity::CITY_ID_LIUZHOU => $cities[User_Common_Const_MultiCity::CITY_ID_LIUZHOU],
            ),
            "中 西 部" => array(
                User_Common_Const_MultiCity::CITY_ID_CHENGDU => $cities[User_Common_Const_MultiCity::CITY_ID_CHENGDU],
                User_Common_Const_MultiCity::CITY_ID_CHONGQING => $cities[User_Common_Const_MultiCity::CITY_ID_CHONGQING],
                User_Common_Const_MultiCity::CITY_ID_WUHAN => $cities[User_Common_Const_MultiCity::CITY_ID_WUHAN],
                User_Common_Const_MultiCity::CITY_ID_ZHENGZHOU => $cities[User_Common_Const_MultiCity::CITY_ID_ZHENGZHOU],
                User_Common_Const_MultiCity::CITY_ID_XIAN => $cities[User_Common_Const_MultiCity::CITY_ID_XIAN],
                User_Common_Const_MultiCity::CITY_ID_KUNMING => $cities[User_Common_Const_MultiCity::CITY_ID_KUNMING],
                User_Common_Const_MultiCity::CITY_ID_GUIYANG => $cities[User_Common_Const_MultiCity::CITY_ID_GUIYANG],
                User_Common_Const_MultiCity::CITY_ID_LANZHOU => $cities[User_Common_Const_MultiCity::CITY_ID_LANZHOU],
                User_Common_Const_MultiCity::CITY_ID_LUOYANG => $cities[User_Common_Const_MultiCity::CITY_ID_LUOYANG],
            )
        );

        //当时商业地产时过滤掉未开通城市
        $from = $this->get_page()->getActivedTab();
        if (in_array($from, array('zu_sp', 'shou_sp', 'shou', 'zu_xzl'))) {
            $this->getCityListForShop($city_lists, $cities);
        }

        return $city_lists;
    }

    /**
     * 获取tab下城市的链接和title
     * @param $cityid
     * @param $city_name
     * @return array
     */
    public function getCityLink($cityid, $title)
    {
        $from = $this->get_page()->getActivedTab();
        $city_set = APF::get_instance()->get_config("city_set", "multicity");
        $base_domain = APF::get_instance()->get_config("base_domain");
        if (preg_match('#xzl\.#', $base_domain)) {
            $link = User_Common_Util_Url::buildUri($base_domain, $city_set[$cityid]['xfdomain']) . '/';
        } elseif (preg_match('#sp\.#', $base_domain)) {
            $link = User_Common_Util_Url::buildUri($base_domain, $city_set[$cityid]['spdomain']) . '/';
        } else {
            $link = User_Common_Util_Url::buildUri($base_domain, $city_set[$cityid]['pinyin']) . '/';
        }
        switch ($from) {
            case 'sale' :
                $link .= 'sale/';
                $title .= '二手房';
                break;
            case 'market' :
                $link .= 'market/';
                $title .= '房价网';
                break;
            case 'bangdan':
                $link .= 'bangdan/';
                $title .= '房价排行榜';
                break;
            case 'community':
                $link .= 'community/';
                $title .= $city_set[$cityid]['cityname'];
                break;
            case 'zufangyuan':
            case 'ditie' :
                $link = User_Common_Util_Url_BaseUrl::buildZufangUrl($cityid);
                $title .= '租房网';
                break;
            case 'shou_sp':
                $link = User_Common_Util_Url::buildUri($base_domain, $city_set[$cityid]['spdomain'].'.sp');
                $link .= '/shou/';
                $title .= '商铺';
                break;
            case 'zu_sp':
                $link = User_Common_Util_Url::buildUri($base_domain, $city_set[$cityid]['spdomain'].'.sp');
                $link .= '/zu/';
                $title .= '商铺';
                break;
            case 'shou':
                $link = User_Common_Util_Url::buildUri($base_domain, $city_set[$cityid]['xzldomain'].'.xzl');
                $title .= '写字楼';
                $link .= '/shou/';
                break;
            case 'zu_xzl':
                $link = User_Common_Util_Url::buildUri($base_domain, $city_set[$cityid]['xzldomain'].'.xzl');
                $title .= '写字楼';
                $link .= '/zu/';
                break;
            case 'property_map':
                $title .= '地图找房';
                $link .= 'map/sale/';
                break;
            default:
                $title .= '房产网';;
        }
        return array('link' => $link, 'title' => $title);
    }

    public function getCitySelectorUrl()
    {
        $base_domain = APF::get_instance()->get_config("base_domain");
        return "http://www." . $base_domain . '/index/';
    }

    protected function getCityNameFromCityPinyin($city_pinyin)
    {
        if (!isset(self::$city_pinyin_name)) {
            $city_sites = APF::get_instance()->get_config("city_set", "multicity");
            self::$city_pinyin_name = array();
            foreach ($city_sites as $city_site) {
                self::$city_pinyin_name[$city_site['pinyin']] = $city_site['cityname'];
            }
        }
        return self::$city_pinyin_name[$city_pinyin];
    }

    protected function getCityName()
    {
        $uri = ($_SERVER['REQUEST_URI']);
        $result = explode("/", $uri);
        $city_name = $this->getCityNameFromCityPinyin($result[1]);
        if ($city_name == null) {
            $cities = APF::get_instance()->get_config("cities", "multicity");
            $city_id = APF::get_instance()->get_request()->getCityId();
            $city_name = $cities[$city_id];
        }
        return $city_name;
    }

    /**
     * 获得导航
     */
    private function getCityTabs()
    {
        $cityId = APF::get_instance()->get_request()->getCityId();
        return User_Common_Uri_Navigation::getCityTabs($cityId);
    }

    /**
     * 获得当前焦点的一级导航
     */
    public function geCurrentNavFirst($actived, $cityTabs)
    {
        foreach ($cityTabs as $k => $tab) {
            if ($k == $actived || in_array($actived, array_keys($tab['navSecond']))) {
                return $k;
            }
        }
        return false;
    }


    /**
     * 过滤城市，只返回商业地产开通城市
     * @param $cities
     * @return array
     */
    private function getCityListForShop(&$cities, $city_list)
    {
        /**
         * 共29城。
         * 华北东北:     北京、天津、长春、大连、哈尔滨、沈阳、石家庄、太原
         * 华东地区:     上海、杭州、合肥、济南、昆山、南昌、南京、青岛、苏州
         * 华南地区:     广州、深圳、长沙、东莞、佛山、厦门
         * 中 西 部:       成都、重庆、昆明、武汉、西安、郑州
         */
        $ca = array(
            '华北东北' => array("北京", "天津", "长春", "大连", "哈尔滨", "沈阳", "石家庄", "太原"),
            '华东地区' => array("上海", "杭州", "合肥", "济南", "昆山", "南昌", "南京", "青岛", "苏州", '无锡', '宁波'),
            '华南地区' => array("广州", "深圳", "长沙", "东莞", "佛山", "厦门", '海口', '海口', '惠州', '南宁', '三亚', '珠海', '泉州', '中山'),
            '中 西 部' => array("成都", "重庆", "昆明", "武汉", "西安", "郑州"),
        );
        foreach ($cities as $k => $cary) {
            foreach ($cary as $kv => $kc) {
                if (!in_array($kc, $ca[$k])) {
                    unset($cities[$k][$kv]);
                }
            }
        }
        $cities['华东地区'][User_Common_Const_MultiCity::CITY_ID_JIAXING] = $city_list[User_Common_Const_MultiCity::CITY_ID_JIAXING];
        $cities['华东地区'][User_Common_Const_MultiCity::CITY_ID_NANTONG] = $city_list[User_Common_Const_MultiCity::CITY_ID_NANTONG];
        $cities['华东地区'][User_Common_Const_MultiCity::CITY_ID_XUZHOU] = $city_list[User_Common_Const_MultiCity::CITY_ID_XUZHOU];
        $cities['华东地区'][User_Common_Const_MultiCity::CITY_ID_CHANGZHOU] = $city_list[User_Common_Const_MultiCity::CITY_ID_CHANGZHOU];
        $cities['华东地区'][User_Common_Const_MultiCity::CITY_ID_FUZHOU] = $city_list[User_Common_Const_MultiCity::CITY_ID_FUZHOU];
        return $cities;
    }

}
