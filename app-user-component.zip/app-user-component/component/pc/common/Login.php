<?php
class Pc_Common_LoginComponent extends User_Component_AbstractComponent {
    
    public function getView() {

        return "";
    }

    public static function use_boundable_styles()
    {
        return parent::use_boundable_styles();
    }

    public static function use_boundable_javascripts()
    {
        $path = apf_classname_to_path(__CLASS__);
        $js = array_merge(
            parent::use_boundable_javascripts(),
            array($path."Login.js")
        );
        return $js;
    }

    public static function use_component()
    {
        $components = array_merge(
            parent::use_component(),
            array(
                'Pc_Ui_DropDown',
            )
        );
        return $components;
    }

}
