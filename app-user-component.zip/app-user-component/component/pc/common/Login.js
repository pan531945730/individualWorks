APF.Namespace.register('ajk.UserLogin');
(function(){
    var UserLogin;


    var _tpl_general = ''
    +'<div class="userlogin userblock userblockfirst">'
    +    '<i class="icon icon-people"></i>'
    +    '<a class="link" href="<%= righturl.myanjuke %>" rel="nofollow" title="<%= common.usernamestr %>"><%= common.usernamestr %></a>'
    +    '<i class="triangle-down"></i>'
    +    '<ul>'
    +        '<li><a href="<%= righturl.links.my_favorite %>" rel="nofollow">我的收藏</a></li>'
    +        '<li><a href="<%= righturl.links.view_history %>" rel="nofollow">浏览历史</a></li>'
    +        '<li><a href="<%= righturl.links.subscription_management %>" rel="nofollow">订阅管理</a></li>'
    +        '<li><a href="<%= righturl.links.my_ask %>" rel="nofollow">我的问答</a></li>'
    +        '<li><a href="<%= lefturl.pmurl %>" rel="nofollow">我的消息<em><%= common.totalUnreadCount>99?"99+":common.totalUnreadCount %></em></a></li>'
    +        '<li><a href="<%= righturl.links.my_ugc %>" rel="nofollow">我的点评</a></li>'
    +        '<li class="hr"></li>'
    +        '<li><a target="_blank" href="<%= righturl.links.publish_sell || "#" %>?from=i_dhfa" rel="nofollow">我要发房</a></li>'
    +        '<li><a target="_blank" href="<%= common.my_house||"#" %>?from=i_dhmge" rel="nofollow">我的房源</a></li>'
    +        '<li class="hr"></li>'
    +        '<li><a href="<%= lefturl.logouturl %>" rel="nofollow">退出</a></li>'
    +    '</ul>'
    +'</div>';

    var _tpl_broker = ''
    +'<div class="userlogin userblock userblockfirst">'
    +    '<span>您好，<%= common.usernamestr %></span>'
    +    '<a class="link" href="<%= lefturl.logouturl %>" rel="nofollow"> [退出] </a>'
    +    '<a class="link usermsg" href="<%= lefturl.pmurl||"#" %>" rel="nofollow">消息 <i class="icon icon-point"><%= common.totalUnreadCount>99?"99+":common.totalUnreadCount %></i></a>'
    +'</div>'
    +'<div class="userblock">'
    +   '<a class="link" href="<%= righturl.myanjuke %>" rel="nofollow">中国网络经纪人</a>'
    +'</div>'
    + '<% if( common.developUrl ){ %>'
    +'<div class=" userblock">'
    +   '<a class="link" href="<%= common.developUrl %>" rel="nofollow">新房分销平台</a>' 
    +'</div>'
    + '<% } %>';

    var _tpl_developer = ''
    +'<div class="userlogin userblock userblockfirst">'
    +    '<span>您好，<%= common.usernamestr %></span>'
    +    '<a class="link" href="<%= lefturl.logouturl %>" rel="nofollow"> [退出] </a>'
    +'</div>'
    +'<div class="userblock ">'
    +    '<a class="link usermsg" href="<%= lefturl.pmurl||"#" %>" rel="nofollow">消息 <i class="icon icon-point"><%= common.totalUnreadCount>99?"99+":common.totalUnreadCount %></i></a>'
    +'</div>';

    //1: 网络门店或者用户 9:大业主 10: 新房分销平台用户 2:经济人 8:开发商(房易通/分销平台)
    var _templates = {
        '1':_tpl_general,
        '9':_tpl_general,
        '10':_tpl_general,
        '2':_tpl_broker,
        '8':_tpl_developer
    };

    ajk.UserLogin = UserLogin = ajk.inherit(ajk.Observer,function(op){
        var self = this;
        self._op = $.extend({},{userbox:'#userbox', templates:_templates },op||{});
        self._userDate = null;
        self._init();
    });

    UserLogin.prototype._init = function() {
        var self = this;
        self.userbox = $(self._op.userbox);
        if( APF.Utils.getCookie('aQQ_ajkauthinfos') ){
            self._op.getUserInfo({},function(r){
                self._userDate = r;
                self.updateUserInfo();
                self._bindEvent();
            });
        }
        else{
            self._bindEvent();
        }

    };

    UserLogin.prototype._bindEvent = function() {
        var self = this;
        if( !self.isLogin() ){
            new ajk.DropDown($('.brokerlogin>.link'),$('.brokerlogin>ul'));
        }
        new ajk.DropDown($('.userlogin>.link'),$('.userlogin>ul'));
    };

    UserLogin.prototype.updateUserInfo = function(){
        var self = this;
        if( !self.isLogin() ){
            return
        }
        var template = self.getUserTpl();
        self.userbox.html( template(self._userDate) );
    }

    UserLogin.prototype.isLogin = function(){
        return this._userDate && this._userDate.common.userid;
    }

    UserLogin.prototype.getUserTpl = function(){
        var self = this;
        var loginType = self._userDate.common.usertype+'';
        return _.template( self._op.templates[loginType] );
    }

})();