<?php

class Pc_Common_Search_SearchBarComponent extends User_Component_AbstractComponent
{

    public static function use_component()
    {
        return array_merge(
            parent::use_component(), array(
                'Pc_Ui_DataCache',
                'Pc_Ui_Autocomplete',
            )
        );
    }

    public static function use_boundable_javascripts()
    {
        return parent::use_boundable_javascripts();
    }

    public static function use_boundable_styles()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "SearchBar.css");
    }

    public function getView()
    {
        $searchBarTpl = $this->get_param("site");
        return $searchBarTpl."SearchBar";
    }

}
