$(function(){
    $('#navigation>li').hover(function(){
        $(this).addClass('hover');
    },function(){
        $(this).removeClass('hover');
    });

    // 下拉框箭头中间位置
    var arrows = $('.nav-triangle');
    arrows.each(function(i, v) {
        var _this = $(this);
        var parent = _this.parent().parent(), left = 0;
        parent && (left = (parent.width() - 14) / 2);
        _this.css('left',left);
    });

    var userBox = $('#user_box');
    userBox.hover(function(){
        userBox.addClass('hover');
    },function(){
        userBox.removeClass('hover');
    });
});