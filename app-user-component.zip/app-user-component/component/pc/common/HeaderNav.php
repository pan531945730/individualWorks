<?php
/**
 * 单个导航的header
 */
class Pc_Common_HeaderNavComponent extends User_Component_AbstractComponent {

    public function getView() {
        $city_id = APF::get_instance()->get_request()->getCityId();
        $actived = $this->apf->get_request()->get_attribute('active_tab');
        $cityTabs = User_Common_Uri_Navigation::getNewCityTabs($city_id);
        $currentNavFirst = $this->geCurrentNavFirst($actived, $cityTabs);
        $this->assign_data('currentNavFirst', $currentNavFirst);
        $this->assign_data('actived', $actived);
        $this->assign_data('cityTabs', $cityTabs);
        $this->assign_data('city_id', $city_id);
        return "HeaderNav";
    }

    /**
     * 获得当前焦点的一级导航
     */
    public function geCurrentNavFirst($actived,$cityTabs){
        foreach($cityTabs as $k => $tab){
            if($k==$actived || in_array($actived,array_keys($tab['navSecond']))){
                return $k;
            }
        }
        return false;
    }

    public static function getClassNameByTitle($title)
    {
        if ($title == '新房') {
            return 'xf';
        }else if ($title == '商业地产') {
            return 'sydc';
        }
        return '';
    }

    /*
     * 二级导航样式是否出现下划线
     */
    public static function isShowUnderline($title)
    {
        if ($title == '地图找房') {
            return true;
        } else if ($title == '商铺出租') {
            return true;
        }
        return false;
    }

    public function getCityUrl()
    {
        $city_set = APF::get_instance()->get_config("city_set", "multicity");
        $city_id = APF::get_instance()->get_request()->getCityId();
        $base_domain = APF::get_instance()->get_config('base_domain');
        return User_Common_Util_Url::buildUri($base_domain, $city_set[$city_id]['pinyin']);
    }

    public static function use_boundable_styles()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "HeaderNav.css");
    }

    public static function use_boundable_javascripts()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "HeaderNav.js");
    }

    public static function use_component()
    {
        $components = array_merge(
            parent::use_component(),
            array(
                'Pc_Common_CitySelector',
                'Pc_Common_Login',
            )
        );
        return $components;
    }

    protected function getUrl($name, $from = '')
    {
        $back_url = "http://" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"];
       // $base_domain = "http://" . APF::get_instance()->get_config('base_domain');
        $base_domain = "http://" . APF::get_instance()->get_config('anjuke_base_domain');
        //$my_domain = "http://my." . APF::get_instance()->get_config('base_domain');
        $user_domain = "http://user." . APF::get_instance()->get_config('anjuke_base_domain');
        $member_domain = "http://member." . strstr($base_domain, "anjuke.");

        //判断是否开通了新房业务
        $intCityID = APF::get_instance()->get_request()->getCityId();
        $navCityConfig = APF::get_instance()->get_config('city_nav', 'navigation');
        $isOpenFang = false;
        if (isset($navCityConfig[$intCityID]) && ($navCityConfig[$intCityID] == 1 || $navCityConfig[$intCityID] == 2)) {
            $isOpenFang = true;
        }

        switch ($name) {
            case 'login_url' :
                echo $user_domain . "/my/login?history=" . base64_encode($back_url);
                echo $from ? '&from=' . $from : '';
                break;
            case 'register_url' :
                echo $user_domain . "/register/";
                echo $from ? '?from=' . $from : '';
                break;
            case 'extlogin_qq' :
                echo $member_domain . "/extlogin/?sid=anjuke&url=" . base64_encode($back_url) . "&logintype=qq";
                echo $from ? '&from=' . $from : '';
                break;
            case 'extlogin_wb' :
                echo $member_domain . "/extlogin/?sid=anjuke&url=" . base64_encode($back_url) . "&logintype=weibo";
                echo $from ? '&from=' . $from : '';
                break;
            case 'my_anjuke' :
                if ($isOpenFang) {
                    $back_url = $user_domain . "/favorite/xinfang/";
                } else {
                    $back_url = $user_domain . "/favorite/fangyuan";
                }
                echo $user_domain . "/my/login?history=" . base64_encode($back_url);
                break;
            case 'my_favorite' :
                if ($isOpenFang) {
                    $back_url = $user_domain . "/favorite/xinfang/";
                } else {
                    $back_url = $user_domain . "/favorite/fangyuan";
                }
                echo $domain . "/my/login?history=" . base64_encode($back_url);
                break;
            case 'my_recommend' :
                if ($isOpenFang) {
                    $back_url = $user_domain . "/fang/loupan-recommend/";
                } else {
                    $back_url = $user_domain . "/prop/collection/";
                }
                echo $user_domain . "/my/login?history=" . base64_encode($back_url);
                break;
            case 'view_history' :
                if ($isOpenFang) {
                    $back_url = $user_domain . "/fang/loupan-viewed/";
                } else {
                    $back_url = $user_domain . "/prop/myviewed/";
                }
                echo $user_domain . "/my/login?history=" . base64_encode($back_url);
                break;
            case 'subscription_management' :
                $back_url = $user_domain . "/subscribe/manage/list/";
                echo $user_domain . "/my/login?history=" . base64_encode($back_url);
                break;
            case 'my_ask' :
                $back_url = $user_domain . "/member/ask/my/";
                echo $user_domain . "/my/login?history=" . base64_encode($back_url);
                break;
            case 'publish_sell' :
                $back_url = $user_domain . "/prop/publish/list/";
                echo $user_domain . "/my/login?history=" . base64_encode($back_url);
                break;
            case 'my_house' :
                $back_url = "http://i." . APF::get_instance()->get_config('base_domain');
                echo $user_domain . "/my/login?history=" . base64_encode($back_url);
                break;
            case 'prop_manage' :
                $back_url = User_Common_Util_Url::buildGpropManageUrl();
                echo $user_domain . "/my/login?history=" . base64_encode($back_url);
                break;
        }
    }

}
