/**
* 用于用户中心通用登录的组件，此组件内嵌一个iframe page
* 入參：@openSlter: 用于点击打开登录弹窗的选择器，传入空值或不传表示非弹窗登录
* 生成实例：ajk.loginIframeWrap
* 实例方法：
* @open: 打开弹窗，打开后发码。
* 文档: http://gitlab.corp.anjuke.com/_site/docs/blob/master/API/%E7%94%A8%E6%88%B7%E4%B8%AD%E5%BF%83/%E6%96%B0%E7%89%88%E7%94%A8%E6%88%B7%E4%B8%AD%E5%BF%83%E6%8E%A5%E5%8F%A3.md
* created by yaohuiwang@anjuke.com 16-08-01 & 陈国利
*/
;APF.Namespace.register("ajk")
;(function($, ns) {
  ns.IframeLogin = function(op) {
    this.defaults = {
      redirectTime : 1000 // 自动跳转时长（ms）
    };
    this.ops = $.extend({},this.defaults,op);
    this.comp = $("#IframeLoginWrap");
    this.nodes = {
      ifm                : $("#loginIfm"),
      IframeLoginBody    : $("#IframeLoginBody"),
      IframeLoginSuccess : $("#IframeLoginSuccess"),
      redirectBtn        : $("#redirectBtn"),
      IframeLoginWrap    : $("#IframeLoginWrap"),
      IframeLoginCloseBtn : $("#IframeLoginCloseBtn")
    };
    this.nodes.opener = $( this.ops.openSlter );
    this.init();
  }

  ns.IframeLogin.prototype.init = function() {
    var self = this;
    self.bindEvent();
    self.initOuterMsger();
    self.initTrack();
  }

  ns.IframeLogin.prototype.bindEvent = function() {
    var self = this;

    // 绑定： 点击关闭按钮关闭弹层
    self.nodes.IframeLoginCloseBtn.on("click", function(e) {
        e.preventDefault();
        self.close();
        return false;
    });

    // 点击打开按钮打开弹层，打开按钮的选择器从组件传入
    if ( self.nodes.opener.length ) {
      self.nodes.opener.on("click", function(e) {
          e.preventDefault();
          self.open();
          return false;
      });
    }
  }

  // 初始化外层messenger
  ns.IframeLogin.prototype.initOuterMsger = function() {
    var self = this;
    self.outerMsger = new Messenger("parent", "login");
    var ifm = self.nodes.ifm[0];
    if(ifm && ifm.contentWindow) {
        self.outerMsger.addTarget( ifm.contentWindow, "iframe" );
    }
    self.outerMsger.listen(function(msg) {
        self.handleReceive(msg);
    });
  }

  // 初始化发码
  ns.IframeLogin.prototype.initTrack = function() {
    var self = this;
    var trackAllocations = [{
        node : "#IframeLoginBody .qq",
        act : "click",
        code : "login_page_qq"
    }, {
        node : "#IframeLoginBody .weibo",
        act : "click",
        code : "login_page_weibo"
    }, {
        node : "#IframeLoginBody .weixin",
        act : "click",
        code : "login_page_weichat"
    }];
    $.each( trackAllocations, function(k, v) {
        $(v.node).on(v.act, function(e) {
            ajk.Logger.sendSoj({
                page: v.code,
                pageName : v.code,
                site : "anjuke-npv"
            })
        });
    } );
  }

  // 向内层发送消息（只能是{}）
  ns.IframeLogin.prototype.send = function(msg) {
    var self = this;
    self.outerMsger.send( JSON.stringify(msg) );
  }

  // 接收到内层传来的消息@msg（字符串）
  ns.IframeLogin.prototype.handleReceive = function(msg) {
    var self = this;
    var msgObj = JSON.parse(msg);
    var args;
    if ( msgObj.type === "act" || msgObj.type === undefined ) {
      self[msgObj.name] && self[msgObj.name].apply(self, msgObj.args);
    }
  }

  // 显示提交成功@b：true显示，false隐藏,@url:被定向到的页面
  ns.IframeLogin.prototype.toggleLoginSuccess = function(b, url) {
    var self = this;
    if (b) {
      self.nodes.IframeLoginBody.addClass("none");
      self.nodes.IframeLoginSuccess.removeClass("none");
      self.nodes.redirectBtn.attr("href", url);
      setTimeout(function() {
        location.href = url;
      }, self.ops.redirectTime);
    } else {
      self.nodes.IframeLoginBody.removeClass("none");
      self.nodes.IframeLoginSuccess.addClass("none");
    }
  }

  // 打开登录弹层
    ns.IframeLogin.prototype.open = function() {
        var self = this;
        if ( +self.ops.isInlayer !== 1 ) {
            return false;
        }
        self.nodes.IframeLoginWrap.removeClass("none");
        ajk.Logger.setSite("anjuke-npv");
        ajk.Logger.sendSoj({
          page : "track_login_phonetc",
          pageName : "track_login_phonetc"
        });
    }

    // 关闭登录弹层
    ns.IframeLogin.prototype.close = function() {
        var self = this;
        if ( +self.ops.isInlayer !== 1 ) {
            return false;
        }
        self.nodes.IframeLoginWrap.addClass("none");
    }

})(jQuery, ajk);
