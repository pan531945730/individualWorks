APF.Namespace.register('ajk.pc');;
;(function($) {

    var sideBar;
    ajk.pc.sideBar = sideBar = function(op) {
        this._op = $.extend({}, {
            sideBarBox: $('.sidebar'),
            toTop: $('.sidebar-top'),
            sidebarNav: $('.sidebar-mod a'),
            minWidth: 1280,
            minTop: 400
        }, op || {});

        this.init();
    };

    sideBar.prototype.init = function() {
        var self = this;

        self.checkVisible();
        $(window).on('scroll resize', function() {
            self.checkVisible();
        });

        self._op.toTop.on('click',function(e) {
            ajk.Logger.sendSoj({
                site: 'anjuke-npv',
                customparam: 'track_back_top_click'
            });
            $('html,body').animate({
                scrollTop: 0
            }, 100);
        });

        $('#sid_survey').on('click',function(){
            ajk.Logger.sendSoj({
                site: 'anjuke-npv',
                customparam: 'track_survey_click'
            });
        })

    };

    sideBar.prototype.checkVisible = function() {
        var self = this,
            winWidth = $(window).width(),
            scrollTop = $(window).scrollTop();

        //sidebar 通栏是否显示
        if (winWidth > self._op.minWidth) {
            self._op.sideBarBox.stop().animate({
                right: '0px'
            }, 100)
            self._op.toTop.removeClass('sd-top-sig');
        } else {
            self._op.sideBarBox.stop().animate({
                right: '-40px'
            }, 100)
            self._op.toTop.addClass('sd-top-sig');
        }

        if (scrollTop > self._op.minTop) {
            self._op.toTop.show();
        } else {
            self._op.toTop.hide();
        }

        self.slideNav();

    };

    sideBar.prototype.slideNav = function() {
        var self = this;
        self._op.sidebarNav.hover(
            function() {
                var hoverWidth = $(this).children('.sidebar-nav-hover').hasClass('sidebar-sao') ? '130px' : '90px';
                $(this).children('.sidebar-nav-hover').stop()
                    .animate({
                        width: hoverWidth
                    }, 100);
            },
            function() {
                $(this).children('.sidebar-nav-hover').stop()
                    .animate({
                        width: '0px'
                    }, 100)
            }
        )
    };

})(jQuery);