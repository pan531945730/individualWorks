$(function(){
	var navMain = $('#navMain'),
		menu = navMain.find('.cp-menu');
		menu.on('mouseenter mouseleave',function(){
			$(this).toggleClass('menu-hover');
		})
})