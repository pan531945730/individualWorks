<?php
/**
 * 二手房源的footer
 */
class Pc_Common_ChanpinHeadComponent extends User_Component_AbstractComponent {
    
    public function getView() {
        $this->assign_data('base_domain', $this->request->get_attribute('base_domain'));
        $this->assign_data('city_url', $this->request->get_attribute('city_url'));
        return "ChanpinHead";
    }

    public static function use_boundable_styles()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "ChanpinHead.css");
    }

    public static function use_boundable_javascripts()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "ChanpinHead.js");
    }
}