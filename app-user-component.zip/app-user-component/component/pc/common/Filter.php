<?php
class Pc_Common_FilterComponent extends User_Component_AbstractComponent {
    
    public function getView() {

        return "";
    }

    public static function use_boundable_styles()
    {

        $path = apf_classname_to_path(__CLASS__);
        return array($path . "Filter.css");         
    }

    public static function use_boundable_javascripts()
    {
        $path = apf_classname_to_path(__CLASS__);
        $js = array_merge(
            parent::use_boundable_javascripts(),
            array($path."Filter.js")
        );
        return $js;
    }

    public static function use_component()
    {
    }

}
