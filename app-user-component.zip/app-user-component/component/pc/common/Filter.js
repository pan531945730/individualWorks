APF.Namespace.register('ajk.Filter');
(function($){
    /**
     * 筛选的区间输入框
     * @param {jQueryObject} $form        区间输入框的表单
     * @param {jQueryObject} $firstInput  from的input
     * @param {jQueryObject} $secondInput to的input
     * @param {jQueryObject} $confirm     submit按钮
     */
    ajk.Filter.Range = function($form, $firstInput, $secondInput, $confirm){
        $('body').on('click',function(evt){
            var target = $(evt.srcElement || evt.target);
            if(!target.is($firstInput)&&!target.is($secondInput)){
                target.is($confirm)?
                checkRange() && $form.submit():
                $confirm.hide();
            }
        });

        $firstInput.add($secondInput).on({
            'focus.text' : function(){
                $confirm.show();
            },
            'input keyup': function(){
                $(this).val($(this).val().replace(/[^0-9]/g,''));
                resetWidth();
            }   
        });

        function resetWidth(){
            $firstInput.add($secondInput).each(function(){
                $(this).val().length>=3?
                $(this).css('width',$(this).val().length*8+'px'):
                $(this).css('width','24px');
            });
        }

        function checkRange(){
            var valFrom = parseInt($.trim($firstInput.val()), 10);
            var valTo   = parseInt($.trim($secondInput.val()), 10);
            $.trim($firstInput.val())!=''&&$.trim($secondInput.val())!=''&&valFrom>valTo&&function(){
                var temp = valFrom;
                $firstInput.val(valTo);
                $secondInput.val(temp);
                $firstInput.removeClass('focus');
                $secondInput.removeClass('focus');
            }();
            resetWidth();
            return true;            
        }
    }
})(jQuery);
