<?php
/**
 * 二手房源的footer
 */
class Pc_Common_FooterComponent extends User_Component_AbstractComponent {

    public function getView() {
        $allcity = APF::get_instance()->get_config("city_set", "multicity");
        // 临时关闭新开城市
        foreach ($allcity as $key=>$city_info) {
            if ($key > User_Common_Const_MultiCity::CITY_ID_JIANGMEN) {
                unset($allcity[$key]);
            }
        }
        /* 对城市按城市名字数，ID进行排序 */
        $seo_city_set = $len_array = $city_array = array();
        foreach ($allcity as $key => $value) {
            if ($value['open'] & $seo_city_set['cityid'] != $key) {
                if (!in_array(strlen($value['cityname']), $len_array)) {
                    $len_array[] = strlen($value['cityname']);
                }
                $city_array[strlen($value['cityname'])][$value['cityid']] = $value;
            }
        }
        $base_domain = APF::get_instance()->get_config("base_domain");
        //$len_array = array(12,9,6);
        sort($len_array); //按字数,ID进行排序
        $hot_city_set = array();
        foreach ($len_array as $len) {
            ksort($city_array[$len]);
            foreach ($city_array[$len] as $city_value) {
                $seo_city_set[] = array('url' => User_Common_Util_Url::buildUri($base_domain, $city_value['pinyin']),
                    'name' => $city_value['cityname']);
                if($this->request->get_attribute('from_shangpu_view') and $city_value['cityid'] <= User_Common_Const_MultiCity::CITY_ID_CHONGQING){
                    $hot_city_set[] = array('url' => User_Common_Util_Url_Ershou_Sale::buildErshouPropListUrl($city_value['cityid']),
                                        'name' => $city_value['cityname']);
                }
            }
        }

        $this->assign_data("hot_city_set", $hot_city_set);
        $this->assign_data("seo_city_set", $seo_city_set);
        $this->assign_data("is_show_seo_recommend", $this->get_param('is_show_seo_recommend'));
        $this->assign_data("seo_recommend_data", $this->get_param('seo_recommend_data'));

        $internal_links = $this->get_param('new_seo_footer_recommend_data');
        if (!empty($internal_links)) {
            $this->assign_data("new_seo_footer_recommend_data", $internal_links);
        }

        //右侧工具是否显示
        $this->assign_data("is_show_rightbar", $this->request->get_attribute('is_show_rightbar'));

        //hide weiliao
        $hide_wei = ($this->request->get_attribute("hide_wei")) ? true : false;
        $this->assign_data("hide_wei", $hide_wei);
        return "Footer";
    }

    public static function use_component()
    {
        $components = array_merge(
            parent::use_component()
        );
        return $components;
    }


    public static function use_boundable_styles()
    {
        $path = apf_classname_to_path(__CLASS__);

        return array_merge(parent::use_boundable_styles(),array($path . "Footer.css"));
    }

    public static function use_boundable_javascripts()
    {
        $path = apf_classname_to_path(__CLASS__);
        $js = array_merge(
            parent::use_boundable_javascripts(),
            array($path . "Footer.js")
        );
        return $js;
    }

    // Pc_Common_Gotop

    public function getCurrentCityUriPrefix()
    {
        return $this->getCityLink($this->request->getCityId());
    }

    public function getCityLink($cityid)
    {
        $city_set = APF::get_instance()->get_config("city_set", "multicity");
        $base_domain = APF::get_instance()->get_config("base_domain");
        return User_Util_Url::build_uri($base_domain, $city_set[$cityid]['pinyin']);
    }

    public function buildSeoCommunityBooks()
    {
        $base_domain = APF::get_instance()->get_config("anjuke_base_domain");
        $city_set = APF::get_instance()->get_request()->load_city_set();
        return "http://www." . $base_domain . '/' . $city_set['pinyin'] . '/cm/';
    }

    public function buildZfSeoCommunityBooks()
    {
        $base_domain = APF::get_instance()->get_config("anjuke_base_domain");
        $city_set = APF::get_instance()->get_request()->load_city_set();
        return "http://www." . $base_domain . '/' . $city_set['pinyin'] . '/cm-zu/';
    }
    public function buildmSeoCommunityBooks()
    {
        $base_domain = APF::get_instance()->get_config("anjuke_base_domain");
        $city_set = $this->request->load_city_set();
        return "http://m.$base_domain/".$city_set['twdomain']."/xiaoqu/";
    }


    public function buildmSeoMapBooks($param)
    {
        $city_set = $this->request->load_city_set();
        $base_domain = APF::get_instance()->get_config("anjuke_base_domain");
        $path = "http://m.$base_domain/".$city_set['twdomain'].'/sitemap/';
        $path = ($param=='xinfang')?"http://m.$base_domain/".$city_set['twdomain']."/{$param}/sitemap/":$path;
        return $path;
    }

    public function buildSeoMapBooks($param)
    {
         $city_set = $this->request->load_city_set();
         $base_domain = APF::get_instance()->get_config("anjuke_base_domain");
         $city_set = $this->request->load_city_set();
         $path = 'http://'.$city_set['pinyin'].".$base_domain/sitemap/";
         $path = ($param=='xinfang')?"http://".$city_set['xfdomain'].".fang.$base_domain/fangsitemap/":$path;
         return $path;
    }
    public function buildSeoHouseBooks($param)
    {
         $city_set = $this->request->load_city_set();
         $base_domain = APF::get_instance()->get_config("anjuke_base_domain");

         $path = 'http://';
         switch($param)
         {
             case'ershou': //二手房
             {
                $path = $path.$city_set['pinyin'].".".$base_domain.'/fang/';
                break;
             }
             case'xinfang': //新房
             {
                 $path = $path.$city_set['xfdomain'].'.fang.'.$base_domain.'/fang/';
                 break;
             }
             case 'zufang'://租房
             {
                 $path = $path.$city_set['zfdomain'].'.zu.'.$base_domain.'/fang/';
                 break;
             }
             case 'xzl_zu'://写字楼出租
             {
                 $path = $path.$city_set['xzldomain'].'.xzl.'.$base_domain.'/fang_zu/';
                 break;
             }
             case 'xzl_shou'://写字楼出售
             {
                 $path = $path.$city_set['xzldomain'].'.xzl.'.$base_domain.'/fang_shou/';
                 break ;
             }

             case 'sp_zu'://商铺出租
             {
                 $path = $path.$city_set['spdomain'].'.sp.'.$base_domain.'/fang_zu/';
                 break;
             }
             case'sp_shou'://商铺出售
             {
                 $path = $path.$city_set['spdomain'].'.sp.'.$base_domain.'/fang_shou/';
                 break;
             }
             case 'm_ershou'://二手房手机版
             {
                 $path = $path.'m.'.$base_domain.'/'.$city_set['twdomain'].'/'.'propsitemap/esf/';
                 break;
             }
             case 'm_zufang'://租房手机版
             {
                 $path = $path.'m.'.$base_domain.'/'.$city_set['twdomain'].'/'.'propsitemap/zf/';
                 break;
             }
             case 'xinfang_loupan'://新房楼盘大全
             {
                 $path = $path.$city_set['pinyin'] . '/fang.anjuke.com/fangsitemap/A/';
                 break;
             }

             default:$path="";
         }


        return $path;

    }

    /**
     * @param int   $cityid 城市ID
     * @param string $type  类型
     * @return boolean
     */
    public function checkSeoCity($cityid,$type)
    {

        $config =  APF::get_instance()->get_config($type,'/multicity/foot_nav');
        if(in_array($cityid,$config))
        {
            return TRUE;
        }
        return FALSE;

    }

    //除杭州和天津，显示产品推广
    public function isShowChanpin()
    {
        $no_shown_city = array(
            User_Common_Const_MultiCity::CITY_ID_CHANGSHA,
            User_Common_Const_MultiCity::CITY_ID_SHENYANG,
        );
        $url = User_Common_Util_Url_Seo_Aboutus::buildSuffixUrl('home_foot_tgy');
        $city_id = $this->request->getCityId();

        if(!in_array($city_id,$no_shown_city)){
            return "<li><a rel='nofollow' target='_blank' href='{$url}'>产品推广</a></li>";
        }

        return false;
    }
}
