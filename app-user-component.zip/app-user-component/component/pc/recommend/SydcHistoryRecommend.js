;
function HistoryRecommend(op,param){
    $.ajax({
         url: op.url,
         type: 'GET',
         dataType: 'json',
         data: {
             city_id     : op.city_id,
             pro_id      : op.pro_id,
             trade_type  : op.trade_type,
             page        : op.page,
             pagesize    : op.pagesize,
             from        : op.from,
             showsoj     : op.showsoj,
             showprofile : op.showprofile,
             r           : op.r,
             pagename    : op.pagename
         }
    })
    .done(function(data) {
         if(data.status!="ok" || $(data.data).length <= 0){
              $('#historyRecom-content').hide();
              return false;
         }
         var tpl = _.template( $('#historyRecom-tpl').html() );
         var html = tpl(data.data);
         $('#historyRecom-content').show();
         $('#historyRecom-content').html(html);

        //加载点击滚动事件
        $('#historyRecom-content  ul').slick({
            slidesToShow: 5,
            slidesToScroll: 5,
            autoplay: false,
            autoplaySpeed: 2000,
            accessibility:false,
            draggable:false,
            arrows:true,
            vertical:false
        });

        // soj发曝光
        var list = data.data;
        var cp = $.extend(true,{}, param) , _proids = [];
        _.each(list,function(item){
            var _type = 1;
            var _str = item.id + '|' + item.broker_id + '|' + item.prop_id + '|' + item.is_hp;
            _proids.push(_str);
        });
        cp.proids = _proids.join(',');
        ajk.Logger.sendSoj({
            page: op.pagename,
            pageName: op.pagename,
            site:'anjuke-npv',
            customparam: JSON.stringify(cp)
        });

    });
}