;
function History(op){
    $.ajax({
         url: op.url,
         type: 'GET',
         dataType: 'json',
         data: {
             city_id      : op.city_id,
             pro_id      : op.pro_id,
             trade_type  : op.trade_type,
             page        : op.page,
             pagesize    : op.pagesize,
             from        : op.from,
             showsoj     : op.showsoj,
             showprofile : op.showprofile,
             r           : op.r,
             pagename    : op.pagename
         }
    })
    .done(function(data) {
         if(data.status!="ok"){
              return;
         }
         var tpl = _.template( $('#history-tpl').html() );
         var html = tpl(data.data);
         $('#history-content').show();
         $('#history-content').html(html);

        //加载上下页点击滚动事件
        $('#history-content ul').slick({
            slidesToShow: 5,
            slidesToScroll: 5,
            autoplay: false,
            autoplaySpeed: 2000,
            accessibility:false,
            draggable:false,
            arrows:true
        });
         //发送soj
         // ajk.Logger.sendSoj({
         //     page: op.pagename,
         //     pageName: op.pagename,
         //     site:'anjuke-npv',
         //     customparam: JSON.stringify(data.sojData)
         // });

    });
}