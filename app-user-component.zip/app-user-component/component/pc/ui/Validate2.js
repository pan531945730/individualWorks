;(function(){
    var Validate;
    APF.Namespace.register('ajk.Validate');
    ajk.Validate = Validate = ajk.inherit(ajk.Observer,function(form,options){
        var self = this;
        self._form = form;
        self._checkList = [];
        self._op = $.extend({}, Validate._config_, options||{});
        self._init();
    });

    Validate._config_ = {
        rules:[],
        eventNameSpace:'validate',
        checkEventType:'blur',
        selectEventType:'change',
        checkboxEventType:'click',
        ignoreList:[],
        singleHandle:function(result){},
        submitHandle:function(result,firstError){
            if(result){
                this._form.off('submit.validate').submit()
            }else{
                var dom = firstError.dom;
                if( !dom.focus ){
                    dom = $('[data-group="'+dom+'"]');
                }
                dom.focus();
            }
        }
    };

    /**
     * [rulesCheckbox 验证规则与方法对应 针对checkbox和radio]
     * @type {Object}
     */
    Validate._rulesCheckbox_ = {
        required:function(filds){
            return filds.filter(':checked').length > 0;
        },
        maxNumber:function(filds,max){
            return filds.filter(':checked').length <= max;
        }
    }
    Validate._rulesText_ = {
        required:function(value){
            var val = value;
            return val.length > 0;
        },
        integer:function(value){
            var val = value;
            return /^\-?[\d]*$/.test(val)
        },
        equal:function(value,eqVal){
            var val = value;
            return val === eqVal
        },
        not:function(value,notVal){
            var val = value;
            if(value == ''){
                return val !== notVal;
            }else{
                return val != notVal;
            }
        },
        maxLength:function(value,maxlength){
            var val = value;
            return val.length <= maxlength;
        },
        minLength:function(value,minLength){
            var val = value;
            return val.length >= minLength;
        },
        max:function(value,_max){
            var val = value-0;
            return val - _max <= 0
        },
        min:function(value,min){
            return value-0-min >= 0
        },
        mobile:function(value){
            var val = value;
            return /^1[3|4|5|7|8]\d{9}$/.test(val);
        },
        email:function(value){
            var val = value;
            return /^[a-z0-9_-]+@[a-z0-9_-]+\.\w{2,3}$/i.test(val);
        },
        ucode: function (value) {
            var val = value;
            return /^[U]{0,1}\d{12}$/.test(val);
        },
        number: function (value) {
            var val = value;
            return !isNaN(val);
        },
        depend:function(value,fieldName,output){
            var dependField = $('[name="'+fieldName+'"]');
            this.check(dependField, false, function(result){
                output( result.status == 'success'?true:false );
            });
        },
        numOrLetter:function(value){
            var val = value;
            return val=='' || /^[a-z0-9]+$/i.test(val);
        },
        decimal:function(value, arg){
            var val = value;
            var arr = value.split('.');
            if( arr[1] ){
                return arr[1].length <= arg;
            }else{
                return true;
            }
        },
        repeatNumber:function(value, arg){
            var reg = new RegExp('[0-9]{' + arg + ',}');
            var test = reg.test(value);
            return !test;
        },
        invalidChar:function(value, arg){
            var reg = new RegExp('[@#$%￥…]{' + arg + ',}');
            var test = reg.test(value);
            return !test;
        }
    };

    Validate.prototype._init = function() {
        var self = this;
        self._form.on('submit.validate',function(e){
            e.preventDefault();
            self.checkAll(self._op.submitHandle);
        });
    };

    Validate.prototype._getCheckEvent = function(dom){
        var self = this;
        var type = dom.filter('select').length > 0 ? 'select' :dom.attr('type');
        var _event = '';

        switch(type){
            case 'checkbox':
                _event += self._op.checkboxEventType
            break;
            case 'radio':
                _event += self._op.checkboxEventType
            break;
            case 'select':
                _event += self._op.selectEventType
            break;
            default:
                _event += self._op.checkEventType
        }

        return _event+'.'+self._op.eventNameSpace;
        self._checkEvent = self._op.checkEventType
    }

    Validate.prototype._ruleWrap = function(config,ruleBase){
        var _base = ruleBase || Validate._rulesText_;
        var fn = _base[config.rule];
        var arg = config.arg;

        if( config.rule=="depend" ){
            return fn;
        }

        return function(value,arg,callback){
            var result = fn(value,arg)
            callback(result);
        }
    }

    Validate.prototype._check = function(dom,rules){
        var self = this;
        var dtd = $.Deferred();
        var connect = new ajk.Connect();
        var name = (typeof dom == 'string')? dom:dom.attr('name');
        var value = (typeof dom == 'string')? '': $.trim(dom.val());
        if( self._op.getValue && self._op.getValue[name] ){
            value = self._op.getValue[name]();
        }
        var hasRequired = !!_.find(rules,function(item){ return item.rule == 'required' });

        if( !(typeof dom == 'string') && !hasRequired ){
            // 如果字段非必填，且字段为空，则直接验证通过
            connect.next(function(args,next){
                if( value.length <= 0 ){
                    dtd.resolve({
                        status:'success',
                        dom:dom,
                        value:value
                    });
                }else{
                    next();
                }
            });
        }

        for( var i = 0; i < rules.length; i ++ ){
            (function(){
                var thisRuleConfig = rules[i];
                var _onestep = function(_dom){
                    var _type = (typeof _dom == 'string')?dom:_dom.attr('type');
                    var _isCheckbox = ( _type == 'radio' || _type == 'checkbox' );
                    var _ruleBase = _isCheckbox? Validate._rulesCheckbox_ : Validate._rulesText_;
                    var _rule = $.isFunction( thisRuleConfig.rule ) ? thisRuleConfig.rule: self._ruleWrap(thisRuleConfig,_ruleBase);
                    var _fistArg = _isCheckbox? _dom:value;

                    return function(callback){
                        _rule.call(self,_fistArg,thisRuleConfig.arg,callback);
                    }
                }
                connect.next(function(args,next){
                    _onestep(dom)(function(result){
                        if( result ){
                            next();
                        }else{
                            var arg = _.toArray(arguments);
                            arg[0] = value;
                            dtd.reject({
                                status:'error',
                                dom:dom,
                                value:value,
                                msg: $.isFunction( thisRuleConfig.msg )? thisRuleConfig.msg.apply(dom,arg) : thisRuleConfig.msg
                            });
                        }
                    });
                });
            })()
        }
        connect.allDone(function(){
            dtd.resolve({
                status:'success',
                dom:dom,
                value:value
            });
        });
        connect.start(value);
        return dtd.promise();
    }

    Validate.prototype._getRules = function(target){
        var self = this;
        var key = (typeof target == 'string')? target : target.attr('name');
        return _.find(self._checkList,function(item){
            return item.key == key;
        });
    }

    /**
     * [check 监测单个字段]
     * @param  {[jQueryObj]}   dom      [需要验证字段的jQuery对象]
     * @param  {Function} callback      [验证结果回调]
     * @return {[type]}                 [验证 promise 对象 ]
     */
    Validate.prototype.check = function(dom, forceCheck, callback){
        var self = this;
        var _isGroup = (typeof dom == 'string');
        var _rule = self._getRules(dom);
        var _valueNow = (_isGroup)? dom : dom.val();

        var checkFlow = (function(){
            var lastCheckVal = _isGroup? undefined : dom.data('checkflow');
            var _type = _isGroup? 'group' : dom.attr('type');
            var _isCheckbox = ( _type == 'radio' || _type == 'checkbox' );

            if( !forceCheck && !_isCheckbox && lastCheckVal && lastCheckVal.value == _valueNow ){
                return lastCheckVal.dtd;
            }else{
                self._beginCheck(_rule);
                var dtd = self._check(_rule.dom,_rule.rules);
                if( !_isGroup ){
                    dom.data('checkflow',{
                        value:_valueNow,
                        dtd:dtd
                    });
                }
                return dtd;
            }
        })()
        if( callback ){
            checkFlow.always(callback);
        }
        return checkFlow;
    }

    Validate.prototype.checkAll = function(callback){
        var self = this;
        var _list = self._ignore(self._checkList);
        return self._buildCheckFlow(_list)(callback);
    }

    Validate.prototype.checkAsList = function(list,callback){
        var self = this;
        var _list = _.filter(self._checkList,function(item){
            return $.inArray(item.key,list) > -1;
        });
        return self._buildCheckFlow(_list)(callback);
    }

    // 重置验证状态
    Validate.prototype.resetCheckResult = function(key){
        var self = this;
        var dom = $('[name="'+key+'"]');

        if( dom.length >= 1 ){
            dom.removeData('checkflow');
        }

        self._op.singleHandle.apply(self,[{
            status: 'reset',
            name: key,
            dom: dom.length >= 1 ? dom : key
        }]);
        self.trigger('reset',[key,dom]);
    }

    Validate.prototype.addIgnoreList = function(arr, force){
        var self = this;
        if(force) self._op.ignoreList = arr;
        else self._op.ignoreList = _.union(self._op.ignoreList, arr);

        _.each(arr,function(item){
            self.resetCheckResult(item);
        });
    }

    Validate.prototype.removeIgnoreList = function(arr){
        var self = this;
        if(arr) self._op.ignoreList = _.difference(self._op.ignoreList, arr);
        else self._op.ignoreList = [];
    }

    Validate.prototype._ignore = function(checklList){
        var self = this;
        var　_list = _.filter(checklList, function(item){
            return _.indexOf(self._op.ignoreList, item.key) == -1;
        });
        return _list;
    }

    Validate.prototype._buildCheckFlow = function(list){
        var self = this;
        var _list = !list ? self._checkList: list;
        return function(callback){
            var checkFlowList = [];
            for( var i = 0; i < _list.length; i ++ ){
                checkFlowList.push( self.check(_list[i].dom, false, function(r){ self._checkResult(r); }) );
            }
            var result = true;
            var f = $.when.apply($,checkFlowList);
            return f.fail(function(){
                result = false;
            }).always(function(firstError){
                callback.apply(self,[result,firstError]);
            });
        }
    }

    Validate.prototype._checkResult = function(r){
        var self = this;
        self._op.singleHandle.apply(self,[r]);
        self.trigger(r.status,arguments);
    }
    Validate.prototype._beginCheck = function(r){
        var self = this;
        self._op.singleHandle.apply(self,[{
            status:'check',
            dom:r.dom,
            data:r
        }]);
        self.trigger('check',arguments);
    }


    Validate.prototype.initRules = function(){
        var self = this;
        var allNeedCheckDoms = self._form.find('input,textarea,select');
        self._checkList = [];
        for( var i = 0; i < allNeedCheckDoms.length; i ++ ){
            var _this = allNeedCheckDoms.eq(i);
            var name = _this.attr('name');
            var groupName = _this.data('group');
            if( _this.data('rules') || self._op.rules[name] ){
                var fieldRules = self._buildRules(_this);
                if( groupName ){
                    var groupRules = self._buildRules(groupName);
                }
                var eventType = self._getCheckEvent(_this);
                fieldRules.dom.off(eventType).on(eventType,function(){
                    var $this = $(this);
                    var _name = $this.attr('name');
                    if( $.inArray(_name,self._op.ignoreList) < 0 ){
                        self.check($this, false, function(r){ self._checkResult(r); });
                    }
                    var group = $this.data('group');
                    if( group && $.inArray(group,self._op.ignoreList) < 0  ){
                        self.check(group,false,function(r){
                            self._checkResult(r);
                        });
                    }
                });

            }
        };
    }

    var mergeDiffrenceRules = function(ruleOld,rulesNew){
        var rulesExisted = _.pluck(ruleOld, 'rule');
        var filtered = _.filter( rulesNew , function(item){
            return $.inArray(item.rule,rulesExisted) < 0;
        });
        return ruleOld.concat(filtered);
    }

    Validate.prototype._buildRules = function(dom){
        var self = this;
        var isGroup = (typeof dom == 'string');
        var key = isGroup?dom:dom.attr('name');
        var fieldRules = _.find(self._checkList,function(item){
            return item.key == key;
        });
        if( !fieldRules ){
            if( !isGroup && (dom.attr('type') == 'checkbox' || dom.attr('type') == 'radio') ){
                dom = $('[name="'+key+'"]');
            }
            fieldRules = {
                key:key,
                dom:isGroup? key:dom,
                rules:[]
            }
            self._checkList.push(fieldRules);
        }

        if( !isGroup ){
            var ruleFromAttr = self._getRulesByData(dom);
            fieldRules.rules = mergeDiffrenceRules(fieldRules.rules,ruleFromAttr);
        }

        var ruleFromOption = self._getRulesByOption(key);
        fieldRules.rules = mergeDiffrenceRules(fieldRules.rules,ruleFromOption);

        return fieldRules
    }

    Validate.prototype._getRulesByData = function(dom){
        var rulesConfig = dom.data('rules');
        var msgsConfig = dom.data('msgs');
        var formatRules = [];
        for( var i in rulesConfig ){
            formatRules.push({
                rule:i,
                arg:rulesConfig[i],
                msg:msgsConfig[i]
            });
        }
        return formatRules;
    }

    Validate.prototype._getRulesByOption = function(key){
        var self = this;
        return self._op.rules[key]||[];
    }



})();
