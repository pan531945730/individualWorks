/**
 * [inherit 方法：使得子构造函数继承父构造函数]
 * @param  {[fn]} [构造函数，最后一个参数为子构造函数，之前均为父构造函数，支持多父类继承]
 * @return {[fn]}             [经过继承之后的新构造函数]
 */
APF.Namespace.register('ajk.inherit');
ajk.inherit = function(){
    var splice = Array.prototype.splice,
        args = arguments;
    var childClass = args[ args.length -1 ];
    splice.apply(args,[-1,1]);

    var newConstructor = function(){
        for( var i=0; i<args.length; i++ ){
            if( args[i] ){
                args[i].apply(this,arguments);
            }
        }
        childClass.apply(this,arguments);
    }
    for( var i=0; i<args.length; i++ ){
        if( args[i] ){
            $.extend( newConstructor.prototype, args[i].prototype);
        }
    }

    $.extend( newConstructor.prototype, childClass.prototype );
    return newConstructor
}