;APF.Namespace.register('ajk.Validate');
;(function($){
    'use strict';
    /**
     * [ValidateSingle 单个验证构造函数]
     * @param {[Zobj]} fi    [需要验证的表单域]
     * @param {[array]} rules [验证规则列表]
     *                        单个验证规则是一个对象
     *                        {
     *                          rule: 如果是字符串则从现有规则中匹配，也可以是自定义方法必须返回true/false
     *                              自定义方法参数:
     *                                  dom:验证字段
     *                                  args:参数
     *                                  msg: 报错文案
     *                                  id: 验证规则在验证列表中得key                                  
     *                          msg: 报错信息，字符串
     *                          args: 可选，验证规则需要的参数，类型由验证规则决定
     *                        }
     * @param {[object]} op    [验证触发事件，可选，默认事件 text/textarea:blur,checkbox/radio:click,select:change ]
     */
    var ValidateSingle = ajk.inherit(ajk.Observer,function(fi,rules,op){
        var self = this;
        self.dom = fi;
        self.rules = rules;
        self._op = $.extend({},ValidateSingle._default,op||{});
        self._errorId = null;
        self._isRemoteing = false;
        self._rulesBase;
        self._init();
    });

    ValidateSingle.prototype._init = function(){
        var self = this,
            _type = self.dom.attr('type');
        self._rulesBase = ( _type == 'radio' || _type == 'checkbox' )? Validate.rulesCheckbox : Validate.rulesText;
        if( self.dom.attr('type') == 'checkbox' || self.dom.attr('type') == 'radio' ){
            self.dom.on(self._op.eventCheckbox,function(){
                self.check();
            });
            return;
        }
        if( self.dom.filter('select').length > 0 ){
            self.dom.on(self._op.eventSelect,function(){
                self.check();
            });
        }else{
            self.dom.on(self._op.eventText,function(){
                self.check();
            });
        }
    }
    /**
     * [check 验证方法]
     * @return {[boolean]} [验证成功或失败]
     */
    ValidateSingle.prototype.check = function(){
        var self = this;
        var result = true;
        var findRules = function(rule){
            if(typeof rule == 'string'){
                rule =  self._rulesBase[rule];
            }
            return rule;
        }
        for( var i=0,checklist = self.rules; i< checklist.length; i++ ){
            var fn = findRules( checklist[i].rule );
            var r = fn.apply(self,[self.dom, checklist[i].args, checklist[i].msg, i] );
            if(!r){
                if( !(checklist[i].rule == 'remote' && (!self.dom.data('remote') || self.dom.data('remote') == '')) ){
                    self._errorId = i;
                    self.trigger('error',['error',self,checklist[i].msg||'']);
                }
                result = false;
                break;
            }
        }
        if(result){
            self._errorId = null;
            self.trigger('success',['success',self]);
        }
        return result;
    }

    /**
     * [status 获取当前状态]
     * @return {[object]} [状态信息对象，status属性为 'success'或'error',如果错误状态msg属性返回当前错误信息]
     */
    ValidateSingle.prototype.status = function(){
        var self = this,
            r;
        if( self._isRemoteing ){
            r = { status:'remote' }
            return r
        }
        if( self._errorId == null ){
            r = { status:'success' }
        }else{
            r = { status:'error' };
            r.msg = self.rules[self._errorId].msg;
        }
        return r;
    }
    /**
     * [upDateMsg 动态改变报错文案，如果更新的错误规则正是当前的错误规则的话则会触发error事件]
     * @param  {[Number|string]} ruleIdOrName [报错规则名称或所在列表中得key]
     * @param  {[string]} newMsg       [新的报错文案]
     * @return {[type]}              [description]
     */
    ValidateSingle.prototype.upDateMsg = function(ruleIdOrName,newMsg){
        var self = this,
            i = 0,
            _ruleId = ruleIdOrName;
        if( typeof _ruleId == 'string' ){
            for( ; i<self.rules.length; i++ ){
                if( self.op.checklist[i].rule === _ruleId ){
                    _ruleId = i;
                    break;
                }
            }
        }
        self.rules[i].msg = newMsg;
        if( self._errorId == i ){
            self.trigger('error',['error',self,newMsg]);
        }
    }
    /**
     * [addRules 新的验证规则]
     * @param {[object]} newRules [参见构造函数rules详细说明]
     */
    ValidateSingle.prototype.addRules = function(newRules){
        var self = this;
        self.rules = self.rules.concat(newRules);
    }
    
    /**
     * [removeRules 移除某条验证规则]
     * @param  {[number]} rulesId [需要移除规则的ID]
     * @return {[type]}         [description]
     */
    ValidateSingle.prototype.removeRules = function(rulesId){
        var self = this;
        for (var i = arguments.length - 1; i >= 0; i--) {
            for (var j = self.rules.length - 1; j >= 0; j--) {
                if( self.rules[j] == arguments[i] ){
                    self.rules.splice(j,1);
                    break
                }
            };
        }
    }

    ValidateSingle._default = {
        eventCheckbox:'click',
        eventSelect:'change',
        eventText:'blur'
    }

    /**
     * [Validate 表单验证构造函数]
     * @param {[array]} checkList [验证字段列表，单个字段信息参看 add方法]
     * @param {[object]} op        [可选，验证事件或者form选择器，如果form元素存在则在且验证失败，submit将被阻止]
     */
    var Validate = ajk.inherit(ajk.Observer,function(checkList,op){
        var self = this;
        self._op = $.extend({},Validate._default,op);
        self._skipList = [];
        self.filds = {};
        self._init(checkList);
    });
    
    Validate.prototype._init = function(checkList){
        var self = this;
        $.each(checkList,function(key,value){
            self.add(value);
        });
        $(self._op.formSelect).on('submit',function(){
            return self.checkAll();
        });
    }
    /**
     * [add 添加新的验证字段]
     * @param {[object]} vOne [验证规则参数]
     *                        vOne.selector [string] 验证字段的选择器
     *                        vOne.checklist [array] 验证字段的规则列表,详见ValidateSingle
     */
    Validate.prototype.add = function(vOne){
        var self = this,
            fi = $(vOne.selector);
        if( fi.length <= 0 || vOne.checklist.length <= 0 ){
            return
        }
        var _name = fi.attr('name');
        self.filds[_name] = new ValidateSingle(fi,vOne.checklist,self._op);
        self.filds[_name].on('error success remoteBegin remoteEnd',function(eventType,valObj,msg){
            self._op.singleHandle(valObj.dom,eventType,valObj,msg);
        });
    }
    /**
     * [remove 永久移除验证字段]
     * @param  {[string]} name [验证字段的name]
     * @return {[type]}        [如果成功删除返回原验证对象object，如果删除失败则返回undefined]
     */
    Validate.prototype.remove = function(name){
        var self = this,_delItem;
        if( self.filds[name] ){
            _delItem = self.filds[name];
            delete self.filds[name];
        }
        return _delItem;
    }
    /**
     * [checkAll 统一验证]
     * @param  {[boolean]} notSkip [是否不经过忽略列表的过滤经行验证，即全部验证]
     * @return {[boolean]}         [验证结果]
     */
    Validate.prototype.checkAll = function(notSkip){
        var self = this,
            result = true,
            firstError = false,
            _skip = notSkip?[]:self._skipList;
        for( var i in self.filds ){
            if( $.inArray(i,_skip) >= 0 ){
                continue;
            }
            var r = self.filds[i].check();
            if(!r){
                if (!firstError) {
                    self.trigger('firstError', [self.filds[i].dom]);
                    firstError = true; 
                }
                  
                result = false;
            }
        }
        var eventName = result?'success':'error';
        self.trigger(eventName);
        return result;
    }
    /**
     * [checkAsList 部分验证]
     * @param  {[array]} list   [需要验证的字段 name 组成的数组]
     * @return {[boolean]}      [验证结果]
     */
    Validate.prototype.checkAsList = function(checklist){
        var self = this,
            result = true;
        for( var i=0; i<checklist.length; i++ ){
            var r = self.filds[checklist[i]].check();
            if(!r){
                result = false;
            }
        }
        return result;
    }
    /**
     * [addSkip 添加忽略验证的字段列表]
     * @param {[string||array]} _skip [需要忽略验证字段的name或者由name组成的数组]
     */
    Validate.prototype.addSkip = function(_skip){
        var self = this,
            skip = ( typeof _skip == 'string' )?[_skip]:_skip;
        for( var i = 0; i<skip.length; i++ ){
            if( $.inArray(skip[i],self._skipList) >= 0 ){
                continue;
            }
            self._skipList.push(skip[i]);
        }
    }
    /**
     * [addSkip 从忽略验证的字段列表中移除字段]
     * @param {[string||array]} _skip [需要移除字段的name或者由name组成的数组]
     */
    Validate.prototype.removeSkip = function(_skip){
        var self = this,newSkip = [],
            skip = ( typeof _skip == 'string' )?[_skip]:_skip;
        for( var i = 0; i < self._skipList.length; i++ ){
            if( $.inArray(self._skipList[i],skip) >= 0 ){
                continue;
            }
            newSkip.push(self._skipList[i]);
        }
        self._skipList = newSkip;
    }
    Validate._default = {
        formSelect:'',
        singleHandle:function(dom,eventType,valObj,msg){
            var tpl = '<div class="ui message error"><i class="ui icon predefine"></i><div class="content">{%= msg %}</div></div>';
            if( !valObj.msgBox || valObj.msgBox.length < 1 ){
                valObj.msgBox = $(_.template(tpl)({ msg:msg||''}));
                valObj.dom.parents('.field').append(valObj.msgBox);
            }
            switch(eventType){
                case 'error': {
                    valObj.msgBox.removeClass('success remote').addClass('error').find('.content').html(msg).show();
                }
                break;
                case 'success': {
                    valObj.msgBox.removeClass('error remote').addClass('success').find('.content').html('').show();
                }
                break;
                case 'remoteBegin': {
                    valObj.msgBox.removeClass('success error').addClass('remote').find('.content').html('加载中...').show();
                }
                break;
                case 'remoteEnd': {
                    var status = valObj.status(),
                        msg = ( status.status == 'error' )?status.msg:'',
                        _class = ( status.status == 'error' )?'error':'success';
                    valObj.msgBox.removeClass('remote error success').addClass(_class).find('.content').html(msg).show();
                }
                break;
                default:{
                    valObj.msgBox.hide()
                }
            }
        }
    }


    /**
     * [rulesText 验证规则，方法，对应关系，针对非checkbox和radio]
     * @type {Object}
     */
    Validate.rulesText = {
        required:function(filds){
            var val = filds.val();
            var val = $.trim(val);
            return val.length > 0 && val != filds.attr('placeholder');
        },
        integer:function(filds){
            var val = filds.val();
            return /^\-?[\d]*$/.test(val)
        },
        equal:function(filds,eqVal){
            var val = filds.val();
            return val === eqVal
        },
        not:function(filds,notVal){
            var val = filds.val();
            return val != notVal;
        },
        maxLength:function(filds,maxlength){
            var val = filds.val();
            return val.length <= maxlength;
        },
        minLength:function(filds,minLength){
            var val = filds.val();
            return val.length >= minLength;
        },
        max:function(filds,_max){
            var val = filds.val()-0;
            return val - _max <= 0
        },
        min:function(filds,min){
            return filds.val()-0-min >= 0
        },
        email:function(filds){
            var val = filds.val();
            return /^[a-z0-9_-]+@[a-z0-9_-]+\.\w{2,3}$/i.test(val);
        },
        ucode: function (filds) {
            var val = filds.val();
            return /^[U]{0,1}\d{12}$/.test(val);
        },
        number: function (filds) {
            var val = filds.val();
            return !isNaN(val);
        },
        remote:function(filds,_op,_msg,checklistId){
            var my = this,
                msg = _msg,
                oldVal = filds.data('remote'),
                nowVal = filds.val(),
                op = $.extend({},{
                    type:'post',
                    url:'',
                    loading:'验证中...',
                    dataType:'json',
                    dataInit:function(fi){
                        return fi.val()
                    },
                    resultInit:function(r){
                        //{ st:true,val:最后验证的值,msg:'已过期' }
                        return r
                    }
                },_op);
                
            if( oldVal && oldVal != '' && oldVal == nowVal ){
                return true;
            }else{
                var remoteData = op.dataInit(filds);
                my._isRemoteing = true;
                my.trigger('remoteBegin',['remoteBegin',my,op.loading]);
                var resultHandle = function(r){
                    var r = op.resultInit(r);
                    if(!!r.st == true){
                        filds.data('remote',r.val);
                        if( filds.val() == r.val ){
                            my._errorId = null;
                            my.trigger('success',['success',my]);
                        }else{
                            my._errorId = checklistId;
                            my.trigger('error',['error',my,msg]);
                        }
                    }else{
                        var _serverMsg = msg;
                        my._errorId = checklistId;
                        my.trigger('error',['error',my,_serverMsg]);
                    }
                    my._isRemoteing = false;
                    my.trigger('remoteEnd',['remoteEnd',my]);
                }
                $.ajax({
                    type:op.type,
                    dataType:op.dataType,
                    url:op.url,
                    data:{'w':remoteData},
                    success:resultHandle,
                    error:function(){
                        my._errorId = checklistId;
                        my.trigger('error',['error',my,msg]);
                    }
                });
                // return false;
            }
        }
    }

    /**
     * [rulesCheckbox 验证规则与方法对应 针对checkbox和radio]
     * @type {Object}
     */
    Validate.rulesCheckbox = {
        required:function(filds){
            return filds.filter(':checked').length > 0;
        },
        maxNumber:function(filds,max){
            return filds.filter(':checked').length <= max;
        }
    }

    ajk.Validate = Validate;
})(jQuery);