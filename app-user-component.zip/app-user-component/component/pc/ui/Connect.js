;(function(){
    var Connect;
    APF.Namespace.register('ajk.Connect');
    ajk.Connect = Connect = function(){
        var self = this;

        self._key = 0;
        self._final = null;
        self._stack = [];
    }

    Connect.prototype.next = function(job) {
        this._stack.push(job);
        return this;
    }

    Connect.prototype.allDone = function(finalHandle){
        this._final = finalHandle
        return this;
    }

    Connect.prototype._handle = function(arg){
        var self = this;
        var fn = self._stack[self._key] || self._final;

        if( !fn ){
            return;
        }

        var next = function(){
            if( self._key == self._stack.length ){
                return;
            }
            self._key ++;
            self._handle(arg);
        }

        var jobArg = arg.concat([next]);
        fn.apply(self,jobArg);
    }

    Connect.prototype.start = function(){
        var self = this;
        var _arr = _.toArray(arguments)
        self._key = 0;
        self._handle(_arr);
    }

})();