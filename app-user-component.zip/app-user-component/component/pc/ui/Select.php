<?php
class Pc_Ui_SelectComponent extends User_Component_AbstractComponent {
    
    public function getView() {

        return "";
    }

    public static function use_boundable_styles()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array_merge(
            parent::use_boundable_styles(),
            array($path."Select.css")
        );
    }

    public static function use_boundable_javascripts()
    {
        $path = apf_classname_to_path(__CLASS__);
        $js = array_merge(
            parent::use_boundable_javascripts(),
            array($path."Select.js")
        );
        return $js;
    }

}
