<?php

class Pc_Ui_Validate2Component extends APF_Component

{
    public function get_view()
    { 

    }

    public static function use_boundable_javascripts()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array_merge(
            parent::use_boundable_javascripts(), 
            array($path . "Inherit.js"),
            array($path . "Event.js"),
            array($path . "Connect.js"),
            array($path . "Validate2.js"),
            array($path . "Validate2-view.js")
        );
    }

    public static function use_javascripts()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array_merge(
            parent::use_javascripts()
            // array(PageHelper::pure_static_url("/js/jquery-1.9.1/jquery-underscore.min.js"),PHP_INT_MAX)
        );
    }
}