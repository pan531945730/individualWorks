;APF.Namespace.register('ajk.MsgCenter');
;(function(){

    var Msger = ajk.inherit(ajk.Observer,function(field){
        var self = this;
        self.dom;
        self.fields = [];
        self.msgs = {};
        self._lastResult = {};
        self.init(field);
    });

    Msger.prototype.init = function(field){
        var self = this;
        self.dom = $(field.msgSelector);
        self.addWatcher(field);

        // self.dom.hide();
    }

    Msger.prototype.addWatcher = function(field){
        var self = this,
            dom = $(field.selector),
            domType = dom.attr('type'),
            isSelect = dom.filter('select').length > 0,
            name = dom.attr('name');

        self.fields.push({
            msgKey:name,
            dom:dom 
        });

        self.msgs[name] = {
            operated:false,
            focus:field.focusMsg,
            error:null,
            remote:null,
            extend:field.extendMsg
        }

        if( domType == 'checkbox' || domType == 'radio' || isSelect ){
            return;
        }
        dom.focus(function(){
            self.getMsgQuery();
        });
    }

    var tplMsg = '{% icon?icon:\'\' %}{% msg %}',
        icons = {
            success:'<i class="com-ico success-ico"></i>',
            error  :'<i class="com-ico warn-ico"></i>',
            extend:'<i class="com-ico prompt-ico"></i>',
            remote:'',
            focus:''
        };
    Msger.prototype.showMsg = function(iconType,msg){
        var self = this,
            da = {
                icon:icons[iconType],
                msg:msg
            };

        self.dom.html( ajk.render(tplMsg,da) ).show();
        if( iconType == 'focus' || iconType == 'remote' ){
            self.dom.addClass('msg-gry');
        }else{
            self.dom.removeClass('msg-gry');
        }
        if (iconType == 'error') {
            self.dom.addClass('error-font');
        } else {
            self.dom.removeClass('error-font');
        }
    }

    Msger.prototype.hideMsg = function(){
        this.dom.hide();
    }

    Msger.prototype.msgQuery = ['getFocusMsg','getRemoteMsg','getErrorMsg','getExtendMsg','getSuccessMsg'];

    Msger.prototype.getMsgQuery = function(){
        var self = this,
            point = 0,
            doQuery = function(){
                var _thisQuery = self.msgQuery[point];
                if( !_thisQuery ){
                    return;
                }
                self[_thisQuery](function(r){
                    if( r !== false ){
                        point++;
                        doQuery();
                    }
                });
            };


        self._lastResult = {};

        for( var i = 0, _this, _msg; i < self.fields.length; i++ ){
            _this = self.fields[i];
            _msg = self.msgs[ _this.msgKey ];

            if( _this.dom.hasClass('fi-focus') ){
                var focusMsg = typeof _msg.focus == 'function' ? _msg.focus.call(_this.dom) : _msg.focus;
                self._lastResult.focus = focusMsg ||'&nbsp;';
            }

            if( self._lastResult.error === undefined && typeof _msg.error == 'string' ){
                self._lastResult.error = _msg.error;
            }

            if( self._lastResult.error === undefined && typeof _msg.error == 'function' ){
                self._lastResult.error = _msg.error();
            }

            if( _msg.operated == false ){
                self._lastResult.hasUnactived = true;
            }

            if( self._lastResult.remote === undefined && _msg.remote !== null ){
                self._lastResult.remote = _msg.remote;
            }
        }

        self.hideMsg();
        doQuery();
    }

    Msger.prototype.getFocusMsg = function(next){
        var self = this;
        
        if( self._lastResult.focus ){
            self.showMsg('focus',self._lastResult.focus);
            next(false)
        }else{
            next();
        }
    }

    Msger.prototype.getRemoteMsg = function(next){
        var self = this;

        if( self._lastResult.remote ){
            self.showMsg('remote',self._lastResult.remote);
            next(false)
        }else{
            next();
        }
    }

    Msger.prototype.getErrorMsg = function(next){
        var self = this;
        if( self._lastResult.error ){
            self.showMsg('error',self._lastResult.error);
            next(false)
        }else{
            next();
        }
    }

    Msger.prototype.getExtendMsg = function(next){
        var self = this,
            point = 0,
            doQuery = function(){
                if( !self.fields[point] ){
                    next();
                    return;
                }

                var key = self.fields[point].msgKey,
                    msger = self.msgs[key],
                    _thisQuery = msger.extend;

                if( !_thisQuery || msger.error === null  ){
                    point++;
                    doQuery();
                    return;
                }

                _thisQuery(key,function(r){
                    if( typeof r  == 'string' ){
                        self.showMsg('extend',r);
                    }else{
                        point++;
                        doQuery();
                    }
                });
            };
        doQuery();
    }

    Msger.prototype.getSuccessMsg = function(next){
        var self = this;
        if( self._lastResult.error === undefined && !self._lastResult.hasUnactived ){
            self.showMsg('success','');
        }else{
            self.hideMsg();
        }
    }

    Msger.prototype.upDateMsg = function(name,type,msg){
        var self = this;
        self.msgs[name][type] = msg;
        self.getMsgQuery();
    }


    var MsgCenter = function(fields){
        var self = this;

        self.map = {};
        self.msgers = [];
        self.init(fields);
    }
    MsgCenter.prototype.init = function(fields){
        var self = this;
        for( var i = 0; i < fields.length; i++ ){
            var field = fields[i];
            self.addField(field);
        }
    }

    MsgCenter.prototype.addField = function(field){
        var self = this,
            name = $(field.selector).attr('name'),
            msgObj = self.findMsger( field.msgSelector );
        if( msgObj != null ){
            msgObj.addWatcher(field);
            self.map[name] = msgObj;
        }else{
            var newMsger = new Msger(field);
            self.map[name] = newMsger;
            self.msgers.push({
                key:field.msgSelector,
                msger:newMsger
            });
        }
    }

    MsgCenter.prototype.findMsger = function(key){
        var self = this,
            result = null;
        for( var i = 0; i < self.msgers.length; i++ ){
            if( self.msgers[i].key == key ){
                result = self.msgers[i].msger
                break;
            }
        }
        return result
    }

    MsgCenter.prototype.connector = function(dom,eventType,valObj,msg){
        var self = this,
            key = dom.attr('name'),
            msger = self.map[key];

        msger.upDateMsg(key,'operated',true);
        switch(eventType){
            case 'success':
                    dom.removeClass('fi-err');
                    msger.upDateMsg(key,'error',undefined);
                break;
            case 'error':
                    dom.addClass('fi-err');
                    msger.upDateMsg(key,'error',msg);
                break;
            case 'remoteBegin':
                    msger.upDateMsg(key,'remote',msg);
                break;
            case 'remoteEnd':
                    msger.upDateMsg(key,'remote',null);
                break;
        }
    }

    MsgCenter.prototype.removeSkipErrorMsg = function (key) {
        var self = this;
        var map = self.map;
        for (var i in map) {
            if (map[i].msgs[key]) {
                map[i].msgs[key].error = null;
            }
        }
    }

    var Validate;
    ajk.ValidateBroker = Validate = function(form,fields){
        var self = this;

        self.msgShower = new MsgCenter(fields);
        self.validater = new ajk.Validate(fields,{
            formSelect:form,
            singleHandle:function(dom,eventType,valObj,msg){
                self.msgShower.connector(dom,eventType,valObj,msg);
            }
        });
    }

})();