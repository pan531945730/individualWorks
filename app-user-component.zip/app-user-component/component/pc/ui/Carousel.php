<?php
class Pc_Ui_CarouselComponent extends User_Component_AbstractComponent {
    
    public function getView() {

        return "";
    }

    public static function use_boundable_styles()
    {
        return array_merge(
            parent::use_boundable_styles(),
            array('')
        );
    }

    public static function use_boundable_javascripts()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array_merge(
            parent::use_boundable_javascripts(),
            array($path . "Carousel.js")
        );
    }

}
