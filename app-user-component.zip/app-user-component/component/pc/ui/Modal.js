APF.Namespace.register('ajk');
(function ($) {
    "use strict";
    ajk.Modal = ajk.inherit(ajk.Observer,function (op) {
        var self = this;
        self.op = $.extend({}, ajk.Modal._default, op);
        self.op.ie6 = /MSIE 6/.test(navigator.userAgent);
    });
    ajk.Modal._default = {
        modalClass: '', //className,多个类名空格分开
        con       : '', //conHtml
        hd        : '', //headerHtml
        title     : '', //titleText
        bd        : '', //bodyHtml
        ft        : '', //footerHtml
        width     : 560, //Number
        height    : '', //Number
        pos       : {top: undefined, left: undefined},//Number
        mask      : true, //true,false，遮罩层
        duration  : 200 //Number，动画持续时间
    };
    ajk.Modal.prototype._create = function () {
        var self = this,
            op = self.op;
        //生成节点
        op.modal = $('<div class="xf-modal"></div>');
        op.modalMask = $('<div class="modal-mask"></div>');
        op.modalIfr = $('<iframe class="modal-ifr"></iframe>');
        op.modalCover = $('<div class="modal-cover"></div>');
        //写入节点内容
        var shadow = $('<div class="shadow"></div>'),
            close = $('<a href="javascript:" class="md-close">x</a>'),
            con = $('<div class="con"></div>').append($(op.con).show()),
            hd = $('<div class="hd"></div>').append($(op.hd).show()),
            bd = $('<div class="bd"></div>').append($(op.bd).show()),
            ft = $('<div class="ft"></div>').append($(op.ft).show());
        //插入节点
        !op.hd && op.title && hd.html('<h3 class="title">' + op.title + '</h3>');
        op.con || $().add((op.hd || op.title) && hd).add(op.bd && bd).add(op.ft && ft).appendTo(con);
        con.add(close).appendTo(op.modal);
        op.modalClass && op.modal.addClass(op.modalClass);
        con.css({width: op.width, height: op.height});
        op.modalCover.append(op.modal).appendTo('body');
        //关闭按钮事件
        close.on('click.modal', function () {
            self.close();
        });
        //是否添加遮罩层
        var docHeight = $(document).height();
        op.mask && op.modalMask.css({'height': docHeight}).appendTo('body');
        //ie6添加iframe
        op.ie6 && op.modalIfr.css({'height': docHeight}).appendTo('body');
    };
    /**
     * [center 弹出框居中函数]
     */
    ajk.Modal.prototype.center = function (node, duration) {
        var self = this,
            op = self.op,
            nodeWidth = node.outerWidth(),
            nodeHeight = node.outerHeight(),
            winHeight = $(window).height();
        //弹出内容超过一屏时，隐藏body滚动条，显示弹出框滚动条，ie6全部隐藏body滚动条
        if (op.ie6 || nodeHeight > winHeight) {
            $('html').css({'overflow': 'hidden'});
            op.modalCover.css({'overflow': 'auto'});
        } else {
            $('html').css({'overflow': ''});
            op.modalCover.css({'overflow': 'hidden'});
        }
        //未传入pos值，默认居中定位
        if (op.pos.top === undefined || op.pos.left === undefined) {
            var _left = -parseInt(nodeWidth / 2, 10),
                _top = -parseInt(nodeHeight / 2, 10);
            if (nodeHeight > winHeight) {
                _top = -parseInt(winHeight / 2, 10);
            }
            node.animate({'margin-top': _top, 'margin-left': _left}, duration);
        } else {
            node.animate(op.pos, duration);
        }
    };
    /**
     * [open 弹出框打开函数]
     * 可绑定函数 openBefore,openAfter
     */
    ajk.Modal.prototype.open = function () {
        var self = this, op = self.op, undefined = window.undefined;
        //计算位置
        function calpos(duration) {
            op.ie6 && op.modalCover.css({'top': $(window).scrollTop()});
            self.center(op.modal, duration);
        }

        if ($(self).trigger('openBefore') !== false) {
            //第一次弹出，则插入节点到body
            (op.modal === undefined) && self._create();
            calpos(0);
            op.modalCover.add(op.modalMask).add(op.modalIfr).css({'visibility': 'visible'});
            //绑定窗口resize事件
            $(window).off('resize.modal').on('resize.modal', function () {
                op.timer && clearTimeout(op.timer);
                op.timer = setTimeout(function () {
                    calpos(op.duration);
                }, 200);
            });
            $(self).trigger('openAfter');
        }
    };
    /**
     * [close 弹出框关闭函数]
     * 可绑定函数 closeBefore,closeAfter
     */
    ajk.Modal.prototype.close = function () {
        var self = this, op = self.op;
        if ($(self).trigger('closeBefore') !== false) {
            if (op.modal !== undefined) {
                op.modalCover.css({'overflow': 'hidden'}).add(op.modalMask).add(op.modalIfr).css({'visibility': 'hidden'});
                $('html').css({'overflow': ''});
                $(window).off('resize.modal');
                $(self).trigger('closeAfter');
            }
        }
    };
})(jQuery);