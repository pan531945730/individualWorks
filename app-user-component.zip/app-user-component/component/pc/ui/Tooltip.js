/**
 * 使用示例：
 * 第一种简单的使用方法：直接在hover的元素上写一个  data-autoTips 的属性
 * 		eg：<a data-autoTips="你要显示再提示框中的内容,{{right}}"
 * 		注意：这种简单的使用方法最后的「,{{right}}」为配置参数-->箭头靠近提示框的右边缘不写的话默认左边缘。
 * 第二种使用方法：写在js里
 * 		$(selector).toolTip('你要显示再提示框中的内容',{});
 *		selector为选择器名称，
 *		第二个参数可以是字符串也可以是function。
 *		若为function->$(selector).toolTip(function(render){
 			var that  = this;
 *			render('你要显示再提示框中的内容',that)
 *		},{});
 *			render的第一个参数为需要显示的HTML。第二个参数为 this；这里的this指的是当前houve的dom元素。
 *		第三个参数为option；
 */
/**
 * 参数配置示例。
 * arrowDiretion:箭头出现的位置，tb是出现在hover元素的上下，lr是出现在hover元素的左右。
 * arrowPosition：箭头靠近提示框的左边缘或者右边缘。注意：只有arrowDiretion：tb 的时候此参数才有效。
 * width:100;可设置宽度默认auto；
 * 以下是默认配置。
 */

/*	default_op = {
		arrowDirection:'tb',
		arrowPosition:'left',
	}
*/
;
(function($) {
	var defaultsOptions = {
		arrowDirection: 'tb',
		arrowPosition: 'left'
	};
	(function(pluginname) {
		var $tipDom, $msg, $arrow, arrowDirectionsClassNames, $body, global = {};
			$body                     = $('body');
			$tipDom                   = $('<div style="position:absolute;z-index:10000"><div class="tooltip-wrap"><div class="tooltip-arrow arr-top"><div class="tooltip-arrowbg"></div></div><div class="tooltip-msg"></div></div></div>');
			$msg                      = $tipDom.find('.tooltip-msg');
			$arrow                    = $tipDom.find('.tooltip-arrow');
			arrowDirectionsClassNames = {
				upwards: 'arr-top',
				rightwards: 'arr-right',
				downwards: 'arr-bottom',
				leftwards: 'arr-left'
			}
		function insertMsg(msg) {
			$msg.html(msg);
		}
		function renderPosition(targetDom,op) {
			// $arrow.removeClass(arrowDirectionsClassNames.upwards,arrowDirectionsClassNames.rightwards,arrowDirectionsClassNames.downwards,arrowDirectionsClassNames.leftwards);
			// 清除已有的箭头方向的Class
			$arrow.attr('style','');
			for(var k in arrowDirectionsClassNames){
				$arrow.removeClass(arrowDirectionsClassNames[k]);
			}
				var $targetDom 	   = $(targetDom), //目标元素
					t_offset       = $targetDom.offset(), //目标元素的位置
					t_width        = $targetDom.outerWidth(), //目标元素的宽度
					t_height       = $targetDom.outerHeight(), //目标元素的高度
					arrPos         = op.arrowPosition, //小箭头的位置（不是方向）
					arrDir         = op.arrowDirection,
					tips_position  = {
						left: 0,
						top: 0,
						excursion:12
					}; //tip的位置
			$tipDom.hide().appendTo($body);
			$tipDom.width(op.width||'auto');
			
			if (arrDir == 'tb') {
				//箭头朝上或者朝下
				if (arrPos == 'left') {
					tips_position.left = t_offset.left + t_width / 2 - 28;
					$arrow.css('right', 'initial');
					$arrow.css(arrPos, '19px')
				} else if (arrPos == 'right') {
					tips_position.left = t_offset.left - $tipDom.width() + t_width / 2 + 28;
					$arrow.css('left', 'initial')
					$arrow.css(arrPos, '19px');
				} else if(arrPos == 'center') {
					$arrow.addClass('arr-center');
					tips_position.left = t_offset.left + t_width / 2 - $tipDom.width() / 2;	
				}
				/**
				 *	设置提示框出现在目标元素的上方或者下方
				 *	出现在下方的时候arrow方向朝上
				 *	出现在上方的时候arrow方向朝下
				 */
				var scTop = $(document).scrollTop(), //页面Scroll的高度；
					clHeight = document.documentElement.clientHeight; //窗口高度；

				if (t_height + tips_position.excursion + t_offset.top + $tipDom.height() - scTop > clHeight) {
					arrDir = arrowDirectionsClassNames.downwards;
					tips_position.top = t_offset.top - $tipDom.height() - tips_position.excursion;
				} else {
					arrDir = arrowDirectionsClassNames.upwards;
					tips_position.top = t_offset.top + t_height + tips_position.excursion;
				}

				$arrow.addClass(arrDir);
			} 
			if (arrDir == 'lr') {
				//箭头朝左或右
				tips_position.top = t_offset.top - $tipDom.height()/2+t_height/2;
				// 判断提示框有没有超出屏幕的宽度
				if(t_offset.left+t_width+tips_position.excursion > document.documentElement.clientWidth){
					arrDir = arrowDirectionsClassNames.rightwards;
					tips_position.left = t_offset.left-$tipDom.width()-tips_position.excursion
				}else{
					arrDir = arrowDirectionsClassNames.leftwards;
					tips_position.left = t_offset.left+t_width+tips_position.excursion
				}
				$arrow.css('top',$tipDom.height()/2-8+'px');
				$arrow.addClass(arrDir);
			}

			$tipDom.css({left:tips_position.left,top:tips_position.top});
			$tipDom.show();
		}
		function syncShowTips (msg,targetDom,_op) {
			insertMsg(msg);
			renderPosition(targetDom,_op)
			$(targetDom).trigger('tipshow');
		}
		function asynShowTips (msg,targetDom) {
			if(targetDom == global.targetDom){
				insertMsg(msg);
				renderPosition(targetDom,global.op)
				$(targetDom).trigger('tipshow');
			}	
		}
		$.fn[pluginname] = function(arg0, _op) {
			return this.each(function() {
				var $that = $(this);
				$that.on('mouseover', function(e) {
					e.stopPropagation();
					var $that = $(this);
					clearTimeout(window.stt);
					clearTimeout(window.sttt);
					window.stt = window.sttt = undefined;
					window.st = setTimeout(function() {
						var _argType = typeof arg0;
						_op = $.extend({},defaultsOptions,_op)
						if(_argType =='string'){
							var _msgHtml = arg0;
							syncShowTips(_msgHtml,$that[0],_op)
						}
						if(_argType =='function'){
							global.op = _op;
							global.targetDom = $that[0];
							syncShowTips('请稍后。。。',$that[0],_op)
							arg0.call($that[0],asynShowTips)
						}
					}, 150);
				});
				$that.on('mouseout', function(e) {
					e.stopPropagation();
					var that = this;
					clearTimeout(window.st);
					clearTimeout(window.stt);
					window.st = undefined;
					window.stt = setTimeout(function() {
						$(global.targetDom).trigger('tiphide');
						global.targetDom = null;
						$tipDom.detach();
					}, 200);
				})
			});
		};
		$tipDom.on('mouseenter', function(e) {
			clearTimeout(window.stt);
			window.stt = undefined;
			e.stopPropagation();
		});
		$tipDom.on('mouseleave', function(e) {
			e.stopPropagation();
			window.sttt = setTimeout(function() {
				$(global.targetDom).trigger('tiphide');
				$tipDom.detach();
			}, 150)
		});
		$(document).ready(function  () {
			$body = $('body');
			$('[data-autoTips]').on('mouseover', function(e) {
				e.stopPropagation();
				var $that = $(this);
				clearTimeout(window.stt);
				clearTimeout(window.sttt);
				window.stt = window.sttt = undefined;
				window.st = setTimeout(function() {
					global.targetDom           = null;
					var _preMsg, _msgHtml, _op = {};
					_preMsg                    = $that.attr('data-autoTips');
					_msgHtml                   = _preMsg.replace(/^(.+)(,{{(right|bottom)}})$/g, "$1"); // 处理preMsg得到提示的msg
					_op.arrowPosition          = _preMsg.match(/(,{{(right|bottom)}})$/g); // 处理preMsg得到箭头的位置（不是方向）
					_op.arrowPosition          = _op.arrowPosition ? _op.arrowPosition[0].replace(/.+(right|bottom).+/g, '$1') : 'left';
					_op                        = $.extend({},defaultsOptions,_op)
					syncShowTips(_msgHtml,$that[0],_op)
				}, 150);

			});
		$('[data-autoTips]').on('mouseout',function(e) {
				e.stopPropagation();
				var that = this;
				clearTimeout(window.st);
				window.st = undefined;
				window.stt = setTimeout(function() {
					$tipDom.detach();
				}, 200);
			});
		})
	})("toolTip");
})(jQuery);