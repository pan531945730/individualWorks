  /**
   * [DataCache 缓存数据对象 依赖 http://underscorejs.org/#isEqual ]
   * @param {[function]} source [数据来源，对于相同请求，只从来源请求获取一次]
   */
APF.Namespace.register('ajk');
(function($){
  ajk.DataCache = function(source){
      var self = this;
      self._cache = [];
      self.source = source;
  }

  ajk.DataCache.prototype.get = function(keys,callback) {
      var self = this,
          cacheDatas = [],
          newQuery = [],
          query = _.isArray(keys)?keys:[keys];

      /**
       * [doHandle 单个请求返回单一数据，多个请求(数组)，结果页返回数组]
       */
      var doHandle = function(rep,req){
          if( !_.isArray(keys) ){
              callback( rep[0], req[0] );
          }else{
              callback(rep,req);
          }
      }

      for( var i = 0; i < query.length; i++ ){
          var _cache = self.find(query[i]);
          if( _cache !== null ){
              cacheDatas[i] = _cache;
          }else{
              newQuery.push({
                  id:i,
                  query:query[i]
              });
          }
      }

      if( newQuery.length === 0 ){
          doHandle( cacheDatas, query );
          return
      }

      for( var j = 0,backed = 0; j < newQuery.length; j++ ){
          (function(){
              var _thisQuery = newQuery[j];
              self.source( _thisQuery.query ,function(data){
                  var da = self.add( _thisQuery.query ,data).data;
                  cacheDatas[ _thisQuery.id ] = da;
                  backed ++;
                  if( backed === newQuery.length ){
                      doHandle( cacheDatas, query );
                  }
              });
          })();
      }

  };

  ajk.DataCache.prototype.add = function(key,data){
      var self = this,
          newData = {
              key:key,
              data:data
          };
      self._cache.push(newData);
      return newData
  };

  ajk.DataCache.prototype.find = function(key) {
      var self = this,
          result = null,
          i = 0,
          len = self._cache.length;
      for( ; i < len ; i ++ ){
          if( _.isEqual( self._cache[i].key, key) ){
              result = self._cache[i].data;
              break;
          }
      }
      return result
  };
})(jQuery);