//  本模块依赖于 jquery & underscore, ajk.DataCache
//  示例如下:
//  var auto = 
//      new ajk.Autocomplete($('#search-rent'),{
    //     hasCache : true,                         //是否有数据源缓存，相同的keyword不会重复请求。、、
    //     debouce  : 250 ,                         //反弹时间，在时间内的连续输入不会触发获取数据，直至时间内没有输入。
    //     insertDom:$('#search-rent').parent(),    //wrap appendTo的元素
    //     template : _.template($('#search-tpl').html()), //列表渲染模板
    //     itemSelector: 'li',                      //每条目的选择器
    //     keySelector : 'span',                    //关键字的选择器
    //     cursorClass : 'auto-grayback',           //hover条目时的class
    //     wrap        : '.auto-wrap',              //wrap 支持className（需加.）,jquery对象，或者html字符串
    //     emptyFetch  : false                      //value为空时是否请求
    //     dataSource: function(keyword,setData){  //数据源函数，也支持数组形式，keyword返回当前input的key，setData用以传入数据
    //         $.ajax({
    //             url: op.url,
    //             type: 'GET',
    //             dataType: 'jsonp',
    //             data: { kw: keyword  }
    //         }).done(function(data) {
    //             setData(data.list);
    //         });
    //     }
    // });
    // 可绑事件：
    // inputed  输入时触发，会返回当前keyword
    // selected 当条目被选择时触发，返回当前条目的jquery对象，原始数据和index
    // cursored 当条目被hover时触发，返回当前条目的jquery对象，原始数据和index
    // onfocus, onblur 当input被 focus, blur时触发
    // 方法：
    // show()   hide() 显示/隐藏 wrap
    // resetCursored() 重置cursor状态
    // cursor(optNum, isCal) cursor指定的index，若存在isCal且为true, 则cursor结果为当前cursor + optNum 
    //                       如 cursor(-1, true) 向前cursor一位  cursor(0) cursor第一个item
    // select($item)  以传入的$item触发selected
    // input(keyword) 以传入的keyword触发inputed

APF.Namespace.register('ajk');
(function($){
    ajk.Autocomplete = ajk.inherit(ajk.Observer,function(el,op){
        var _tpl = 
        '<ul class="auto-ul">'+
            '<% _.each(obj,function(item){ %>'+
                '<li>'+
                    '<span><%= item.keyword %></span><b>约<%= item.num %>套</b>'+
                '</li>'+
            '<%});%>'+
        '<ul>',
        _defaults = {
            dataSource     : function(){},
            debounce       : 250, 
            hasCache       : true, 
            insertDom      : $('body'), 
            template       : _.template( _tpl ), 
            itemSelector   : 'li',  
            keySelector    : 'span', 
            cursorClass    : 'auto-grayback', 
            wrap           : '.auto-wrap',
            emptyFetch     : false
        };
        this.op =$.extend({}, _defaults , op);
        this.op.wrapStyle = $.extend({}, _defaults.wrapStyle, op.wrapStyle);
        this.el = el;
        this._init();
    });

    ajk.Autocomplete.prototype._init = function(){
        this.wrap = null;
        this.sourceChecked = null;
        this.dataCenter = [];
        this.keyword = null;
        this._createWrap();
        this.resetCursored();
        this._checkSource();
        this._delay = false;
        if(this.op.hasCache){
            this.dataCache = new ajk.DataCache( this.sourceChecked );
        }
        this._bindEvent();
    }

    ajk.Autocomplete.prototype._createWrap = function(){
        if( this.op.wrap.constructor == jQuery){
            this.wrap = this.op.wrap.eq(0);
        }
        else if ( _.isString(this.op.wrap) ){
            var str = $.trim( this.op.wrap );
            var firstChar = str.substring(0,1);
            if( firstChar == '.'){
                this.wrap = $('<div class="'+ str.slice(1) + '"></div>');
            }
            else if( firstChar == '<'){
                this.wrap = $(str);
            }
            this.wrap.appendTo( this.op.insertDom );
        }
    }

    ajk.Autocomplete.prototype._bindEvent = function(){
        this._onKeyup();
        this._onMouseover();
        this._onClick();
        this._onFocus();
        this._onBlur();
        this._isEnterWrap();
        this._onMousedown();
    }

    ajk.Autocomplete.prototype._onKeyup = function(){
        var self = this;
        self.el.on('keyup',function(e){
            self._updateKeyword();
            switch(e.keyCode){
                case 35: // end
                case 36: // home
                case 16: // shift
                case 17: // ctrl
                case 18: // alt
                case 37: // left
                case 39: // right
                    break;
                case 40: //down
                    self.cursor(+1, true);
                    break;
                case 38: //up
                    self.cursor(-1, true);
                    break;
                case 13: //enter
                    if(self.cursorIndex != -1){
                        self.select(self.wrap.find(self.op.itemSelector).eq(self.cursorIndex));
                    }
                    break;
                default:
                    self._inputCheck(self.keyword);                  
                    break;
            }
        });
    }
    /*此处作用是鼠标不在下拉列表中的时候关闭延迟*/
    ajk.Autocomplete.prototype._isEnterWrap = function(){
        var self = this;
        self.wrap.on('mouseover',function(){
            self._delay = true;
        });
        self.wrap.on('mouseout',function(){
            self._delay = false;
        });

    }

    ajk.Autocomplete.prototype._onMouseover = function(){
        var self = this;
        self.wrap.on('mouseover',self.op.itemSelector,function(){
            self.cursorIndex = _index = $(this).index();
            self.cursor(_index);
        });
    }

    ajk.Autocomplete.prototype._onClick = function(){
        var self = this;
        self.wrap.on('click',self.op.itemSelector,function(){
            self.select($(this));
        });
    }
    ajk.Autocomplete.prototype._onFocus = function(){
        var self = this;
        self.el.on('focus',function(){
            self._updateKeyword();
            self._inputCheck(self.keyword);
            if(self.trigger('onfocus',arguments) !== false){
                self.el.css('border-color','#f60');
            }
        });
    }
    ajk.Autocomplete.prototype._onMousedown = function(){
        var self = this;
        self.wrap.on('mousedown', function(e){
            e.preventDefault();
            self.cancelBlur = true;
            //若非滚动条
            if( $(e.target).is(self.op.itemSelector) ){
                delete self.cancelBlur;
            } 
        })
    }
    ajk.Autocomplete.prototype._onBlur = function(){
        var self = this;
        self.el.on('blur',function(){
            if(self.cancelBlur){
                delete this.cancelBlur;
                return;
            }
            if(self.trigger('onblur',arguments) !== false){
                self.el.css('border-color','#ccc');
                if(self._delay){
                    setTimeout(function(){
                        self.hide();
                    },150); 
                } else {
                    self.hide();
                }

            }
        });
    }
    ajk.Autocomplete.prototype._updateKeyword = function(keyword){ //更新keyword
        this.keyword = keyword || this.el.val();
    }

    ajk.Autocomplete.prototype._inputCheck = function(val){ //检查是否需要触发输入事件
        if( $.trim(val) === ''){
            this.trigger('empty');
            if( this.op.emptyFetch ) this.input(val);
        }
        else{
            this.input(val);
        }
    }

    ajk.Autocomplete.prototype._checkSource = function(){ //检查数据源，若为函数，增加debounce；也可以为数组
        var self = this;
        if($.isFunction(self.op.dataSource)){
            self.sourceChecked = _.debounce(self.op.dataSource, self.op.debounce);
        }else if($.isArray(self.op.dataSource)){
            self.sourceChecked = self.op.dataSource;
        }
     }

    ajk.Autocomplete.prototype._updateData = function(){ //获取数据，可以为异步函数，也可以为数组
        var self = this;
        if($.isFunction(self.sourceChecked)){ //若为异步函数
            if(self.op.hasCache) self.dataCache.get(self.keyword, _setData);
            else self.sourceChecked(self.keyword, _setData);
        }
        else if($.isArray(self.sourceChecked)){ //若为数组
            self.dataCenter = self.sourceChecked;
            self._render();
        }
        function _setData(data){
            self.dataCenter = data;
            self._render();
        }
    }

    ajk.Autocomplete.prototype._render = function(){   
        this.wrap.html(this.op.template(this.dataCenter));
        this.resetCursored();
        if(this.wrap.find(this.op.itemSelector).length > 0){
            this.show();
        }else{
            this.hide();
        }
    }

    ajk.Autocomplete.prototype.show = function(){
        this.wrap.show();
    }

    ajk.Autocomplete.prototype.hide = function(){
        this.wrap.hide();
    }

    ajk.Autocomplete.prototype.resetCursored = function(){ 
        this.cursorIndex = -1;
        this.wrap.find(this.op.itemSelector).removeClass(this.op.cursorClass);
    }
    
    ajk.Autocomplete.prototype.cursor = function(optNum ,isCal){ 
        var self    = this, _index, $item,itemObj = {},
            _isCal  = arguments[1] === undefined? false: arguments[1],
            _items  = self.wrap.find(self.op.itemSelector);
        if( !_isCal ){
            _index  = optNum;
        }
        else{
            _index  = self.cursorIndex + optNum;
            if(_index  > _items.length - 1){ _index = 0; }
            else if(_index < 0){ _index = _items.length - 1; }
        }
        $item   = _items.eq(_index);
        itemObj = {
            index : _index,
            item  : $item,
            data  : self.dataCenter[_index]
        };
        self.cursorIndex = _index;
        if( self.trigger('cursored',[itemObj]) !== false){
            _items.removeClass(self.op.cursorClass);
            $item.addClass(self.op.cursorClass);
        }

    }
    ajk.Autocomplete.prototype.select = function($item){ 
        var self    = this,
            _index  = $item.index(),
            itemObj = {
                index : _index,
                item  : $item,
                data  : self.dataCenter[_index]
            };
        var _kw = $item.find(self.op.keySelector).text();
        self.el.val(_kw);
        if(this.trigger('selected',[itemObj]) !== false){
            self.hide();
        }
    }

    ajk.Autocomplete.prototype.input = function(keyword){ 
        if(this.trigger('inputed',arguments) !== false){
            self.keyword = keyword;
            this._updateData();
        }
    }

})(jQuery);