(function($){
	var Nanairo = ajk.MultiUpload = ajk.inherit(ajk.Observer, function(op){
		this.uploader 		 = op.uploader;
		this.boxTemplate 	 = op.boxTemplate;
		this.loadingTemplate = op.loadingTemplate;
		this.wrap            = op.wrap;
		this.maxCount        = op.maxCount;
		this.mainInput       = op.mainInput;

		this._bindEvent();
	});

	Nanairo.prototype._bindEvent = function(){
		var self = this;
		self.uploader.on('select',function(uploadCount){
			$('.img-err').hide();
			var _html = '';
			var _t = self.loadingTemplate();
			for(var i = 0; i < uploadCount ; i++){
				_html += _t;
			}
			self.wrap.find('.uploader-content').before(_html);
			
			/*选择图片时是否发码*/
			var cp = self.wrap.parents(".upload").attr("data-track") || "";
			if(cp!=""){
				var tracker = new SiteTracker("anjuke-npv");
				tracker.setCustomParam("{" + cp + "}" );
				tracker.track();
			}
			
			// self.wrap.find('.remainText').text('还剩'+ (self.uploader.remainLength-uploadCount) +'张');
		});

		self.uploader.on('success',function(res){
			$('.img-err').hide();
			self.wrap.find('.upload-box-loading').remove();
			var data = self._produceObject(res);
			var result = self.addImage(data);
			if( result ){
				self.trigger('add',[data]);
			}
			setTimeout(function(){
				self.checkEnough();
			},0);
			return result;
		});

		self.uploader.on('error',function(r){
			self.wrap.find('.upload-box-loading').remove();
			if(r.status == '1'){ //数量超限
				self.showErr('抱歉，最多只能上传' + self.maxCount + '张图片');
			}else if(r.status == '2'){
				self.showErr('请上传小于3M的图片');
			}else if(r.status == '6'){
				self.showErr('上传失败，图片格式不符合规定');
			}else if(r.status == '4'){
				self.showErr('请上传大于' + self.uploader.op.minwidth+ '*' + self.uploader.op.minheight+ 'px的图片');
			}else{
				self.showErr('图片上传失败，请重试');
			}
			self.checkEnough();
		});

		//删除item
		self.wrap.on('click','.set-delete',function(){
			var item = $(this).parents('.upload-box');
			var id = item.data('id');
			self.deleteById(id);
		});
		 
	}

	//成功时产生对象
	Nanairo.prototype._produceObject = function(response){
		return {
			src : 'http://pic1.ajkimg.com/display/anjuke/' + response.image.id + '/100x75c.jpg',
			exif : JSON.stringify(response.image),
			id : response.image.id,
			host : response.image.host
		};
	}

	//检查图片是否存在
	Nanairo.prototype._checkUnique = function(item){
		var id = item.id;
		return $(".upload-pictures").find('[data-id="' + id + '"]').length == 0;
	}

	Nanairo.prototype.checkList = function(){
		var list = this.wrap.find('.upload-box');
		var arr = [];
		if(list.length <= 1){
			list.find('.set-prev,.set-next').hide();
		}else{
			list.find('.set-prev,.set-next').show();
			list.eq(0).find('.set-prev').hide();
			list.eq(list.length - 1).find('.set-next').hide();
		}
		list.each(function(){
			arr.push({
				src: $(this).find('img').attr('src'),
				id: $(this).data('id'),
				exif: $(this).find('.hideupd').val()
			});
		});
		return arr;
	}

	Nanairo.prototype.checkEnough = function(){
		// this.wrap.find('.remainText').text('还剩'+ this.uploader.remainLength +'张');
		if(this.uploader.remainLength == 0){
			this.wrap.find('.uploader-main').hide();
		}else{
			this.wrap.find('.uploader-main').show();
		}
	 
	}

	Nanairo.prototype.addImage = function(item){
		var self = this;

		if( self.uploader.remainLength <= 0){
			self.showErr('抱歉，最多只能上传' + self.maxCount + '张图片');
			return false;
		}

		if( self._checkUnique(item) ){
			var _html = self.boxTemplate(item);
			self.wrap.find('.uploader-content').before(_html);
			self.checkEnough();
			return true;
		}else{
			var currentLength = self.uploader.remainLength;
			self.showErr('已经上传该图片，不能重复上传');
			return false;
		}
	}

	Nanairo.prototype.showErr = function(msg){
        $('.img-err').show().find('em').html(msg);
        return false;
    }

	Nanairo.prototype.deleteById = function(delIds){
		var self = this;
		if( !delIds ){
			return;
		}
		var _ids = _.isArray(delIds)? delIds:[delIds];

		_.each(_ids,function(id,key){
			var delItem = self.wrap.find('[data-id="'+id+'"]');
			if( delItem.length > 0 ){
				delItem.remove();
				self.uploader.setImageUploadsSize( self.uploader.remainLength-0 + 1);
			}
			self.checkEnough();
		});
	}

})(jQuery);

