<?php

class Pc_Ui_Upload_MultiUploadComponent extends User_Component_AbstractComponent
{

    public static function use_boundable_styles()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "MultiUpload.css");
    }

    public static function use_boundable_javascripts()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "MultiUpload.js");
    }

    public function getView()
    {
        $request = APF::get_instance()->get_request();

        $pageParams = $request->get_attributes();

        foreach ($pageParams as $k => $v) {
            $this->assign_data($k, $v);
        }
        return "MultiUpload";
    }

    public static function use_component()
    {
        $returnArr = array(
            'Pc_Ui_Upload_ImageUpload'
        );

        return array_merge(parent::use_component(), $returnArr);
    }
}