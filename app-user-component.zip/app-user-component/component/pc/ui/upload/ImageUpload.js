;
(function($, ajk) {
    ajk.flashChecker = function() {
        var hasFlash = 0, // 是否安装了flash
            flashVersion = 0, // flash版本
            swf,
            VSwf;

        try {
            // ie
            swf = new ActiveXObject('ShockwaveFlash.ShockwaveFlash');
            if (swf) {
                hasFlash = 1;
                VSwf = swf.GetVariable("$version");
                flashVersion = parseInt(VSwf.split(" ")[1].split(",")[0]);
            }
        } catch (e) {
            // 非ie
            if (navigator.plugins && navigator.plugins.length > 0) {
                swf = navigator.plugins["Shockwave Flash"];
                if (swf) {
                    hasFlash = 1;
                    var words = swf.description.split(" ");
                    for (var i = 0, l = words.length; i < l; ++i) {
                        if (isNaN(parseInt(words[i]))) continue;
                        flashVersion = parseInt(words[i]);
                    }
                }
            }
        }
        if (hasFlash === 1 && flashVersion >= 10) {
            return true;
        } else {
            return false;
        }
    };
    var imageUtils = {
            isInstallFlash: ajk.flashChecker(),
            isSupportXhrFileUpload: !!(window.ProgressEvent && window.FileReader),
            isSupportFormData: !!window.FormData,
            isSupportMultiUpload: 'multiple' in document.createElement('input')
        },
        imageStatus = {
            success: 0, // 成功
            length: 1, // 长度
            size: 2, // 文件大小不合格
            security: 3, // 权限不足
            graphics_size: 4, // 图像大小
            support: 5, // 功能不支持
            file_type:6, // 图片类型不正确
            defaults: 10 // 其他错误
        };
    ajk.ImageUpload = ajk.inherit( ajk.Observer, function(op) {
        var defaults = {
            fileDataName: 'file',
            multi: true,
            auto: false,
            multiLength: 10, // 多图上传数量
            sizeLimit: 3145728, // 图片总大小k;3145728(3M)
            fileDesc: '',
            fileExt: '*.jpg;*.JPG;*.png;*.PNG;*.jpeg;*.JPEG;',
            width: 144,
            height: 109,
            // scriptData:'',
            buttonText: '文件上传',
            simUploadLimit: 20, // 每次同步上传数量
            queueID: '',
            fileType: 'image',
            buttonImg: '', // flash 上传按钮图片 
            cancelImg: '',
            minSize: null,
            maxSize: null,
            minheight: null, // 图片最小高度
            minwidth: null, // 图片最小宽度
            model:0 // 默认flash
        };
        this.op = $.extend({}, defaults, op);
        this.status = true;
        // 模式
        this.model = this.op.model;
        this.remainLength = this.op.multiLength; // 还可上传多少张
        this.dom = $(this.op.target);
        this._init();
    });
    ajk.ImageUpload.prototype = $.extend({}, ajk.ImageUpload.prototype , {
        constructor: ajk.ImageUpload,
        switchServer: function(url) { // 设置图片上传地址
            this.op.uploader = url;
            this._init();
        },
        setImageUploadsSize: function(size) { // 设置多图上传图片数量
            this.op.multiLength = size;
            this.remainLength = size;
        },
        setUploadImageStatus: function(status) { // 设置是否开启上传
            var st = 'disable';
            this.status = status;
            if (imageUtils.isInstallFlash === false) {
                if (status) {
                    st = 'enable';
                }
                this.dom.fileupload(st);
            }
        },
        switchModle: function(model) {
            // model 0:flash,1:javascript
            this.model = model;
            this._init();


            if (model === 0) {
                if (imageUtils.isInstallFlash === false) {
                    this.trigger('error', [{
                        status: imageStatus.support
                    }]);
                }
            } else {
                this._javasciptUpload();
            }
        },
        getRemainUploadImageSize: function() { // 获取还可以上传多少
            return this.remainLength;
        },
        _init: function() {
            // 移除之前初始化内容
            this.dom.off();
            this.dom.siblings('object').remove();

            // 上传优先级 flash >  other
            if (imageUtils.isInstallFlash && this.model === 0) {
                this._flashUpload();
                return;
            } else {
                this._javasciptUpload();
            }
        },
        _javasciptUpload: function() {
            var _this = this;

            var _id = _this.dom.attr('id');
            var uploadOption = {
                url: _this.op.uploader,
                secureuri: false,
                rt: _this.op.redirect,
                dataType: 'json',
                fileElementId: _this.dom.attr('id'),
                success:function(data,status){
                    _this.checkFileInfo(data);
                },
                error:function(){
                    _this.trigger('error', [{
                        status: imageStatus.defaults
                    }]);
                },
                complete:function(){
                    _this.dom.replaceWith('<input type="file" id="'+_id+'" name="file" value="上传图片" accept="image/*" />');
                    $('#'+_id).change(function(){
                        $.ajaxFileUpload(uploadOption);
                    });
                }
            }

            _this.dom.change(function(){
                if(_this.checkFileLength(1) === false){
                    return 
                }else{
                    $.ajaxFileUpload(uploadOption);
                }
            });
            _this.dom.show();
        },
        _flashUpload: function() {
            var _this = this;
            this.dom.uploadify({
                uploader: _this.op.swfUrl,
                script: _this.op.uploader,
                scriptAccess: 'always',
                fileDataName: _this.op.fileDataName,
                multi: _this.op.multi,
                auto: _this.op.auto,
                sizeLimit: _this.op.sizeLimit,
                fileDesc: _this.op.fileext,
                fileExt: _this.op.fileext,
                width: _this.op.width,
                height: _this.op.height,
                // scriptData:'',
                buttonText: _this.op.buttonText,
                simUploadLimit: _this.op.simUploadLimit,
                queueID: _this.op.queueID,
                fileType: _this.op.fileType,
                buttonImg: _this.op.buttonImg,
                cancelImg: _this.op.cancelImg,
                onInit: function() {
                    // console.log('init');
                    // console.log(arguments);
                },
                onSelect: function(event, obj) {
                    // TODO
                    //_this.trigger('select', arguments);                
                },
                onComplete: function(event, queueID, fileObj, response, data) {
                    var d = $.parseJSON(response);
                    _this.checkFileInfo(d);
                },
                onError: function(event, queueID, fileObj, errorObj) {
                    var errorType = errorObj.type,
                        status = 0;
                    switch (errorType) {
                        case "File Size":
                            status = imageStatus.size;
                            break;
                        case "Security":
                            status = imageStatus.security;
                            break;
                        default:
                            status = imageStatus.defaults;
                            break;
                    };
                    _this.dom.uploadifyCancel(queueID);
                    // 图片大小信息待确定
                    _this.trigger('error', [{
                        status: status
                    }]);
                },
                onAllComplete: function() {
                    // console.log('onAllComplete', arguments);
                    // TODO 
                },
                onQueueFull: function(event, queueSizeLimit) {
                    _this.trigger('error', [{
                        status: imageStatus.defaults
                    }]);
                },
                onSelectOnce: function(event, obj) {
                    // console.log('select', arguments);
                    if (_this.status === false) {
                        return;
                    }
                    if (_this.checkFileLength(obj.fileCount) === false) {
                        return false
                    }
                    // obj 数据格式
                    // obj = {
                    //     allBytesTotal: 522804
                    //     fileCount: 3
                    //     filesReplaced: 0
                    //     filesSelected: 3
                    // }
                    _this.dom.uploadifyUpload();
                }
            });
        },
        checkFileInfo: function(d) {

            if ( !d || d.status !== 'ok' ) {
                this.trigger('error', [{
                    status: imageStatus.defaults
                }]);
                return false;
            }

            if( this.op.fileExt.indexOf(d.image.format) == -1 ){
                this.trigger('error', [{
                    status: imageStatus.file_type
                }]);
                return;
            }

            if (this.op.minheight && this.op.minwidth > 0) {
                if (d.image.width < this.op.minwidth || d.image.height < this.op.minheight) {
                    if (imageUtils.isInstallFlash) {
                        this.dom.uploadifyCancel(this.op.queueID);
                    }
                    this.trigger('error', [{
                        status: imageStatus.graphics_size
                    }]);
                    return false;
                }
            }

            // 文件大小验证
            if (this.op.minSize > 0  ||  this.op.maxSize > 0) {
                if (d.image.size <= this.op.minSize || d.image.size >= this.op.maxSize) {
                    if (imageUtils.isInstallFlash) {
                        this.dom.uploadifyCancel(this.op.queueID);
                    }
                    this.trigger('error', [{
                        status: imageStatus.size
                    }]);
                    return false;
                }
            }
            
            if( this.trigger('success', [d]) !== false ){
                this.remainLength--;
            }
        },
        checkFileLength: function(current) {
            if (this.remainLength <= 0) {
                if (imageUtils.isInstallFlash) {
                    this.dom.uploadifyClearQueue();
                }
                this.trigger('error', [{
                    status: imageStatus.length,
                    limit: this.remainLength,
                    current: current
                }]);
                return false;
            }

            if (current > this.remainLength) {
                if (imageUtils.isInstallFlash) {
                    this.dom.uploadifyClearQueue();
                }
                this.trigger('error', [{
                    status: imageStatus.length,
                    limit: this.remainLength,
                    current: current
                }]);
                return false;
            }

            // 参数待定
            if (this.trigger('select', [current]) === false) {
                return false;
            }
            return true;
        }
    });
    ajk.ImageUpload.Utils = imageUtils;
    ajk.ImageUpload.Status = imageStatus;
})(jQuery, ajk);