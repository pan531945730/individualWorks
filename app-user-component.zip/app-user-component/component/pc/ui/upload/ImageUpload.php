<?php

class Pc_Ui_Upload_ImageUploadComponent extends User_Component_AbstractComponent {

    public static function use_boundable_javascripts() {
        $path = apf_classname_to_path(__CLASS__);
        return array($path."ImageUpload.js");
    }

    public function getView() {
        return false;
    }


    public static function use_javascripts() {
        return array_merge(
            parent::use_javascripts(),
            array(
                // array(PageHelper::pure_static_url("/js/jquery-1.7.2.min.js"), PHP_INT_MAX),
                User_Common_Util_PageHelper::getPureStaticUrl("/js/uploadify-3.1/ajaxfileupload.js"),
                // PageHelper::pure_static_url('/swf/uploadify-3.2.1/jquery.uploadify.min.js'),
                User_Common_Util_PageHelper::getPureStaticUrl('/swf/uploadify-2.1.0/swfobject.js'),
                User_Common_Util_PageHelper::getPureStaticUrl('/js/jquery-1.3.2/jquery.uploadify.v2.1.0.min.fv9.js'),
                

                // PageHelper::pure_static_url('/js/jquery-file-upload-9.11.2/js/vendor/jquery.ui.widget.js'),
                // PageHelper::pure_static_url('/js/jquery-file-upload-9.11.2/js/jquery.iframe-transport.js'),
                // PageHelper::pure_static_url('/js/jquery-file-upload-9.11.2/js/jquery.fileupload.js')
            )
        );
    }
}