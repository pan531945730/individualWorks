APF.Namespace.register('ajk');
(function($){
	ajk.Carousel = ajk.inherit(ajk.Observer,function(op){
		var _default = {
			baseBox       : '',
			carouselBox   : '#ajk-carouselBox',
			items         : '#ajk-carouselBox>li',
			axis          : 'x', //or y
			autoplay      : false,
			autoplayTime  : 2000,
			autoplayOrder : 'next', // or prev
			animationTime : 500,
			pace          : 2, //每次移动的步长
			visiable      : 2 //可视区域内的数量
		};
		this.op          = $.extend({}, _default, op);
		this.baseBox     = $(this.op.baseBox);
		this.carouselBox = $(this.op.carouselBox);
		this.items       = $(this.op.items);
		this.styles      = {};
		this.init();
	});
	ajk.Carousel.prototype.init = function(){
		var isHorizontal = this.op.axis === 'x';
		this.sizeLabel   = isHorizontal? 'Width':'Height';
		this.posiLabel   = isHorizontal? 'left' :'top';
		this.singleSize  = this.items['outer' + this.sizeLabel](true); //单个长度
		this.itemsLength = this.items.length;
		this.totalSize   = this.singleSize * this.itemsLength; //总长度
		this.extraItems  = this.itemsLength % this.op.visiable;	//余数 		
		this.baseBox.css('overflow', 'hidden');
		this.carouselBox.css('position','relative').css(this.posiLabel,'0').css(this.sizeLabel.toLowerCase(), this.totalSize);
		this.moveIndex   = 0;
		this.itemIndex   = 0;
		this.nowPosition = 0;
		this.interval    = null;
		this.isMoving    = false;
		if(this.op.autoplay){this.autoplay();}
	}
	ajk.Carousel.prototype.move = function(_index){ //从第0个开始
		var self = this , _itemIndex = [];
		self.isMoving = true;
		_itemIndex.push(self.itemIndex);
		self.trigger('move', _itemIndex);
		self.moveIndex = self.checkIndex(_index);
		self.styles[self.posiLabel] = self.nowPosition = -self.moveIndex * self.singleSize;
		self.carouselBox.animate(self.styles,{
			duration: self.op.animationTime,
			complete: function(){
				self.isMoving = false;
			}
		});
	}
	ajk.Carousel.prototype.toPage = function(_pageIndex){ //从第0页开始
		this.trigger('topage');
		this.stopAutoplay();
		if( _pageIndex > Math.ceil(this.itemsLength / this.op.visiable) - 1){return;} 
		this.move( _pageIndex * this.op.visiable);
	}
	ajk.Carousel.prototype.checkIndex = function(_index){
		_index = isNaN(_index)? 0: _index;
		while( _index < 0 ){
			_index += this.itemsLength;
		}
		if( _index >= this.itemsLength){
			_index = _index % this.itemsLength;
		}
		return _index;
	}
	ajk.Carousel.prototype.next = function(){
		if(!this.isMoving){
			this.trigger('next');
			this.itemIndex = this.checkIndex(this.itemIndex + this.op.pace);
			this.checkNext();
			this.move(this.moveIndex + this.op.pace);
		}
	}
	ajk.Carousel.prototype.prev = function(){
		if(!this.isMoving){
			this.trigger('prev');
			this.itemIndex = this.checkIndex(this.itemIndex - this.op.pace);
			this.checkPrev();
			this.move(this.moveIndex - this.op.pace);
		}
	}
	ajk.Carousel.prototype.checkNext = function(){
		var _lastVis = this.moveIndex + this.op.visiable - 1;
		if((this.itemsLength - 1) - _lastVis < this.op.pace ){
			this.styles[this.posiLabel] = this.nowPosition + this.singleSize * this.op.pace;
			this.carouselBox.append($(this.op.items).slice( 0, this.op.pace )).css(this.styles);
			this.moveIndex -= this.op.pace;
		}
	}
	ajk.Carousel.prototype.checkPrev = function(){
		var _firstVis = this.moveIndex;
		if( this.moveIndex < this.op.pace +1){
			this.styles[this.posiLabel] = this.nowPosition - this.singleSize * this.op.pace;
			this.carouselBox.append($(this.op.items).slice( 0, this.itemsLength - this.op.pace )).css(this.styles);
			this.moveIndex -= (this.itemsLength - this.op.pace);
		}
	}
	ajk.Carousel.prototype.autoplay = function(){
		var self = this, func;
		if(self.op.autoplayOrder == 'next'){func = function(){self.next();}}
		else if(self.op.autoplayOrder == 'prev'){func = function(){self.prev();}}
		else{ return;}
		self.interval = setInterval(func,self.op.autoplayTime);
	}
	ajk.Carousel.prototype.stopAutoplay = function(){
		clearInterval(this.interval);
	}
})(jQuery);