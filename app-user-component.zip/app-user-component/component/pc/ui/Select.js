/*
    var roller = new ajk.Roller({
        boxId    : 'prePay',    //包含块Id,必填项
        zcord    : 1,           //包含块的z-index，用于调整多个下拉框次序
        title    : '下拉菜单',  //默认下拉框显示文案
        trigger  : 'mouseover mouseleave',          //下拉触发方式(默认'click')
        onchange : function(){location.reload()},   //onchange事件
    });
    roller.val(8);           //返回或设置value
    roller.valid(true);      //启用或禁用下拉框
    roller.reset([           //重置组件选项
        {
            value : '1',
            desc  : '选项1'
        },
        {
            value : '2',
            desc  : '选项2'
        },
        {
            value : '3',
            desc  : '选项3'
        },
        {
            value : '4',
            desc  : '选项4'
        },
        {
            value : '5',
            desc  : '选项5'
        }
    ]);
*/


APF.Namespace.register('ajk');
(function($){
    var Exia = ajk.Roller = ajk.inherit(ajk.Observer,function(settings){
        var containerTpl = 
        '<div class="exia-box" style="height:<%= height %>px">' +
            '<div class="sol-label">' +
                '<span data-val="" data-title="<%= title %>" style="height:<%= height %>px"><%= title %>' +
                '</span><i style="top:<%= top %>px" class="icon icon-seldown"></i>' +
            '</div>' +
            '<ul style="width:<%= width %>px;top:<%= height %>px;"></ul>' +
        '</div>';
        var itemTpl    = '<li style="height:<%= height %>px;line-height:<%= height %>px;" data-val="<%= value %>"><%= desc %></li>';
        var selectTpl  = '<option value="<%= value %>"><%= desc %></option>';
        this.op = $.extend({
            boxId     : 'selectbox',
            zcord     : 1,
            trigger   : 'click',
            title     : undefined,
            onchange  : undefined,
            crTpl     : _.template(containerTpl),
            imTpl     : _.template(itemTpl),
            slTpl     : _.template(selectTpl),
            rrClass   : 'exia-box',
            teClass   : 'exia-light',
            downClass : 'icon-seldown',
            upClass   : 'icon-selup',
            liClass   : 'li-over',
            liStClass : 'li-static',
            labelClass: 'sol-label',
            resetValue: undefined,
            triggerChange: true,
            onchange  : function(){}
        },settings);
        this.effective = true;
        this.container = $('#'+ this.op.boxId);
        this.originSel = this.container.find('select');
        this.initial();
    });
    
    Exia.prototype.initial = function(){
        this.drawRoller();
        this.bindEvent();
        this.press(0,true);
    }

    Exia.prototype.drawRoller = function(){
        var self = this, box = this.container, 
            select = box.children('select'),
            rrClass = self.op.rrClass;
        var inHeight = box.innerHeight() - 2;
        var inWidth  = box.innerWidth() -2;
        var top = Math.ceil((inHeight - 7)/2);
        var crHtml = self.op.crTpl({
            value  : select.val(),
            title  : self.op.title||select.find('option:first').text(),
            height : inHeight,
            width  : inWidth,
            top    : top
        });
        box.append(crHtml);
        var listHtml = '';
        select.children('option').each(function(i,obj){
            var value = $(obj).prop('value'),
                desc  = $(obj).text();
            listHtml += self.op.imTpl({
                height : inHeight + 2,
                desc   : desc,
                value  : value
            });
        });
        box.find('.'+rrClass+' ul').append(listHtml);
    }

    Exia.prototype.bindEvent = function(){
        var self    = this;
        var box     = this.container;
        var rrClass = self.op.rrClass;
        var roller  = box.find('.'+rrClass);
        roller.bind(self.op.trigger,function(evt){
            var target = $(evt.srcElement || evt.target);
            if(evt.type=='mouseout'||evt.type=='mouseleave'&&!roller.find('ul').is(':visible')) return;
            //if(!self.effective||target.is('ul')||target.is('li')) return;
            roller.find('ul').is(':visible') ?
            box.css('zIndex',self.op.zcord) :
            box.css('zIndex','999');
            roller.find('i').toggleClass(self.op.downClass+' '+self.op.upClass);
            roller.find('ul').toggle();
            roller.toggleClass(self.op.teClass);
        });
        box.on('click','.'+rrClass+' li',function(evt){
            self.handlePress($(this));
            
        });
        box.on('mouseover mouseleave','.'+rrClass+' li',function(evt){
            $(this).toggleClass(self.op.liClass);
        });
        if(self.op.trigger == 'click'){
            $('body').on('click',function(evt){
                var target = $(evt.srcElement || evt.target);
                if(!target.parents('#'+self.op.boxId).length 
                    && !target.is('#'+self.op.boxId)
                    && roller.find('ul').is(':visible'))
                self.shrink();
            });
        }
    }

    Exia.prototype.shrink = function(){
        var self    = this;
        var box     = this.container;
        var rrClass = self.op.rrClass;
        var roller  = box.find('.'+rrClass);
        box.css('zIndex',self.op.zcord);
        roller.children('ul').hide();
        roller.removeClass(self.op.teClass);
        roller.find('i').removeClass(self.op.upClass).addClass(self.op.downClass);
    }

    Exia.prototype.handlePress = function(liObj,doNotTrigger){
        var self    = this;
        var box     = this.container;
        var rrClass = self.op.rrClass;
        var roller  = box.find('.'+rrClass);
        var li = liObj, desc = li.text(), value = li.attr('data-val');
        if(self.op.resetValue&&self.op.resetValue==value) desc = self.op.title;
        roller.find('.'+self.op.labelClass+' span').attr('data-val',value).html(desc);
        li.siblings().removeClass(self.op.liStClass);
        li.addClass(self.op.liStClass);
        self.originSel.val(value);
        if(self.op.triggerChange){
            self.originSel.change();
        }
        !doNotTrigger && self.op.onchange(value);
        self.shrink();
    }

    Exia.prototype.press = function(index,doNotTrigger){
        var self    = this;
        var box     = this.container;
        var rrClass = self.op.rrClass;
        var roller  = box.find('.'+rrClass);
        self.handlePress(roller.children('ul').find('li:eq('+index+')'),doNotTrigger);
    }

    Exia.prototype.valid = function(flag){
        this.effective = flag;
    }

    Exia.prototype.val = function(value,doNotTrigger){
        var self = this, box = this.container,
            labelClass = self.op.labelClass, label = box.find('.'+labelClass);
        if(value != undefined){
            label.next().find('li').each(function(i,obj){
                if($(obj).attr('data-val')==$.trim(value)){
                    self.press(i,doNotTrigger);
                }
            });
            return self;
        }else{
            return label.children('span').attr('data-val');
        }
    }

    Exia.prototype.reset = function(dataObj){
        var listHtml = '', selHtml = '';
        var box = this.container;
        var liHeight = box.innerHeight();
        var labelClass = this.op.labelClass;
        var label = box.find('.'+labelClass);
        for(var i = 0; i < dataObj.length; i++){
            listHtml += this.op.imTpl({
                height: liHeight,
                value : dataObj[i].value,
                desc  : dataObj[i].desc
            });
            selHtml  += this.op.slTpl({
                value : dataObj[i].value,
                desc  : dataObj[i].desc
            });
        }
        label.children('span').attr('data-title',dataObj[0].desc);
        label.next().html(listHtml);
        this.originSel.html(selHtml);
        this.press(0);
    }

})(jQuery);

