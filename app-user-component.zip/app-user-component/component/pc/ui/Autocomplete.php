<?php
class Pc_Ui_AutocompleteComponent extends User_Component_AbstractComponent {
    
    public function getView() {

        return "";
    }

    public static function use_boundable_styles()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array_merge(
            parent::use_boundable_styles(),
            array($path . "Autocomplete.css")
        );
    }

    public static function use_boundable_javascripts()
    {
        $path = apf_classname_to_path(__CLASS__);
        $js = array_merge(
            parent::use_boundable_javascripts(),
            array($path."Autocomplete.js")
        );
        return $js;
    }

}
