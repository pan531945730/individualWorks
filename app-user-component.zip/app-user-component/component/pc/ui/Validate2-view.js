;(function(){
    var errorMessage = {};

    var upDateMessage = function(name,msg){
        errorMessage[name] = msg;
    }

    var findMsgPlace = function(name){
        return $('[data-msgfor]').filter(function(index) {
            var _this = $(this);
            var _conf = _this.data('msgfor').split(',');
            return $.inArray(name,_conf) > -1;
        });
    }

    var getMsg = function(name){
        var msgPlace = findMsgPlace(name);
        var showMsg = '';

        if( msgPlace.length <= 0 ){
            throw('表单验证展示错误：'+name+'字段找不到信息提示框(通过在标签上添加属性 data-msgfor 设置)');
        }

        var config = msgPlace.data('msgfor').split(',');

        var _config = _.filter(config,function(item){
            if( showMsg == '' && errorMessage[ item ] ){
                showMsg = errorMessage[ item ];
            }
            var _dom = $('[name="'+item+'"]');
            // 如果元素不存在，或者元素无需填写，则不算在消息展示队列中。
            return !(_dom.length <= 0 || _dom.prop('disabled'));
        });

        return {
            msg:showMsg,
            place:msgPlace,
            placeTarget:_config
        }
    }

    var showMessage = function(name, checkList){
        var msgData = getMsg(name);
        var hasNotChecked = false;

        for( var i = 0; i < msgData.placeTarget.length; i++ ){
            if( errorMessage[ msgData.placeTarget[i] ] === undefined ){
                hasNotChecked = true;
                break;
            }
        }

        var msg = '';
        if( msgData.msg.length > 0 ){
            msg += '<i class="icon ico-hint"></i>' + msgData.msg;
            msgData.place.addClass('ui-tips-fail-noborder').removeClass('ui-tips-success-noborder');
        }else if(!hasNotChecked){
            //msg += '<i class="iconfont">&#xE003;</i>';
            msgData.place.addClass('ui-tips-success-noborder').removeClass('ui-tips-fail-noborder');
        }
        msgData.place.html(msg).show();
    }

    $.extend(ajk.Validate._config_,{
        singleHandle:function(result){
            var name = typeof result.dom == 'string'? result.dom : result.dom.attr('name');
            if( result.status == 'success' || result.status == 'error' ){
                if( result.status == 'success' ){
                    upDateMessage(name,'');
                }else{
                    upDateMessage(name,result.msg);
                }

                showMessage(name, this._checkList);

                var _action = ({
                    success:'removeClass',
                    error:'addClass'
                })[result.status];

                if( typeof result.dom != 'string' ){
                    result.dom[ _action ]('ui-form-input-error');
                }
            }

            if( result.status == 'reset' ){
                if( typeof result.dom != 'string' ){
                    result.dom.removeClass('ui-form-input-error');
                }
                upDateMessage(result.name,undefined);
                showMessage(name, this._checkList);
            }
        }
    });
})();
