APF.Namespace.register('ajk');
(function(){
    var DropDown;
    ajk.DropDown = DropDown = ajk.inherit(ajk.Observer,function(target,list,op){
        var self = this;
        self._op = $.extend({},{
            timer:500
        },op||{})

        self._target = target;
        self._list = list;
        self._timer;
        self.isOpen = false;
        self._bindEvent();
    });

    DropDown.prototype._bindEvent = function() {
        var self = this;

        var delayClose = function(){
            self._timer = setTimeout(function(){
                self.close();
            },self._op.timer);
        }

        self._target.on('mouseenter',function(){
            if( !self.isOpen ){
                self.open();
            }
        });

        self._target.on('mouseleave',function(){
            if( self.isOpen ){
                delayClose();
            }
        });

        self._list.on('mouseenter',function(){
            clearTimeout(self._timer);
        });

        self._list.on('mouseleave',function(){
            if( self.isOpen ){
                delayClose();
            }
        });

        self._list.on('click',function(){
            self.close();
        });
    };

    DropDown.prototype.open = function() {
        var self = this;
        if( self.trigger('open',arguments) !== false ){
            self.isOpen = true;
            self._list.show();
        }
    };

    DropDown.prototype.close = function() {
        var self = this;
        if( self.trigger('close',arguments) !== false ){
            self.isOpen = false;
            self._list.hide();
        }
    };
})();