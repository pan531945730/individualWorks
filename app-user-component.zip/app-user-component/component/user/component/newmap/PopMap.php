<?php

class User_Component_Newmap_PopMapComponent extends User_Component_AbstractComponent
{

    public static function use_component()
    {
        return array_merge(
            parent::use_component(), array(
            )
        );
    }

    public static function use_javascripts()
    {
        return array_merge(
            parent::use_javascripts(),
            array(
                'http://api.map.baidu.com/getscript?v=1.6&ak=AB8715ae10c67feb78fea33787b1f974',
            )
        );
    }

    public static function use_boundable_javascripts()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array(
            $path."iscroll.js",
            $path . "PopMap.js"
            );
    }

    public static function use_boundable_styles()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "PopMap.css");
    }

    public function getView()
    {

        $map_url = $this->get_param("comm_map_url");
        $this->assign_data("map_url",$map_url);
        return "PopMap";
    }

}

