<?php

class User_Component_Community_FilterCondition_CommunityFilterConditionComponent extends User_Component_AbstractComponent
{

    public static function use_component()
    {
        return array_merge(
            parent::use_component(), array(
            )
        );
    }

    public static function use_boundable_styles()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "CommunityFilterCondition.css");
    }

    public static function use_boundable_javascripts()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array(
            $path . "CommunityFilterCondition.js"
        );
    }

    public function getView()
    {
        return 'CommunityFilterCondition';
    }


}
