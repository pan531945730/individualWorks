J.ready(function() {
    var lifeCon = J.g('life_box');
    var mapTitle = J.g('map_tab_title');
     var life_json = {
         "traffic": {
             "name": "交通",
             "score": 4,
             "distance": "步行15分钟内的公交设施",
             "tip": "本评分根据交通种类、数量、距离等因素计算得出",
             "attr": {
                 "metro_station": "个地铁站",
                 "bus_station": "个公交站"
             }
         },
         "school": {
             "name": "教育",
             "score": 4,
             "distance": "1公里范围内的学校",
             "tip": "本评分根据附近学校的种类、数量、距离等因素计算得出",
             "attr": {
                 "middlel": "所中学",
                 "junior": "所小学",
                 "nursery": "所幼儿园"
             }
         },
         "hospital": {
             "name": "医疗",
             "score": 4,
             "distance": "5公里范围内的医疗机构",
             "tip": "本评分根据医院的级别、种类、性质、数量、距离等因素计算得出",
             "attr": {
                 "level_three": "所三级医院",
                 "level_tow": "所二级医院",
                 "level_one": "所一级医院",
                 "level_comm": "所普通医院"
             }
         },
         "commerce": {
             "name": "商业",
             "score": 4,
             "distance": "步行15分钟内的商业设施",
             "tip": "本评分根据银行/餐饮/超市的数量、距离等因素计算得出",
             "attr": {
                 "restaurant": "个餐馆",
                 "bank": "个银行和ATM机",
                 "supermarket": "个超市"
             }
         }
     };

     function stopBubble(e) {
         if (e && e.stopPropagation) {
             e.stopPropagation();
         } else {
             window.event.cancelBubble = true;
         }
     };

     function getLifeDetial() {
         var commid = comm_info.comm_id;
         var cityid = city_id,
             url = anjuke_city_url || ''; //跨域
         var life_url = url + '/v3/ajax/nearby/?commid=' + commid + '&cityid=' + cityid;
         //        var life_url = '/?commid=' + commid + '&cityid=' + cityid;

         J.get({
             url: life_url,
             cache: false,
             type: "jsonp",
             callback: 'life_url_callback'
         });

         life_url_callback = function(data) {
             //data ={"status":"true","result":{"traffic":{"name":"\u4ea4\u901a","score":0,"distance":1000,"attr":{"metro_station":2,"bus_station":19}},"school":{"name":"\u5b66\u6821","score":0,"distance":"3000","attr":{"nursery":0,"junior":1,"middlel":0}},"hospital":{"name":"\u533b\u9662","score":0,"distance":"3000","attr":{"level_three":0,"level_tow":3,"level_one":1,"level_comm":15}},"commerce":{"name":"\u5546\u4e1a","score":0,"distance":"3000","attr":{"restaurant":346,"bank":96,"supermarket":80}}}}
             if (data && data.status == "true") {
                 buildLifeHtml(data.result);
                 J.g('star_greet').length && (J.g('star_greet').get().style.width = (data.result.greet / 10) * 100 + '%');
                 if (data.result.comfort) {
                     J.g('star_comfort').length && (J.g('star_comfort').get().style.width = (data.result.comfort / 10) * 100 + '%');
                 } else {
                     J.g('comfort_info').hide();
                 }
                 if (data.result.traffic||data.result.hospital||data.result.school||data.result.commerce) {
                     lifeCon && lifeCon.s('.lifeBox').each(function(i, v) {
                         var lifeInfo = v.s('.nlist').eq(0);
                         var lifeGray = v.s('.gray').eq(0);
                         var lifeMap = v.s('.lifeMap').eq(0);
                         var lifeStar = v.s('.p_star_k').eq(0);
                         var lifeTip = v.s('.p_arowCon').eq(0);
                         lifeStar.on('mouseenter', function() {
                             lifeTip.show();
                         })
                         lifeStar.on('mouseleave', function() {
                             lifeTip.hide();
                         })
                         var arrClass = v.attr("data-attr");
                         // buildGrayHtml(arrClass, data["result"][arrClass], lifeGray);
                         buildListHtml(arrClass, data["result"][arrClass]["attr"], lifeInfo, lifeMap);
                         var life_hos = v.s('.lifeMap').eq(0).s('span');
                         if (lifeInfo.html() == "") {
                             lifeInfo.html("较少");
                         }
                         if (lifeMap.html() == "") {
                             lifeMap.html('<span class="ico_none lifex"></span>')
                         }
                         if (life_hos.length > 3) {
                             life_hos.eq(3).hide();
                         }
                     })
                     J.g('life_near_box').show();
                     J.g('mappop_content').length && areaMap.AreaBlock();
                 } else {
                     J.g('life_near_box').hide();
                 }

             } else {
                 J.g('life_near_box').hide();
             }
         }
     }

     function buildLifeHtml(data) {
         var compHtml = "";
         var mapTli = "";
         for (var i in data) {
             if (i != "comfort" && i != "greet") {
                 compHtml += '<div data-attr="' + i + '" class="box item lifeBox ' + i + ' cf">';
                 compHtml += '<div class="nleft fl lifeLife">';
                 compHtml += '<div class="p_title cf">';
                 compHtml += '<h6>' + life_json[i].name + '</h6>';
                 compHtml += '<div class="p_star">';
                 compHtml += '<a class="p_star_k"><em class="p_star_s" style="width:' + ((data[i].score / 10) * 100 || "0") + '%;"></em></a>';
                 compHtml += '<div class="p_arowCon" style="display:none"><p> ' + life_json[i].tip + '</p><em class="p_arw p_arw_b" style="left:15px;bottom:-12px;"></em></div>';
                 compHtml += '</div>';
                 compHtml += '</div>';
                 compHtml += '<p class="gray font-f"> ' + life_json[i]["distance"] + '</p>';
                 compHtml += '<div class="nlist">' + ('' || '较少') + '</div>';
                 compHtml += '<a href="javascript:void(0);" onclick="return false;" data-type="' + i + '" class="btn_detail show_prop">查看详情</a>';
                 compHtml += '</div>';
                 compHtml += '<div class="nright lifeMap fr show_prop" data-type="' + i + '"></div>';
                 compHtml += '</div>';
                 mapTli += '<li id="' + i + '" data-attr="' + i + '">' + life_json[i].name + '</li>';
             }
         }
         lifeCon.length && lifeCon.html(compHtml);
         mapTitle.length && mapTitle.html(mapTli);
     }

     function buildListHtml(index, arr, lifeDom, mapDom) {
         var life_info = [];
         var life_map = [];
         for (var j in arr) {
             if (arr[j] != 0) {
                 life_info.push('<p>' + arr[j] + life_json[index]["attr"][j] + '</p>');

                 if (j == "nursery" || j == "metro_station" || j == "level_three" || j == "restaurant") {
                     life_map.push('<span class="ico1 lifex" data-type="' + index + '"></span>');
                 }
                 if (j == "bus_station" || j == "junior" || j == "level_tow" || j == "bank") {
                     life_map.push('<span class="ico2 lifex" data-type="' + index + '"></span>');
                 }
                 if (j == "middlel" || j == "level_one" || j == "supermarket") {
                     life_map.push('<span class="ico3 lifex" data-type="' + index + '"></span>');
                 }
                 if (j == "level_comm") {
                     life_map.push('<span class="ico4 lifex" data-type="' + index + '"></span>');
                 }
             }
         }
         lifeDom.html(life_info.slice(0, 3).join(""));
         mapDom.html(life_map.slice(0, 3).join(""));
     }
     getLifeDetial();
});
 