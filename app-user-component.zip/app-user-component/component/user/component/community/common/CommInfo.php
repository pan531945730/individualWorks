<?php

class User_Component_Community_Common_CommInfoComponent extends User_Component_AbstractComponent
{

    public function getView()
    {
        $community_info = $this->get_param('community');
        $this->assign_data("comm_base_info", $community_info->base_info);
        $this->assign_data("comm_from", $community_info->base_info);
        $this->assign_data("no_show_rental", $this->get_param('no_show_rental'));
        $this->assign_data("comm_ext_info", $community_info->ext_info);
        $this->assign_data("comm_image_info", $community_info->image_info);
        $this->assign_data("comm_map_info", $community_info->map_info);
        $this->assign_data("from", $community_info->from);
        return 'CommInfo';
    }

    public static function use_component()
    {
        return array_merge(
            parent::use_component(), array(
            )
        );
    }

    public static function use_boundable_styles()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "CommInfo.css");
    }

    public static function use_boundable_javascripts()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array(
            $path . "CommInfo.js"
        );
    }
}

