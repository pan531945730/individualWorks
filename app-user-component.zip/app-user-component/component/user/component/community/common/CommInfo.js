/*小区信息start*/
J.ready(function() {
    var commmap = J.g('commmap');
    if(commmap.length != 0){
        var param = {
            'commid' : link_info.comm_id,
            'rand' : Math.random()
        },
        url = anjuke_city_url || '';
        J.get({
            url: url + '/ajax/communityext/',
            data: param,
            type: 'jsonp',
            callback: 'communityext_callback'
        });
        communityext_callback = function(data){
            if(data && data.comm_propnum){
                var cdata = data.comm_propnum,
                    rentNum = parseInt(cdata.rentNum) || 0,
                    saleNum = parseInt(cdata.saleNum) || 0;
                var rentRate = J.g('rentRate'),
                    sumProp = J.g('sumProp'),
                    tnum = rentNum + saleNum,
                    rrhtml = rentNum/tnum || 0;

                rentRate.length && rentRate.html(parseInt(rrhtml*100)+'%');
                if(pro_type == 1){//ershoufang
                    sumProp.html('(共'+saleNum+'套房源)');
                }else if(pro_type == 2 || pro_type == 3){//zufang
                    sumProp.html('(共'+rentNum+'套租房)');
                } else if(pro_type == 13){//dayezhu
                    sumProp.html('(共'+rentNum+'套房源)');
                }
                J.g('p-phrase-rent-num').html(rentNum);
                J.g('p-phrase-sale-num').html(saleNum);
            }
        };   
    }

});
/*小区信息end*/