<?php

class User_Component_Community_Search_CommunitySearchComponent extends User_Component_AbstractComponent {

    public static function use_boundable_styles()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "CommunitySearch.css");
    }

    public static function use_boundable_javascripts()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array(
            $path . "CommunitySearch.js"
        );
    }

    public static function use_component()
    {
        return array_merge(
            parent::use_component(), array(
            )
        );
    }

    public function getView()
    {
        $this->assign_data('search_info', $this->getSearchInfo());

        return 'CommunitySearch';
    }

    public function getSearchInfo(){

        $city_id = $this->get_param('city_id');

        $search_info = array(
            'btnTxt'     => '找小区',
            'name'       => 'comm',
            'value'      => 3,
            'keyword'    => "请输入小区名或路名…",
            'suggestion' => true,
            'strSuggest' => '',
            'buttonClass'=>'se_community',
            'autoType'   => 8,
            'show_view'  => true,
        );

        $search_info['action']    = '/search';
        $search_info['rd_name']   = 'rd';
        $search_info['kw_name']   = 'k';
        $search_info['city_id']   = $city_id;
        $search_info['btn_name']  = '搜索';

        return $search_info;
    }
}
