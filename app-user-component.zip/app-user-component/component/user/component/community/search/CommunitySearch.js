;(function(){
    try{
        var historyDataLocal= historyData;
    }catch(e){
        historyDataLocal = false;
    }
    function init(){
        var close = J.g('search_close'),
            iptObj = J.g('glb_search');
        if ( historyDataLocal&&historyDataLocal.defaultKW ) {
            iptObj.attr('placeholder', '');
        }
        if(iptObj.length) var autoSearch = searchComplete(iptObj);
        close.on("click",function(){
            //之前发送soj,jock后期更改了方法名以及数据格式
            //J.site.eventTracking({site:'anjuke-npv',page:close.attr('data-tracker')});
            J.site.trackEvent(close.attr('data-tracker'));

            iptObj.val('');
            close.hide();
            autoSearch.hide();
            iptObj.get().focus();
        });

    }
    init();

    function searchComplete(elm){
        var data_type;
        var is_contain_num = null;

        var search = J.g('glbSearch'),
            cid = J.g('currentcityid').val();
        var r = {
            allowEmpty:true,
            width: search.hasClass('forView') ? 348 : 498,
           // width: search.hasClass('forView') ? 340 : 498,
            placeholder: elm.attr('placeholder') ? elm.attr('placeholder').trim() : "",
            params: {
                c:cid,
                n:10,
                g:1
            },
            offset:{
                x: 0,
                y: 0
            },
            type:'json',
            cache:true,
            autoSubmit:false,
            url: '/ajax/indexautocomplete',
            tpl: "autocomplete_ajk",
            toggleClass: "kw_hover",
            //forceClear:false,

            itemBuild:function(item){
                //历史记录 默认文案
                if(this.isDefault&&item.name){
                    //this.isDefault = false;
                    //var region = item.region?('<label style="color: #999;margin-left: 1em;">'+item.region+'</label>'):'',num = item.num ? ('<i style="color: #999">约'+item.num+'套</i>') : '';
                    var region = item.region ? ('<label style="color: #999;margin-left: 1em;">' + item.region + '</label>' + '<i style="color: #999">约' + item.num + '套</i>') : '';

                    return{
                        l:(item.desc ? item.desc : item.name ) + region,
                        v:item.name,
                        isSkip:item.isSkip
                    }
                }

                var number = is_contain_num ?  item.keyword + '<i>约' + item.num + '套</i>' : item.keyword ;
                return {
                    l:number,
                    v:item.keyword
                }
            },
            source: function(params, response,sendHandler){
                //历史记录
                var type = J.g('search_type').val();
                if(type==="1" &&historyDataLocal &&(!elm.val()|| (elm.val().trim()=== historyDataLocal.defaultKW))){
                    this.isDefault = true;
                    var extendObj = {
                        clone : function(obj) {
                            if (typeof (obj) != 'object')
                                return obj;

                            var re = {};
                            if (obj.constructor==Array)
                                re = [];

                            for ( var i in obj) {
                                re[i] = extendObj.clone(obj[i]);
                            }

                            return re;

                        }
                    };
                    var tmp = historyDataLocal;
                    var newhistoryDataLocal = extendObj.clone(tmp);
                    if(newhistoryDataLocal&&newhistoryDataLocal.recentComms && newhistoryDataLocal.recentComms.length){
                        newhistoryDataLocal.recentComms.unshift({
                            name: '<label style="color: #999;">最近看过</label>',
                            isSkip:true
                        });
                    }else{
                        newhistoryDataLocal.recentComms = [];
                    }
                    newhistoryDataLocal.hotComms.unshift({
                        name: '<label style="color: #f60;">热门搜索</label>',
                        isSkip:true
                    });
                    var data = newhistoryDataLocal.recentComms && newhistoryDataLocal.recentComms.concat(newhistoryDataLocal.hotComms);
                    response(data);
                    return;
                }

                this.isDefault = false;


                /*if(elm.attr("placeholder").trim() === elm.val().trim()){
                 return;
                 }*/
                data_type =  J.g('search_type').val();
                var term = params.query;

                params.t = data_type;
                if(params.t != 0){
                    sendHandler.call(this,params,function(data){
                        if(!data){
                            data={
                                is_contain_num:false,
                                list:[]
                            }
                        }
                        is_contain_num = data.is_contain_num; //是否有右侧的个数
                        var data = data.list;
                        data&&response( data);
                    });
                }
            },
            onSelect:function(data){
                elm.val(data.v.replace(/<[^>]+>/g,""));
                if (data.type) {
                    J.g("search_sugg").val(data.type);
                } else {
                    J.g("search_sugg").val("1");
                }
                J.g("global_search_form").submit();
            },

            onFocus:function(elm){
                var type = parseInt(J.g('search_type').val());
                elm.attr("placeholder",'').addClass('kw_hover');
                if (type === 1) {
                    if (historyDataLocal && elm.val() === historyDataLocal.defaultKW) {
                        elm.val('');
                    }
                }
                //if(elm.val()!='') elm.addClass('kw_hover');
                if(true||!elm.val()|| (elm.val().trim()=== elm.attr("placeholder"))){
                    if(elm.val()!='') elm.addClass('kw_hover');
                }
            },

            onBlur:function(){
                var obj = J.g('glb_search');
                obj.removeClass('kw_hover');
                //obj.val(obj.attr('placeholder').trim());
                var type = parseInt(J.g('search_type').val());
                if (type === 1) {
                    if (obj.val() === '' && historyDataLocal) {
                        obj.val(historyDataLocal.defaultKW);
                        return;
                    }
                }
                !elm.val()&&obj.val(obj.attr('placeholder'));
            },

            onKeyUp:function(elm){
                var closeObj = J.g('search_close'),
                    txt = elm.attr('placeholder').trim();
                if(elm.val() !='' && elm.val() != txt){
                    closeObj.show();
                }else{
                    closeObj.hide();
                }
            },

            onChange:function(elm){
                var tmp = elm.v.replace(/<[^>]+>/g,"");
                var obj = J.g('glb_search');
                obj.val(tmp);
            }

        };

        return  elm.autocompleteV2(r);
    }
//    J.g("glb_search")&&J.on(J.g("glb_search").next().next(),'click',function(){
//        var elm = J.g("glb_search");
//        if(!elm.val() || elm.val().trim() === elm.attr("placeholder").trim()){
//            return false;
//        }
//        elm.up(0).submit();
//    })
    /**
     * 页面初始化input中的关闭显示
     */
    J.g("glb_search").length&&(function(){
        var closeObj = J.g('search_close');
        var elm = J.g("glb_search");
        if(elm.val() !='' && elm.val()!= elm.attr("placeholder")){
            closeObj.show();
        }else{
            closeObj.hide();
        }
    })();


}.require(['ui.autocompleteSite'],['ui.autocomplete_ajk'],true));

