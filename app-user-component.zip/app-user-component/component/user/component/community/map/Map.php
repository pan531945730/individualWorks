<?php

class User_Component_Community_Map_MapComponent extends User_Component_AbstractComponent {

    public function getView()
    {
        $this->assign_data("lat", $this->get_param("lat"));
        $this->assign_data("lng", $this->get_param("lng"));
        $this->assign_data("title", $this->get_param("title"));
        return 'Map';
    }

    public static function use_component()
    {
        return array_merge(
            parent::use_component(), array(
            )
        );
    }

    public static function use_boundable_styles()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "Map.css");
    }

    public static function use_boundable_javascripts()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array(
            $path . "Map.js"
        );
    }
}