/*发送到手机js*/ 
J.ready(function() { 
    J.s('.send-mobile')[0] && J.s('.send-mobile').eq(0).on('click', function(e) {
        e.stop();
        if (J.s(".panel_def").length > 0) {
            J.popup.close();
        }
        //@liujie 移除短链接通过异步拿到短信内容并填充展示
        if(pro_type == 13){//大业主
            var url = "/v3/ajax/getMsgSentToPhone/",
                params = {
                    send_type : send_type||0,
                    prop_id : prop_info.prop_id || 0
                },
                imgCodeUrl = '/check/code?cn=haozu&x=120&y=40&s=30&x1=2&y1=46&x2=12&y2=38&t=';
        }
        if(pro_type == 2 || pro_type == 3){//zufang
            var url = "/ajax/getMsgSentToPhone/",
                params = {
                    send_type : send_type||0,
                    prop_id : prop_info.prop_id || 0
                },
                imgCodeUrl = '/check/code?cn=haozu&x=120&y=40&s=30&x1=2&y1=46&x2=12&y2=38&t=';
        }else if(pro_type == 1){//ershoufang
            var url = "/ajax/getToPhoneMsg/",
                params = {
                    prop_id: J.g("send-prop-id").val(),
                    prop_type: J.g("prop-type").val()
                },
                imgCodeUrl = '/seccode?k=seccode&x=101&y=26&s=24&x1=2&y1=30&x2=12&y2=26&t=';
        }
        J.get({
            url: url,
            cache: false,
            type:"json",
            timeout: 20000,
            data: params,
            onSuccess: function(result) {
                if(result.status == 0 && J.g("phoneMsg")){
                    J.g("phoneMsg").html('你将会收到如下信息“ '+result.msg+' ”');
                    J.g("message").val(result.msg);
                    if(pro_type === 1){
                        J.g("message-code").val(result.code);
                    }
                }
            }
        });

        J.popup = new J.ui.panel({
            modal: false,
            mask: false,
            close: true,
            width: 579,
            content: J.g('popup-rssnotab').html(), //没有tab的弹窗
            onClose: function() {
                //alert('窗口关闭事件');
            }
        });
        J.s('.panel_def').eq(0).setStyle('z-index:999999');
        J.s('.re-code-img').eq(0).attr('src', imgCodeUrl + (new Date().getTime()));

        J.s('.popup-box .comfirm-cancel').each(function(i, item) {
            item.on('click', function(e) {
                J.popup.close();
            });
        });
        J.s('.popup-box .comfirm').eq(0).on('click', function() {
            e.stop();
            validatePhone("phone-num");
            validateSeccode("re-code");
            if (J.s(".val-wrong").length === 0) {
                sendToPhone();
            }
        });
        J.s('.re-code-link').eq(0).get().onclick = function() {
            J.s('.re-code-img').eq(0).attr('src', imgCodeUrl + (new Date().getTime()));
            return false;
            };
    });

    function validatePhone(id) {
        var ele = J.g(id);
        if (!ele.length) {
            return;
        }
        var _id = "phone-info";
        var pwdReg = /^[0-9]{11}$/;
        var str = ele.val();
        var result = {errno: 0, msg: '验证成功'};
        if (!str) {
            result.errno = 1;
            result.msg = '手机格式错误';
            onError(_id, result.msg);
            return;
        } else if (!pwdReg.test(str)) {
            result.errno = 2, result.msg = '手机格式错误';
            onError(_id, result.msg);
            return;
        } else {
            onSuccessHandler(_id);
        }
    }

    function validateSeccode(id) {
        var ele = J.g(id);
        if (!ele.length) {
            return;
        }
        var _id = "seccode-info";
        var str = ele.val();
        var result = {errno: 0, msg: '验证成功'};
        if (!str) {
            result.errno = 1;
            result.msg = '输入错误';
            onError(_id, result.msg);
            return;
        } else if (str.length < 4) {
            result.errno = 2, result.msg = '输入错误';
            onError(_id, result.msg);
            return;
        } else {
            onSuccessHandler(_id);
        }
    }

    function onError(id, msg) {
        var temObj = J.g(id);
        if (!temObj.length) {
            return;
        }
        temObj.removeClass("val-right");
        temObj.addClass("val-wrong");
        temObj.html(msg);
        temObj.show();
        return;
    }

    function onSuccessHandler(id) {
        var temObj = J.g(id);
        if (!temObj.length) {
            return;
        }
        temObj.removeClass("val-wrong");
        temObj.html('');
        temObj.show();
        return;
    }

    function sendToPhone() {
        var url = J.g("post-url").val() + "?r=" + Math.random();
        if(pro_type == 1){//ershou
            J.post({
                url: url,
                type: 'json',
                async: false,
                data: {
                    phone: J.g("phone-num").val(),
                    seccode: J.g("re-code").val(),
                    message: encodeURIComponent(J.g("message").val()),
                    message_code: J.g("message-code").val(),
                    from_page: J.g("from-page").val(),
                    message_no: encodeURIComponent(J.g("message-no").val())
                },
                onSuccess: function(rs) {
                    if (rs && (rs.status === 0 || rs.error_code === 3)) {
                        J.popup.setContent(J.g('popup-rssok').html());
                        J.popup.setAutoClose(3);
                    } else if (rs && rs.status === 1) {
                        J.s('.re-code-link')[0].click();
                        onError("seccode-info", "输入错误");
                    } else if (rs && rs.status === 5) {
                        onError("phone-info", rs.message)
                    } else if (rs && rs.message) {
                        J.popup.setContent(J.g('popup-rssok').html());
                        J.s('#rssok .popup-container').eq(0).html(rs.message);
                        J.popup.setAutoClose(3);
                    } else {
                        J.popup.close();
                    }
                }
            });


        }else if(pro_type == 2 || pro_type == 3){//zufang
            J.post({
                url: url,
                type: 'json',
                async: false,
                data: {
                    "f": send_type,
                    "p": prop_info.prop_id,
                    "m": J.g("phone-num").val(),
                    "t": "sm",
                    "c": J.g("re-code").val(),
                    "v": Math.random(),
                    "reg_from" : 'Site_Rent_MP_FP',
                    //"sign": sign,sh,
                    "content": encodeURIComponent(J.g("message").val())
                    //"send_msg_no" : encodeURIComponent(window.send_message_no),
                    //"message": encodeURIComponent(J.g("message").val())
                },
                onSuccess: function(rs) {
                    var result = /*$.trim(*/rs/*)*/;
                    if(result == '1') {
                        J.popup.setContent(J.g('popup-rssok').html());
                        var t = setTimeout("J.popup.close()", 3000);
                    } else if(result == '5') {
                        onError("seccode-info", "验证码错误");
                    } else {
                        var message = '';
                        if(result == '2') {
                            message = '您已超过10条短信发送上限';
                        } else if(result == '3') {
                            message = '您已对本房源发满2条短信';
                        } else if(result == '4') {
                            message = '两次发送的间隔太短啦，请稍后再试。';
                        }
                        J.popup.setContent(J.g('popup-rssfail').html());
                        if(message) {
                            onError("mobilesend_fail",message);
                        }
                        setTimeout("J.popup.close()", 2000);
                    }
                }
            });
        }

    }
});
/*发送到手机js  end*/
