/* <?php $pages = User_Common_Util_PageHelper::getPureStaticUrl(); ?> */
APF.Namespace.register("ajk.RightTool");
;(function($){
    ajk.RightTool.goTop = rightTool = function (){
        this.wchatOpener = '<?= $pages."/js/chat/1.0.js" ?>';
        this.doms = {
            backtop: $("#backTop"),//返回顶部
            weixin: $("#weixin"),//下载app
            erweima: $("#j_erweima"),//二维码
            favirote: $("#favirote"),//我要发房
            suggestion: $("#suggestion"),//意见反馈
            weiliao: $('#weiliao'),//微聊
            research: $('#research'),//小安调查
            weiliao_unReadNum: $('#unReadNum'),//微聊未读信息数量dom
            weiliao_unReadBg: $('#unReadBg')//微聊未读信息数量背景dom
        };
        this.lastClickTime = 0;
        this.currClickTime = 0;
        this.t = ajk.Logger;
        this._init();
    }

    rightTool.prototype._init = function (){
        this.scroll();
        this.min1024();
        this.bindEvent();
    }

    //当页面加载时判断是否滚动超过400px 显示回到顶部
    rightTool.prototype.scroll = function (){
        var self = this;
        var _scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
        if(_scrollTop >= 400){
           self.doms.backtop.css({"visibility":"visible"});
        }else{
            self.doms.backtop.css({"visibility":"hidden"});
        }
    }

    //如果浏览器宽度小于1024，则不显示二维码图片
    rightTool.prototype.min1024 = function (){
        var self = this;
        var _offsetWidth = 1380;

        if(document.documentElement.clientWidth < _offsetWidth){
            self.doms.erweima.addClass("j_sidebar_hide");
            self.doms.weixin.hide();
            self.doms.favirote.hide();
            self.doms.suggestion.hide();
            self.doms.weiliao.hide();
            self.doms.research.hide();
        }else{
            self.doms.erweima.removeClass("j_sidebar_hide");
            self.doms.weixin.show();
            self.doms.favirote.show();
            self.doms.suggestion.show();
            self.doms.weiliao.show();
            self.doms.research.show();
        }
    }

    rightTool.prototype.bindEvent = function (){
        var self = this;
        //显示隐藏二维码
        self.doms.weixin.on("mouseenter", function(){
            var erweima = self.doms.erweima;
            erweima.removeClass("fadeOut");
            erweima.addClass("fadeIn");
        });

        self.doms.weixin.on("mouseleave", function(){
            var erweima = self.doms.erweima;;
            erweima.removeClass("fadeIn");
            erweima.addClass("fadeOut");
        });

        self.doms.weixin.on("click", function(e){
            return false;
        });

        //回到顶部
        self.doms.backtop.on("click", function(){
            if(document.documentElement.scrollTop > 0){
                document.documentElement.scrollTop = 0;
            }else if(document.body.scrollTop > 0){
                document.body.scrollTop = 0;
            }
            _scrollTop = 0;
            // self.t.track('click_backTop');
            self.t.sendSoj({
                site: 'anjuke-npv',
                page: 'click_backTop'
            });
        });

        //如果页面上有微聊的标签显示，则执行微聊的短信数，并且绑定事件
        self.doms.weiliao.length && self.getUnreadMsgCount();

        //点击微聊
        // var lastClickTime = 0;
        // var currClickTime = 0;
        if(self.doms.weiliao.length){
            $.getScript(wchatOpener,function(){
                var that = self;
                self.doms.weiliao.click(function(e){
                    that.currClickTime = new Date().getTime();
                    e.preventDefault();
                    if (that.lastClickTime == 0 || (that.currClickTime - that.lastClickTime) > 500) {
                        window.chat.open();
                    }
                    that.lastClickTime = that.currClickTime;
                });
            });
        }


        //小安点击数统计
        self.doms.research.length && self.doms.research.on('click',function(){
            //T.trackEvent('click_research');
            self.t.sendSoj({
                site: 'anjuke-npv',
                page: 'click_research'
            });
        });

        //判断页面滚动超过400px，显示回到顶部，小于400px隐藏
        $(window).scroll(function(){
            self.scroll();
        });

        //页面缩放时判断浏览器宽度，小于1024则隐藏
        $(window).resize(function(){
            self.min1024();
        });
    }

    //添加收藏
    rightTool.prototype.addFavirote = function (){
        if(document.all) { // 判断是否ie
            window.external.addFavorite(url, title);
        }else{
            alert("抱歉，您的浏览器不支持此操作。\n\n收藏失败，请使用Ctrl+D添加至浏览器哦！");
        }
    }

    //toggle 实现隐藏二维码
    rightTool.prototype.toggleWeixin = function (){
        var self = this;
        var isHide = self.doms.erweima.attr("data-hide");
        if(isHide != "1"){
            self.doms.erweima.attr({"data-hide":"1"});
            self.doms.erweima.hide();
            T.trackEvent('hide_erweima');
            /*if(getCookie("weixin_ui_closed") != 1){
             setCookie("weixin_ui_closed", 1, 24*365, ".anjuke.com"); //设置隐藏二维码到cookie里
             }*/
        }else{
            self.doms.erweima.attr({"data-hide":"0"});
            self.doms.erweima.show();
            /*if(getCookie("weixin_ui_closed") != 0){
             setCookie("weixin_ui_closed", 0, 24*365); //设置显示二维码到cookie里
             }*/
        }
    }

    //微聊获取未读信息数
    rightTool.prototype.getUnreadMsgCount = function() {
        var self = this;
        //var url = '<?php echo Public_Core_Chat_Util_BuildUrl::getUnreadMsgNumUrl();?>';
        var url = urlForWeiLiaoJs;//global variable
        $.get(url,{
            'jsonp': 1,
            'jsonpcallback' :'setUnreadMsgCount'
        },'jsonp');

        window.setUnreadMsgCount = setUnreadMsgCount;
        function setUnreadMsgCount(data) {
            if (data.retcode == 0 && data.retdata && data.retdata.unreadMsgNum) {
                var count = data.retdata.unreadMsgNum;
                if (count > 0) {
                    count = (parseInt(count) > 99) ? '99+' : count;
                    self.doms.weiliao_unReadNum.html(count);
                    self.doms.weiliao_unReadBg.show();
                } else {
                    self.doms.weiliao_unReadBg.hide();
                }
            }
        }
    }












    // var wchatOpener = '<?= $pages."/js/chat/1.0.js" ?>';
    // //当页面加载时判断是否滚动超过400px 显示回到顶部
    // scroll();

    // //页面load时判断浏览器宽度，小于1024则隐藏
    // min1024();

    // //显示隐藏二维码
    // $("#weixin").on("mouseenter", function(){
    //     var erweima = J.g("j_erweima");
    //     erweima.removeClass("fadeOut");
    //     erweima.addClass("fadeIn");
    // });

    // $("#weixin").on("mouseleave", function(){
    //     var erweima = J.g("j_erweima");
    //     erweima.removeClass("fadeIn");
    //     erweima.addClass("fadeOut");
    // });

    // $("#weixin").on("click", function(e){
    //     return false;
    // });

    // //判断页面滚动超过400px，显示回到顶部，小于400px隐藏
    // // J.on(window, "scroll", function(){
    // //     scroll();
    // // });
    // $(window).scroll(function(){
    //     scroll();
    // });

    // //页面缩放时判断浏览器宽度，小于1024则隐藏
    // $(window).resize(function(){
    //     min1024();
    // });

    // //回到顶部
    // $("#backTop").on("click", function(){
    //     if(document.documentElement.scrollTop > 0){
    //         document.documentElement.scrollTop = 0;
    //     }else if(document.body.scrollTop > 0){
    //         document.body.scrollTop = 0;
    //     }
    //     _scrollTop = 0;
    //     T.trackEvent('click_backTop');
    // });

    // //判断是否滚动到400px
    // function scroll(){
    //     var _scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
    //     if(_scrollTop >= 400){
    //        $("#backTop").css({"visibility":"visible"});
    //     }else{
    //         $("#backTop").css({"visibility":"hidden"});
    //     }
    // }

    // //toggle 现实隐藏二维码
    // function toggleWeixin(){
    //     var isHide = $("#j_erweima").attr("data-hide");
    //     if(isHide != "1"){
    //         $("#j_erweima").attr({"data-hide":"1"});
    //         $("#j_erweima").hide();
    //         T.trackEvent('hide_erweima');
    //         /*if(getCookie("weixin_ui_closed") != 1){
    //          setCookie("weixin_ui_closed", 1, 24*365, ".anjuke.com"); //设置隐藏二维码到cookie里
    //          }*/
    //     }else{
    //         $("#j_erweima").attr({"data-hide":"0"});
    //         $("#j_erweima").show();
    //         /*if(getCookie("weixin_ui_closed") != 0){
    //          setCookie("weixin_ui_closed", 0, 24*365); //设置显示二维码到cookie里
    //          }*/
    //     }
    // }

    // function addFavirote(url, title){
    //     if(document.all) { // 判断是否ie
    //         window.external.addFavorite(url, title);
    //     }else{
    //         alert("抱歉，您的浏览器不支持此操作。\n\n收藏失败，请使用Ctrl+D添加至浏览器哦！");
    //     }
    // }

    // //如果浏览器宽度小于1024，则不显示二维码图片
    // function min1024(){
    //     // 老逻辑：获取页面宽度，小于1080P，则设置隐藏临界点为1185,大于或等于则设置隐藏临界点为1297
    //     // 新逻辑：改版后页面放宽，统一按1380 (1180 + 100*2)处理。
    //     var _offsetWidth = 1380;

    //     if(document.documentElement.clientWidth < _offsetWidth){
    //         $("#j_erweima").addClass("j_sidebar_hide");
    //         $("#weixin").hide();
    //         $("#favirote").hide();
    //         $("#suggestion").hide();
    //         $('#weiliao').hide();
    //         $('#research').hide();
    //     }else{
    //         $("#j_erweima").removeClass("j_sidebar_hide");
    //         $("#weixin").show();
    //         $("#favirote").show();
    //         $("#suggestion").show();
    //         $('#weiliao').show();
    //         $('#research').show();
    //     }
    // }
    // //微聊
    // function getUnreadMsgCount() {
    //     //var url = '<?php echo Public_Core_Chat_Util_BuildUrl::getUnreadMsgNumUrl();?>';
    //     var url = urlForWeiLiaoJs;//global variable
    //     // J.get({
    //     //     url: url,
    //     //     data: {
    //     //         'jsonp': 1,
    //     //         'jsonpcallback' :'setUnreadMsgCount'
    //     //     },
    //     //     timeout: 20000,
    //     //     type: 'jsonp'
    //     // });
    //     $.get(url,{
    //         'jsonp': 1,
    //         'jsonpcallback' :'setUnreadMsgCount'
    //     },'jsonp');

    //     window.setUnreadMsgCount = setUnreadMsgCount;
    //     function setUnreadMsgCount(data) {
    //         if (data.retcode == 0 && data.retdata && data.retdata.unreadMsgNum) {
    //             var count = data.retdata.unreadMsgNum;
    //             if (count > 0) {
    //                 count = (parseInt(count) > 99) ? '99+' : count;
    //                 $('#unReadNum').html(count);
    //                 $('#unReadBg').show();
    //             } else {
    //                 $('#unReadBg').hide();
    //             }
    //         }
    //     }
    // }
    // //如果页面上有微聊的标签显示，则执行微聊的短信数，并且绑定事件
    // $('#weiliao').length && getUnreadMsgCount();

    // //点击微聊
    // var lastClickTime = 0;
    // var currClickTime = 0;
    // /*$('#weiliao').length && (function() {
    //     $('#weiliao').on('click', function() {
    //         currClickTime = new Date().getTime();
    //         //lastClickTime == 0代表首次点击
    //         if (lastClickTime == 0 || (currClickTime - lastClickTime) > 500) {
    //             J.chat.opener.open();
    //         }
    //         lastClickTime = currClickTime;
    //     });

    // }.require(['chat.opener'], true));*/
    // if($('#weiliao').length){
    //     $.getScript(wchatOpener,function(){
    //         $('#weiliao').click(function(e){
    //             currClickTime = new Date().getTime();
    //             e.preventDefault();
    //             if (lastClickTime == 0 || (currClickTime - lastClickTime) > 500) {
    //                 window.chat.open();
    //             }
    //             lastClickTime = currClickTime;
    //         });
    //     });
    // }


    // //小安点击数统计
    // $('#research').length && $('#research').on('click',function(){
    //     T.trackEvent('click_research');
    // });


})(jQuery);