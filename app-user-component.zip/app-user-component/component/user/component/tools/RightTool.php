<?php
class User_Component_Tools_RightToolComponent extends User_Component_AbstractComponent {
    public static function use_boundable_styles() {
        $path = apf_classname_to_path(__CLASS__);
        return array($path."RightTool.css");
    }


    public static function use_boundable_javascripts() {
        $path = apf_classname_to_path(__CLASS__);
        return array($path."RightTool.js");
    }

    public function getView() {
        $this->assign_data("hideFavorite",$this->request->get_attribute('hideFavorite'));
        $this->assign_data("hideErweima",$this->request->get_attribute('hideErweima'));
        $this->assign_data("hideTotop",$this->request->get_attribute('hideTotop'));
        $this->assign_data("hideRightBar",$this->request->get_attribute('hideRightBar'));
        $this->assign_data("city_id",APF::get_instance()->get_request()->getCityId());
        $this->assign_data("showChat",$this->isChatUserLogin());
        $this->assign_data("show_research",$this->isShowResearch());
        $research_url = $this->apf->get_config('research_url','api');
        $research_title = $this->apf->get_config('research_title','api');
        $research_button = $this->apf->get_config('research_button','api');
        $research_content = $this->apf->get_config('research_content','api');
        $this->assign_data('config_research_url',$research_url);
        $this->assign_data('config_research_title',$research_title);
        $this->assign_data('config_research_content',$research_content);
        $this->assign_data('config_research_button',$research_button);
        return "RightTool";
    }
    
    private function isShowResearch(){
        $matches = $this->request->get_router_matches ();
        if(preg_match('/^\/prop\/view\/([0-9]+)$/',$matches[0]) || preg_match('/^\/prop\/(view2)\/([0-9]+)$/',$matches[0]) || preg_match('/^\/prop\/preview\/([0-9]+)$/',$matches[0])){
            return true;
        }else{
            return true;
        }
    }

    private function isChatUserLogin()
    {
        $from_page = $this->request->get_attribute('from_page');
        if($from_page == 'home'){
            return false;
        }
        if($this->request->get_attribute('no_show_chat')){
            return false;
        }
        $city_id = $this->request->getCityId();
        if (!User_Common_MultiCity_City::isPpcOpen($city_id)) {
            return false;
        }
        $auth_token = $this->request->get_cookie('AUTHTOKEN');
        $chat_phone = $this->request->get_cookie('chat_phone');
        $chat_uid = $this->request->get_cookie('chat_uid');
        $auth = $this->request->get_cookie('auth');
        $chat_lasttime = $this->request->get_cookie('chat_lasttime');

        if (!$auth_token ||  !$chat_phone || !$chat_uid || !$auth || $chat_lasttime + 30*86400 < time()) {
            return false;
        } else {
            return true;
        }
    }
}