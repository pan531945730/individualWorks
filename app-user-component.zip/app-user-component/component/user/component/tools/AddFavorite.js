
J.ready(function() {
    //公用dom
    var collect_oks = J.s('.tocollect_ok');
    var collect_nos = J.s('.nocollect_ok');
    var contentEle, popupEle, uniqueEle, timer;
    //html中参数
    var login_url = '';
    var register_url = '';

    ;(function() { 
        initPop();
        otherFunEffect();
        checkIsFav();
        bindEvent();
    })();

    //将弹窗dom放到body下
    function initPop() {
        var ele = J.g(favParams.uniqueId);
        J.g(document.body).append(ele);
        contentEle = J.g(favParams.contentId);
        popupEle = J.g(favParams.popupId);
        uniqueEle = J.g(favParams.uniqueId);
    }

    //与收藏一起的＂其他功能＂
    function otherFunEffect() {
        //hover效果
        J.s('.func em').each(function(k, v) {
            v.on('mouseover', function() {
                v.addClass('yellow');
            }).on('mouseout', function() {
                v.removeClass('yellow');
            });
        });

        //＂其他功能＂点击是否展开
        var list = J.s('.funList'),
            otherFunc = J.s('.otherFunctions'),
            funcContainer = J.s('.funCont');
        otherFunc.length && otherFunc.eq(0).on('mouseover', function() {
            list.length && list.eq(0).setStyle({'display': 'block'});
        });
        funcContainer.length && funcContainer.eq(0).on('mouseleave', function() {
            list.length && list.eq(0).setStyle({'display': 'none'});
        });
    }

    //检查是否已经是被收藏过的房源了
    function checkIsFav() {
        var coUrl = user_anjuke + "ajax/favorite/check_favorite";
        var param = {
            type: add_favorite_param.ptype,
            fid: add_favorite_param.fid,
            time: Math.random()
        };
        J.get({
            type: 'jsonp',
            url: coUrl,
            data: param,
            callback: 'usercenter_check_favorite_success'
        });
        function usercenter_check_favorite_success(ret) {
            //ret.code==2表示错误
            if (ret.code == 0) {
                //未收藏
                showCollectOk();
                //未登录收藏已满，登录后返回该单页，自动收藏
                user_favorite > 0 ? usercenterAddFav(user_favorite) : '';
            } else if (ret.code == 1) {
                //已收藏
                showCollectCancel();
            } 
        }
        //跨域
        window.usercenter_check_favorite_success = usercenter_check_favorite_success;
    }

    //展示＂收藏房源＂
    function showCollectOk() {
        collect_nos.each(function(k, v) {
            v.hide();
        });
        collect_oks.each(function(k, v) {
            v.show();
        });
    }

    //展示＂已收藏＂
    function showCollectCancel() {
        collect_nos.each(function(k, v) {
            v.show();
        });
        collect_oks.each(function(k, v) {
            v.hide();
        });
    }

    //添加收藏处理
    function usercenterAddFav(btn) {
        if (btn == '112') {
            login_url = user_anjuke_login_112_url;
            register_url = user_anjuke_register_112_url;
        } else {
            login_url = user_anjuke_login_111_url;
            register_url = user_anjuke_register_111_url;
        }
        var coUrl = user_anjuke + "ajax/favorite/add_favorite";
        btn = (add_favorite_param.btn != undefined) ? add_favorite_param.btn : btn;
        J.get({
            url:coUrl,
            type:'jsonp',
            data:{
                htype:add_favorite_param.htype,
                type:add_favorite_param.ptype,
                button:btn,
                fid:add_favorite_param.fid,
                time:Math.random()
            },
            callback:'usercenter_add_favorite_success'
        });

        window.usercenter_add_favorite_success = usercenter_add_favorite_success;

        //成功添加收藏
        function usercenter_add_favorite_success(ret) {
            //code[0：成功  1：失败  2：失败-已达上限  3：失败-已收藏]
            if (ret.code == 0) {
                if(pro_type == 2 || pro_type == 3 || pro_type == 14 || pro_type==""){//zufang
                    zufangFavSuccess(ret.user_id);
                    showCollectCancel();
                    loginObj&&loginObj.getFavorite&&loginObj.getFavorite();

                } else if (pro_type == 1) {//ershoufang
                    erShouhandle(user_type);
                    showCollectCancel();
                    loginObj&&loginObj.getFavorite&&loginObj.getFavorite();
                }

            } else if (ret.code == 2) {
                popCollect('enough');
            }
        }

        //zufang success 
        function zufangFavSuccess(user_id) {
            var reg_from = '';
            if(typeof(register_source_code) != 'undefined'){
                reg_from = '?from='+register_source_code;
            }
            popCollect('add', user_id);
            J.s('.panel_def_close').each(function(k, v) {
                bindHide(v);
            });
            J.s(".adds").each(function(k, v) {
                bindHide(v);
            });
            setPosition();
            showDialog();

            function bindHide(v) {
                v.on('click', function() {
                    uniqueEle.hide();
                });
            }
        }
    }

    //根据不同情况弹出窗口
    function popCollect(type, user_id) {
        var enough_html = '<div class="outerborder"> <div style="display:block;" class="msg"> <p class="success">您的收藏已加满,登陆后可继续添加</p><a class="go-on" style="display:inline-block;" href="'+login_url+'&from='+register_source_code+'">立刻登陆</a><p class="fav_full_tip"><a style="display:inline-block;" href="'+register_url+'?from='+register_source_code+'">没有账号?10秒快速注册&gt;&gt;</a></p> <a href="javascript:;" class="panel_close"><i class="close"></i></a> </div> </div>';
        var cancel_html = '<div class="outerborder"> <div style="display:block;height:auto;" class="msg"> <p class="success"><i class="ico-success"></i>取消收藏成功！</p> <a href="javascript:;" class="panel_close"><i class="close"></i></a>  </div> </div>';
        if(user_id){
            //登录且没有推荐的收藏成功弹层
            var add_html = '<div class="outerborder"> '+
            '<!-- NewPop Start --> <div style="display:block;" class="msg"> <p class="success"><i class="ico-success"></i>您已收藏成功！'+
            '<a href="' + (add_favorite_param.view_favorate_url || '') +'">查看收藏&gt;&gt;</a></p> <div><a href="#" class="adds" style="_display:inline-block;"></a></div> '+
            '<!--<span class="close go-on">继续找房</span>--> <i class="close panel_def_close"></i> </div> </div>';
        } else {
            //未登录情况下，有无推荐弹层都一样
            var history_ = J.s(".u_l").eq(0).attr("href");
            var add_html = '<div class="outerborder"> '+
            '<!-- NewPop Start --> <div style="display:block;" class="msg"> <p class="success"><i class="ico-success"></i>您已收藏成功！'+
            '<a href="' + (add_favorite_param.view_favorate_url || '')+'">查看收藏&gt;&gt;</a> </p>'+
            '<div style="height:25px;line-height:25px;margin-left:-60px;padding: 0 10px;width:313px;margin-bottom:5px;">该收藏仅在本设备保存，若需要永久保存并同步请<a href="'+history_+'">登录</a></div>'+
            '<div><a href="#" class="adds" style="_display:inline-block;"></a></div> '+
            '<!--<span class="close go-on">继续找房</span>--> <i class="close panel_def_close"></i> </div> </div>';
        }
        var htmlPanel = '';
        if (type == 'cancel') {
            htmlPanel = cancel_html;
        } else if (type == 'enough') {
            htmlPanel = enough_html;
        } else if (type == 'add') {
            htmlPanel = add_html;
        }
        showPopWindow(htmlPanel)
        if (type == 'cancel') {
            timer = setTimeout(function() {
                uniqueEle.hide();
            }, 3000);
        }
    }

    //显示弹窗
    function showPopWindow(htmlPanel) {
        contentEle.html(htmlPanel);
        setPosition();
        showDialog();
        closeDialog();
    }

    function showDialog() {
        uniqueEle.hide();
        timer && clearTimeout(timer);
        uniqueEle.show();
    }

    //x 绑定 关闭窗口
    function closeDialog() {
        uniqueEle.s('.close').each(function(k, v) {
            v.on('click', function() {
                uniqueEle.hide();
            });
        });
    }

    //点击降价通知时发起ajax请求
    function erShouhandle(utype) {
        J.get({
            url: '/ajax/setmarked/',
            data: {
               "retval" : 1,
               "action" : "insert",
               "id" : favParams.propID,
               "type" : favParams.type,
               "r" : Math.random()
            },
            onSuccess: function(ret) {
                addfavor(ret);
            }
        });

        //显示降价通知对话框
        function addfavor(ret) {
            var rtn = ret;
            if (rtn == 'NOTLOGIN') {
                confirm.show();
                return;
            } 
            if (rtn != 'ERROR') {
                showPopWindow(rtn);
            }
        }
    }

    //事件绑定
    function bindEvent() {
        addCollectBtn();
        cancelCollectBtn();
        J.on(window, 'resize', function() {
            setPosition();
        });
        J.on(window, 'scroll', function() {
            setPosition();
        });
    }

    //添加收藏按钮
    function addCollectBtn() {
        collect_oks.each(function(k, v) {
            v.on('click', function(e) {
                e.stop();
                var btn = v.attr('_button');
                usercenterAddFav(btn)
                btn == '112' ? J.site.trackEvent("topFavorite") : J.site.trackEvent("pageFavorite");
            });
        });
    }

    //取消收藏按钮
    function cancelCollectBtn() {
        collect_nos.each(function(k, v) {
            var ele = v.s('.toolOper');
            ele = ele.length && ele.eq(0);
            v.on('mouseover', function(e) {
                ele && ele.html('取消收藏');
            });

            v.on('mouseout', function(e) {  
                ele && ele.html('已收藏');
            });

            cancelBtnClick(v);          
        });
    }

    //取消收藏按钮点击
    function cancelBtnClick(v) {
        var coUrl = user_anjuke + "ajax/favorite/del_favorite";
        var param = {
            type: add_favorite_param.ptype,
            fid: add_favorite_param.fid,
            time: Math.random()
        }
        v.on('click', function(e) {
            e.stop();
            J.get({
                type: 'jsonp',
                url: coUrl,
                data: param,
                callback: 'usercenter_cancel_favorite_success'
            });
            var btn = v.attr('_button');
            btn == '112' ? J.site.trackEvent("topFavorite") : J.site.trackEvent("pageFavorite");
        });

        function usercenter_cancel_favorite_success(ret) {
            if (ret.code == 0) {
                popCollect('cancel');
                showCollectOk();
                loginObj&&loginObj.getFavorite&&loginObj.getFavorite();
            }
        }

        window.usercenter_cancel_favorite_success = usercenter_cancel_favorite_success;
    }

    //设置panel的位置
    function setPosition() {
        var clientW = window.innerWidth ? window.innerWidth : document.documentElement.clientWidth ? document.documentElement.clientWidth : document.body.clientWidth,
            clientH = window.innerHeight ? window.innerHeight : document.documentElement.clientHeight ? document.documentElement.clientHeight : document.body.clientHeight,
            panelW = uniqueEle.width(),
            panelH = uniqueEle.height(),
            scrollY = window.pageYOffset ? window.pageYOffset : document.body.scrollTop ? document.body.scrollTop : document.documentElement.scrollTop,
            scrollX = window.pageXOffset ? window.pageXOffset : document.body.scrollLeft ? document.body.scrollLeft : document.documentElement.scrollLeft;// panelOffset = uniqueEle.get().getOffsetParent().cumulativeOffset();

        var leftV = scrollX + (clientW - panelW) * 0.5;
        var topV = scrollY + (clientH - panelH) * 0.33;
        uniqueEle.setStyle({
            'left': leftV + 'px',
            'top': topV + 'px'
        });
    }

}); 