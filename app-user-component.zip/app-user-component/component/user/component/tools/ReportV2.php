<?php

class User_Component_Tools_ReportV2Component extends User_Component_AbstractComponent
{

    public function getView()
    {
        $city_id = $this->request->getCityId();
        $city_url = User_Common_Util_Url_BaseUrl::buildBaseUrl($city_id);
        $captcha_url = $city_url . '/v3/ajax/complaint/getcaptcha/?r=0.000001';
        $send_msg_url = $city_url . '/v3/ajax/complaint/sendverifycode/';

        $this->assign_data("captcha_url", $captcha_url );
        $this->assign_data("send_msg_url", $send_msg_url) ;
        $this->assign_data("prop_id", $this->get_param("prop_id"));
        $this->assign_data("broker_id", $this->get_param("broker_id"));
        $this->assign_data("ip", $this->get_param("ip"));
        $this->assign_data('title', $this->get_param('title'));
        return 'ReportV2';
    }

    public static function use_boundable_javascripts()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array(
            $path . "ReportV2.js"
        );
    }

    public static function use_component()
    {
        return array_merge(
            parent::use_component(), array(
            )
        );
    }

    public static function use_boundable_styles()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array_merge(
            parent::use_boundable_styles(), array($path . "ReportV2.css"));
    }

    public static function use_javascripts()
    {
        return array(
        );
    }
}

