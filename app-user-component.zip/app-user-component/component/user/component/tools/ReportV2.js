$(function(){

    var dom = {
        box         : $('.report-wrap'),
        sucBox      : $('.report-success'),
        enter       : $('#falseTxt'),
        close       : $('.close-wrap'),
        img         : $('.item-mod .codeImg'),
        refresh     : $('.item-mod .refresh'),
        getCode     : $('.report-wrap .getcode'),
        submit      : $('.report-wrap .submit'),
        rpType      : $('.report-wrap [name=report_type]'),
        description : $('.report-wrap [name=description]'),
        mobile      : $('.report-wrap [name=mobile]'),
        imgCode     : $('.report-wrap [name=captcha]'),
        verify_msg  : $('.report-wrap [name=verify_msg]'),
        errBox      : $('.report-wrap .err-msg'),
        codeBtn     : $('.report-wrap .getcode')
    }

    var reportModal =  new ajk.Modal({
        modalClass: 'modal-custom report_dialog',
        title     : '我要举报',
        bd        : $('.report-wrap'),
        width     : '640',
        height    : '606'
    });

    var successModal =  new ajk.Modal({
        modalClass: 'modal-custom report_dialog',
        title     : '我要举报',
        bd        : $('.report-success'),
        width     : '330',
        height    : '170'
    });

    vdOptions = {
        report_type : {
            empty : '请选择举报类型！'
        },
        mobile : {
            empty  : '请填写手机号！',
            format : '请填写正确手机号！'
        },
        captcha : {
            empty   : '请填写图片验证码！',
            format  : '图片验证码错误！',
            outtime : '图片验证码过期，请重新获取！'
        },
        description : {
            empty  : '请填写举报内容！',
            format : '举报内容不能为非法字符！',
            min    : '至少输入20个文字',
            max    : '最多输入100个文字'
        },
        verify_msg : {
            empty  : '请输入短信验证码！',
            format : '手机验证码错误！'
        },
        fy_url  : {
            format : '房源地址错误！'
        },
        fy_id   : {
            format : '房源ID错误！'
        },
        common  : {
            fail : '执行失败！'
        }
    }

    dom.enter.on('click.enter',function(){
        reportModal.open();
    });
    

    dom.refresh.click(function(){
        refreshImg();
    });

    dom.getCode.click(function(){
        if($(this).is('.btn-disable')) return;
        if(!validate('mobile')) return;
        if(!validate('captcha')) return;
        showErr('','',true);
        sendCode();
    });

    dom.submit.click(function(){
        if(!validate('report_type')) return;
        if(!validate('description')) return;
        if(!validate('mobile')) return;
        if(!validate('verify_msg')) return;
        showErr('','',true);
        submitReport();
    });


    function refreshImg(){
        var curSrc = dom.img.attr('src');
        dom.img.attr('src',curSrc.substring(0,curSrc.indexOf('?r=')) + '?r=' + Math.random());
    }

    function validate(vdType){
        switch(vdType){
            case 'report_type': 
                if(!dom.rpType.filter(':checked').length){
                    showErr(vdType,'empty');
                    return false;
                }
                break;
            case 'description': 
                if(!$.trim(dom.description.val()).length){
                    showErr(vdType,'empty');
                    return false;
                }
                if(/<script.*?>.*?<\/script>/ig.test(dom.description.val())){
                    showErr(vdType,'format');
                    return false;
                }
                if(dom.description.val().length < 20){
                    showErr(vdType,'min');
                    return false;
                }
                if(dom.description.val().length > 100){
                    showErr(vdType,'max');
                    return false;
                }
                break;
            case 'mobile': 
                if(!dom.mobile.val().length){
                    showErr(vdType,'empty');
                    return false;
                }
                if(!/^1[3|4|5|7|8]\d{9}$/.test(dom.mobile.val())){
                    showErr(vdType,'format');
                    return false;
                }
                break;
            case 'captcha': 
                if(!dom.imgCode.val().length){
                    showErr(vdType,'empty');
                    return false;
                }
                break;
            case 'verify_msg': 
                if(!dom.verify_msg.val().length){
                    showErr(vdType,'empty');
                    return false;
                }
                break;
            default:
        }
        return true;
    }

    function sendCode(){
        $.ajax({
            url  : '/v3/ajax/complaint/sendverifycode/',
            data : {
                mobile      : dom.mobile.val(),
                captcha     : dom.imgCode.val()
            },
            type     : 'GET',
            dataType : 'json'
        })
        .done(function(result){
            if(result.code == 2){
                showErr('captcha','format');
            }else if(result.code == 1){
                showErr('mobile','format');
            }else if(result.code == 0){
                dom.codeBtn.addClass('btn-disable');
                countDown(60);
                refreshImg();
            }else if(result.code == 5){
                showErr('captcha','outtime');
            }
        });
    }

    function submitReport(){
        var link = $('link:first').attr('href');
        showErr('','',true);
        var param = {
            property_url  : link,
            property_id   : link.substring(link.indexOf('/view/')+7),
            report_type   : collectReportType(),
            description   : dom.description.val(),
            mobile        : dom.mobile.val(),
            verify_msg    : dom.verify_msg.val()
        };
        $.ajax({
            url      : '/v3/ajax/complaint/savecomplaint/',
            data     : param,
            type     : 'GET',
            dataType : 'json'
        })
        .done(function(result){
            if(result.code == 6){
                showErr('verify_msg','format');
            }else if(result.code == 7){
                showErr('fy_id','format');
            }else if(result.code == 8){
                showErr('fy_url','format');
            }else if(result.code == 0){
                // dom.enter.hide();
                reportModal.close();
                successModal.open();
                setTimeout(function(){
                    successModal.close();
                },2000);
                // dom.enter.off('click.enter');
            }else{
                showErr('common','fail');
            }
        });
    }

    function collectReportType(){
        var rpType = '';
        dom.rpType.filter(':checked').each(function(){
            rpType += $(this).val() + ',';
        })
        return rpType.substring(0,rpType.length-1);
    }

    function showErr(vdType,vdCont,isHide){
        isHide ? dom.errBox.hide() : dom.errBox.text(vdOptions[vdType][vdCont]).show();
    }

    function countDown(sec){
        if(sec > 1){
            sec = sec - 1;
            dom.codeBtn.text(sec + '秒后再次获取');
            clearTimeout(window.cd);
            window.cd = setTimeout(function(){
                countDown(sec);
            },1000);
        }else{
            dom.codeBtn.removeClass('btn-disable').text('获取验证码');
        }
    }

    function show_center(obj) {
        var windowWidth = document.documentElement.clientWidth;
        var windowHeight = document.documentElement.clientHeight;
        var popupHeight = obj.height();
        var popupWidth = obj.width();
        obj.css({
            "zIndex"   : 9999,
            "position" : "fixed",
            "top"      : (windowHeight - popupHeight) / 2 + (document.body.scrollTop ||document.documentElement.scrollTop) + 'px',
            "left"     : (windowWidth - popupWidth) / 2 +'px'
        });
    }

    dom.box.appendTo('body');
    dom.sucBox.appendTo('body');
    // show_center(dom.box);
    // show_center(dom.sucBox);
    refreshImg();
});
