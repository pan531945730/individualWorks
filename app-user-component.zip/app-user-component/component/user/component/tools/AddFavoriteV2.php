<?php
class User_Component_Tools_AddFavoriteV2Component extends User_Component_AbstractComponent
{
    public function getView()
    {
        $prop_id = $this->get_param("prop_id");
        $this->assign_data("prop_id", $prop_id);
        return 'AddFavoriteV2';
    }

    public static function use_component()
    {
        return array_merge(
            parent::use_component(), array(
            )
        );
    }

    public static function use_boundable_styles()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "AddFavoriteV2.css");
    }

    public static function use_boundable_javascripts()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array(
            // $path . "AddFavoriteV2.js"
            $path . "AddFavoriteV2.js"
        );
    }
}