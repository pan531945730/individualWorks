
/*新房源通知js*/
J.ready(function() {

    function validateEmail(id) {
        var ele = J.g(id);
        if (!ele.length) {
            return;
        }
        var mailReg = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        function handler() {
            var str = ele.val();
            var result = {errno: 0, msg: '验证成功'};
            if (!str) {
                result.errno = 1;
                result.msg = '邮箱格式错误';
                onError(result.msg);
                return;
            } else {
                var str = ele.val();
                if (!mailReg.test(str)) {
                    result.errno = 2, result.msg = '邮箱格式错误';
                    onError(result.msg);
                    return;
                } else {
                    onSuccessHandler();
                }

            }
        }
        function onError(msg) {
            var temObj = J.g("subscribe-email-info");
            temObj.removeClass("val-right");
            temObj.addClass("val-wrong");
            temObj.html(msg);
            J.g("subscribe-email-info").show();
            return;
        }
        function onSuccessHandler() {
            var temObj = J.g("subscribe-email-info");
            temObj.removeClass("val-wrong");
            temObj.addClass("val-right");
            temObj.html('');
            J.g("subscribe-email-info").show();
            return;
        }
        return {
            handler: handler
        }
    }

    function validateMobile(id){
        var ele = J.g(id);
        if(!ele.length){
            return;
        }
        var pwdReg=/^[0-9]{11}$/;
        function handler(){
            var str = ele.val();
            var result = {errno:0,msg:'验证成功'};
            if(!str){
                result.errno =1;
                result.msg='手机格式错误';
                onError(result.msg);
                return;
            } else if(!pwdReg.test(str)){
                result.errno =2,result.msg='手机格式错误';
                onError(result.msg);
                return;
            }else{
                onSuccessHandler();
            }
        }
        function onError(msg){
            var temObj =J.g("subscribe-phone-info");
            temObj.removeClass("val-right");
            temObj.addClass("val-wrong");
            temObj.html(msg);
            J.g("subscribe-phone-info").show();
            return;
        }
        function onSuccessHandler(){
            var temObj = J.g("subscribe-phone-info");
            temObj.removeClass("val-wrong");
            temObj.addClass("val-right");
            temObj.html('');
            J.g("subscribe-phone-info").show();
            return;
        }
        return {
            handler:handler
        }
    }

    //自定义执行改写
    J.s('.comm_subscribe').each(function(i,item) {
        item.on('click', function(e) {
            e.stop();
            var content = '';
            if (J.s(".panel_def").length > 0) {
                subscribeModal.close();
            }
            if (item.hasClass("email-icon")) {
                content = J.g('popup-rss-new-prop').html();
            } else if (item.hasClass("phone-icon")) {
                content = J.g('popup-rss-change-price').html()
            }
            // J.popup = new J.ui.panel({
            //     modal: false,
            //     mask: false,
            //     close: true,
            //     width: 579,
            //     content: content, //没有tab的弹窗
            //     onClose: function() {
            //         //alert('窗口关闭事件');
            //     }
            // });

            var subscribeModal =  new ajk.Modal({
                modalClass: 'modal-custom send_subscribe_dialog',
                title     : '新房源通知',
                bd        : $(content),
                width     : '579',
                height    : '360'
            });
            subscribeModal.open();

            J.s('.panel_def').eq(0).setStyle('z-index:999999');
            
            J.s('.tab-box ul li').each(function(i, item) {
                J.on(item, 'mouseover', function() {
                    J.s('.tab-box ul li').each(function(i, item) {
                        item.removeClass('cur');
                    });
                    item.addClass('cur');
                    J.s('.tab-content').each(function(i, item) {
                        //item.setStyle('display:none');
                        item.hide();
                    });

                    $('#'+item.attr('id') + '-content').show();
                });
            });

            /*J.s('.popup-box .comfirm-cancel').each(function(i, item) {
                item.on('click', function(e) {
                    // todo 关闭窗口
                    J.popup.close();
                });
            });*/

            J.s('.popup-subscribe .comfirm').each(function(i, item) {
                item.on('click', function() {
                    e.stop();
                    var phone = '';
                    var email = '';
                    var info_ele = null;
                    var type = 1;
                    var mail = new validateEmail("subscribe-email-addr");
                    var mobile = new validateMobile("subscribe-phone-num");
                    if ($(this).is('.phone-confirm')) {
                        phone = J.g("subscribe-phone-num").val();
                        type = 2;
                        info_ele = J.g("subscribe-phone-info");
                        mobile.handler();
                    } else {
                        email = J.g("subscribe-email-addr").val();
                        type = 1;
                        info_ele = J.g("subscribe-email-info");
                        mail.handler();
                    }

                    if (info_ele.hasClass("val-right")) {
                        var from_page = J.g("from-page").val();
                        var url = J.g("post-url").val() + "?r=" + Math.random();
                        var subscribe_name = J.g("subscribe_name").val();
                        var reg_from = '';
                        if(subscribe_name == 'cp'){
                            reg_from = register_source_code_cp;
                        }else if(subscribe_name == 'nh'){
                            reg_from = register_source_code_nh;
                        }
                        J.post({
                            url: url,
                            type: 'json',
                            async: false,
                            data: {
                                email: email,
                                phone: phone,
                                subscribe_type: type,
                                from_page: from_page,
                                reg_from : reg_from
                            },
                            onSuccess: function(rs) {
                                if (rs && rs.status === 0) {
                                    $('.send_subscribe_dialog').find('.con').css('height','191px').find('.bd').html($('#popup-rssok-change-price').html());
                                    $('.send_subscribe_dialog').find('.bd>div').show();
                                    // J.popup.setContent(J.g('popup-rssok-change-price').html());
                                    // J.popup.setAutoClose(3);
                                    setTimeout(function(){
                                        subscribeModal.close();
                                    },3000);
                                } else if (rs && rs.status === 5) {
                                    var temObj =J.g("subscribe-email-info");
                                    temObj.removeClass("val-right");
                                    temObj.addClass("val-wrong");
                                    temObj.html(rs.message);
                                    J.g("subscribe-email-info").show();
                                } else if (rs && rs.status === 6) {
                                    var temObj =J.g("subscribe-phone-info");
                                    temObj.removeClass("val-right");
                                    temObj.addClass("val-wrong");
                                    temObj.html(rs.message);
                                    J.g("subscribe-phone-info").show();
                                } else if (rs && rs.error_code === 3) {
                                    $('.send_subscribe_dialog').find('.con').css('height','191px').find('.bd').html($('#popup-rssok-change-price').html());
                                    $('.send_subscribe_dialog').find('.bd>div').show();
                                    // J.popup.setContent(J.g('popup-rssok-change-price').html());
                                    J.s('#success-msg').eq(0).html("您已订阅过!");
                                    // J.popup.setAutoClose(3);
                                    setTimeout(function(){
                                        subscribeModal.close();
                                    },3000);
                                } else if (rs && rs.error_code === 1) {
                                    $('.send_subscribe_dialog').find('.con').css('height','191px').find('.bd').html($('#popup-rssok-change-price').html());
                                    $('.send_subscribe_dialog').find('.bd>div').show();
                                    // J.popup.setContent(J.g('popup-rssok-change-price').html());
                                    var item = (type === 1) ? "邮箱" : "手机";
                                    J.s('#success-msg').eq(0).html("您的"+ item +"订阅量已超过10条上限");
                                    // J.popup.setAutoClose(3);
                                    setTimeout(function(){
                                        subscribeModal.close();
                                    },3000);
                                } else {
                                    $('.send_subscribe_dialog').find('.con').css('height','191px').find('.bd').html($('#popup-rssok-change-price').html());
                                    $('.send_subscribe_dialog').find('.bd>div').show();
                                    // J.popup.setContent(J.g('popup-rssok-change-price').html());
                                    J.s('#rssok .popup-container').eq(0).html("您订阅本次失败，请重新订阅。");
                                    // J.popup.setAutoClose(3);
                                    setTimeout(function(){
                                        // subscribeModal.close();
                                    },3000);
                                }
                            }
                        });
                    }
                });

            });
            
        });
    });

});
/*新房源通知js   end*/
