<?php
/**
 * 发送到手机非jock js版本
 * Created by PhpStorm.
 * User: qigao
 * Date: 15-12-10
 * Time: 下午2:15
 */

class User_Component_Tools_SendToMobileNewComponent extends User_Component_AbstractComponent
{
    public function getView()
    {
        $property = $this->get_param("property");
        $comm_info = $this->get_param('community');
        $pro_type = $this->get_param('pro_type');

        if($pro_type == Zufang_Core_Const_Rent::ZUFANG_PROP){
            $code_img = User_Common_Util_Url::buildBaseUrl("zu"). "/check/code?cn=haozu&x=120&y=40&s=30&x1=2&y1=46&x2=12&y2=38&t=";
        }else{
            $code_img = User_Common_Util_Url::buildBaseUrl() . "/seccode?k=seccode&x=101&y=26&s=24&x1=2&y1=30&x2=12&y2=26&t=";
        }

        $code_img .= time();
        $this->assign_data('code_img', $code_img);
        $this->assign_data('pro_type', $pro_type);

        $comm_id = $property->community_id;
        $this->assign_data("posturl", $this->buildSubscribeSendtophoneUrl($comm_id, $pro_type));
        $this->assign_data("frompage", $this->get_param("FromPage"));
        $this->assign_data("property", $property);
        $this->assign_data("community", $comm_info);
        $this->assign_data('register_url', $this->buildRegisterUri());
        $user_id = $this->apf->get_request()->getUserId();
        if ($user_id > 0) {
            $this->assign_data('user_id', $user_id);
            $mobile = $this->getUserMobile($user_id);
            $this->assign_data('default_mobile', $mobile);
            $strBaseDomain = $this->apf->get_config('base_domain');
            $strUserModifyURL = 'http://user.'.$strBaseDomain.BASE_URI.'/member/modify/info/';
            $this->assign_data('userModifyURL', $strUserModifyURL);
        }
        $isYzProp = $this->get_param("isYzProp");

        //1,中介房源,2,个人房源
        if ($isYzProp) {
            $prop_type = 2;
        } else {
            $prop_type = 1;
        }
        $this->assign_data("prop_type", $prop_type);

        if ($isYzProp) {
            $message = $this->get_yz_message($property);
        } else {
            $message = $this->get_message($property, $this->get_param("broker"));
        }
        $this->assign_data("message", $message);
        $this->assign_data("message_code", $this->get_message_code($comm_id,$message));
        $this->assign_data("Base_Reg_From", $this->get_param("Base_Reg_From"));
        $this->assign_data("Reg_From", $this->get_param("Reg_From"));

        return 'SendToMobileNew';
    }

    public function buildSubscribeSendtophoneUrl($id, $pro_type) {
        $id = intval($id);
        if($pro_type == Zufang_Core_Const_Rent::ZUFANG_PROP){
            return User_Common_Util_Url_BaseUrl::buildZufangUrl(APF::get_instance()->get_request()->getCityId())."/ajax/mobilesend/{$id}";
        }else{
            return User_Common_Util_Url::buildBaseUrl()."/community/subscribe/sendtophone/{$id}";
        }
    }

    public function buildRegisterUri(){
        $url=User_Common_Util_Url::buildBaseUrl('anjuke','user');
        return $url.BASE_URI."/register";
    }

    public function  getUserMobile($uid){
        apf_require_class('Member_Core_Service_QueryService');
        $member_query = new Member_Core_Service_QueryService();
        $user_info = $member_query->getOtherDataByUid($uid);
        return isset($user_info['UserMobile']) ? $user_info['UserMobile'] : '' ;
    }

    //个人房源短信模板
    private function get_yz_message($property) {
        $prop_comminfo = $this->get_param("prop_comminfo");
        $commname = $property->comm_name;
        //$address = $prop_comminfo['COMMADDRESS'];
        $address = $property->pro_address;
        $housetype = $property->room_num . "室" . $property->hall_num . "厅" . $property->toilet_num . "卫";
        $price = $property->unit_price;
        $not_sex = in_array(mb_substr($property->owner_name,-2,2,"UTF-8"),array("女士","先生")) ? true:false;
        $username = $property['owner_name'] . ($not_sex ? "":($property->sex? "先生" : "女士"));
        $mobile = $property->owner400 ? $property->owner400 : $property->owner_mobile;
        // $url = $this->get_single_url_domian($property['CITYID'], $property['PROID']);

        $params  = compact("commname", "housetype", "price", "address", "username", "mobile");
        return User_Common_Sms_SmsTemplate::get_instance()->get_template('SMT_SP_anjuke_viewyz', $params);
    }

    //中介房源短信模板
    private function get_message($property, $broker, $user_id=0) {
        $commname = $property->comm_name;
        $address = $property->pro_address;
        $housetype = $property->room_num . "室" . $property->hall_num . "厅" . $property->toilet_num . "卫";
        $price = $property->unit_price;
        $username = $broker->true_name;
        $mobile = $broker->mobile_split_str;

        $params  = compact("commname", "housetype", "price", "address", "username", "mobile");
        return User_Common_Sms_SmsTemplate::get_instance()->get_template('SMT_SP_anjuke_view', $params);
    }

    private function get_message_code($comm_id,$message) {
        return md5($comm_id . $message);
    }

    public static function use_component()
    {
        return array_merge(
            parent::use_component(), array(
            )
        );
    }

    public static function use_boundable_styles()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "SendToMobileNew.css");
    }

    public static function use_boundable_javascripts()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array(
            $path . "SendToMobileNew.js"
        );
    }

}