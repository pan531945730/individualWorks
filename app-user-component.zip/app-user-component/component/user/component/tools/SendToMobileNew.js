/**
 * 发送到手机 非Jock.js
 */
 ;APF.Namespace.register("EntrustView.SendMSG");
;(function($) {
    $(function() {
        function SendMSG(op) {
            this.pro_type  = op.pro_type;
            this.prop_type = op.prop_type;
            this.prop_id   = op.prop_id;
            this.userId    = op.userId;
            this.send_type = op.send_type;
            this.verifyURL = op.verifyURL + "?r=" + Math.random();

            this.btn       = $("#" + op.openBtnId);
            this.msgAjaxParam = null;
            this.confirmBtnAjaxParam = {};
            this.verifyObj = {
                phone  : {tf : false},
                reCode : {tf : false}
            };
            this.msgURL = "";
            self.imgCodeUrl = "";
            this.init();
        }
        SendMSG.prototype.init = function() {
            var self = this;
            self.bindEvent();
            self.getAjaxParam();
            // self.getPhoneMSG(); // 接口不通
        }

        // 设置  ajax参数
        SendMSG.prototype.getAjaxParam = function() {
            var self = this;
            if( self.pro_type == 13 ) { // 大业主
                self.msgURL = "/v3/ajax/getMsgSentToPhone/";
                self.imgCodeUrl = '/check/code?cn=haozu&x=120&y=40&s=30&x1=2&y1=46&x2=12&y2=38&t=';
                self.msgAjaxParam = {
                    send_type : self.send_type || 0,
                    prop_id   : self.prop_id || 0
                };
            } else if( self.pro_type == 2 || self.pro_type == 3 ) { // zufang
                self.msgURL = "/ajax/getMsgSentToPhone/";
                self.imgCodeUrl = "/check/code?cn=haozu&x=120&y=40&s=30&x1=2&y1=46&x2=12&y2=38&t=";
                self.msgAjaxParam = {
                    send_type : self.send_type || 0,
                    prop_id   : self.prop_id || 0
                };
            } else if(self.pro_type == 1) { // ershoufang
                self.msgURL = "/ajax/getToPhoneMsg/";
                self.imgCodeUrl = "/seccode?k=seccode&x=101&y=26&s=24&x1=2&y1=30&x2=12&y2=26&t=";
                self.msgAjaxParam = {
                    prop_id   : self.prop_id || 0,
                    prop_type : self.prop_type
                };
            }
        }

        //
        SendMSG.prototype.getPhoneMSG = function() {
            var self = this;
            $.ajax({
                type     : "get",
                url      : self.msgURL,
                dataType : 'json',
                data     : self.msgAjaxParam,
                success  : function(r) {
                },
                error    : function() {}
            });
        }
        SendMSG.prototype.bindEvent = function() {
            var self = this;

            // 弹层出现时获取验证码
            self.btn.on("click", function() {
                
            });

            // 点击“立即确认”按钮
            $("#send_confirm_btn").on("click", function() {

                // 验证@canshu : id
                self.validateInputPhone("phone_num");
                self.validateInputReCode("re_code");

                if( self.isPassedVerify() ) {
                    self.confirmBtnAjaxParam = {
                        phone : $("#phone_num").val(),
                        seccode : $("#re_code").val(),
                        message : "%E5%AE%89%E5%B1%85%E5%AE%A2%E4%BA%8C%E6%89%8B%E6%88%BF%3A%E4%BB%A5%E4%B8%8B%E6%98%AF%E6%82%A8%E8%AE%A2%E9%98%85%E7%9A%84%E4%BF%A1%E6%81%AF%3A%20t.anjuke.com%2Fsw1swTk%20%2C%E6%9C%AC%E4%BF%A1%E6%81%AF%E7%94%B1%E9%A9%AC%E4%B9%90%E4%B9%90%E5%8F%91%E5%B8%83%2C%E8%81%94%E7%B3%BB%E7%94%B5%E8%AF%9D%20183%202137%206561",
                        message_code : "",
                        from_page : "",
                        message_no : ""
                    };
                    self.verifyThisCode();
                }
            });

            $("#phone_num").on("blur", function() {
                self.validateInputPhone("phone_num");
            });
            $("#re_code").on("blur", function() {
                self.validateInputReCode("re_code");
            });
        }
        SendMSG.prototype.verifyThisCode = function() {
            var self = this;
            $.ajax({
                type      : "post",
                url       : self.verifyURL,
                datatype  : 'json',
                data      : self.confirmBtnAjaxParam,
                success   : function(r) {
                    $(".mask_close_btn").click();
                },
                error     : function(xhr, status, thrown) {
                    // alert("验证码验证失败！");
                }
            });
        }
        SendMSG.prototype.setVerify = function(key, b) {
            var self = this;
            if( self.verifyObj[key]["tf"] !== undefined ) {
                self.verifyObj[key]["tf"] = b;
            }
        }
        SendMSG.prototype.isPassedVerify = function() {
            var self = this,
                r    = true;
            $.each(self.verifyObj, function() {
                if( this.tf === false) {
                    r = false;
                }
            });
            return r;
        }

        SendMSG.prototype.validateInputPhone = function(id) {
            var self = this,
                node = $("#" + id);
            if( $.trim(node.val()) === "" ) { // 手机号为空
                self.setVerify("phone", false);
                $("#phone_info").html("手机号不能为空");
                $("#phone_pass_ico").removeClass("verify_pass_ico");
                $("#phone_pass_ico").addClass("verify_unpass_ico");
            } else if( !/^1[3|4|5|7|8][0-9]\d{8}$/.test($.trim(node.val())) ) { // 手机号格式不符合要求
                $("#phone_info").html("手机号不符合要求");
                $("#phone_pass_ico").removeClass("verify_pass_ico");
                $("#phone_pass_ico").addClass("verify_unpass_ico");
            } else { // 手机号通过
                $("#phone_info").html("");
                $("#phone_pass_ico").addClass("verify_pass_ico");
                $("#phone_pass_ico").removeClass("verify_unpass_ico");
                self.setVerify("phone", true);
            }
        }
        SendMSG.prototype.validateInputReCode = function(id) {
            var self = this,
                node = $("#" + id);
            if( $.trim(node.val()) === "" ) { // 验证码为空
                $("#seccode_info").html("验证码不能为空");
                $("#seccode_pass_ico").removeClass("verify_pass_ico");
                $("#seccode_pass_ico").addClass("verify_unpass_ico");
                self.setVerify("reCode", false);
            } else {
                $("#seccode_info").html("");
                $("#seccode_pass_ico").addClass("verify_pass_ico");
                $("#seccode_pass_ico").removeClass("verify_unpass_ico");
                self.setVerify("reCode", true);
            }
        }


        EntrustView.SendMSG = SendMSG;


    })
})(jQuery);