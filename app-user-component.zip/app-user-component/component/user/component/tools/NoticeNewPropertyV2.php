<?php

class User_Component_Tools_NoticeNewPropertyV2Component extends User_Component_AbstractComponent
{

    public function getView()
    {
        $apf = APF::get_instance();
        $base_domain = $apf->get_config("base_domain");
        $comm_id = $this->get_param("CommId");
        $commname = $this->get_param("CommName");
        $type = $this->get_param("type");
        $reg_from = $this->get_param("Reg_From");
        $base_reg_from = $this->get_param("Base_Reg_From");
//         if ($type == "change-price") {
//             $this->assign_data("posturl", Community_CommunitySubscribeChangepriceController::build_url($comm_id));
//             $this->assign_data("maillabel", "请填写您接收“{$commname}”降价通知的邮箱地址");
//             $this->assign_data("mobilelabel", "请填写您接收“{$commname}”降价通知的手机地址");
//             $this->assign_data("subscribe_name", "cp");
//         } else {
//             $type = "new-prop";
            $this->assign_data("posturl", $this->buildSubscribeNewPropUrl($comm_id));
            $this->assign_data("maillabel", "请填写您接收“{$commname}”新房源通知的邮箱地址");
            $this->assign_data("mobilelabel", "请填写您接收“{$commname}”新房源通知的手机地址");
            $this->assign_data("subscribe_name", "nh");
//         }
        $this->assign_data("frompage", $this->get_param("FromPage"));
        $this->assign_data("type", $type);
        $this->assign_data('register_url', $this->buildRegisterUri());

        $user_id = $apf->get_request()->getUserId();
        $strBaseDomain = $apf->get_config('base_domain');
        if ($user_id > 0) {
            $this->assignUserInfo($user_id);
            $strUserEmailURL = 'http://user.'.$strBaseDomain.BASE_URI.'/member/modify/mail/';
            $strUserModifyURL = 'http://user.'.$strBaseDomain.BASE_URI.'/member/modify/info/';
            $this->assign_data('userModifyURL', $strUserModifyURL);
            $this->assign_data('userEmailURL', $strUserEmailURL);
        }
        $strSubscribeList = 'http://user.'.$strBaseDomain.BASE_URI.'/subscribe/manage/list/';
        $this->assign_data('strSubscribeList', $strSubscribeList);
        $this->assign_data('reg_from', $reg_from);
        $this->assign_data('base_reg_from', $base_reg_from);

        return 'NoticeNewPropertyV2';
    }
    
    protected function assignUserInfo($user_id){
        $this->assign_data('user_id', $user_id);
        
        apf_require_class('Member_Core_Service_ExtMappingService');
        $extMappingService = new Member_Core_Service_ExtMappingService();
        if ($extMappingService -> getUserMappingByUid($user_id)){
            $this->assign_data('is_ext_member', true);
        }

        apf_require_class('Member_Core_Service_QueryService');
        $member_query = new Member_Core_Service_QueryService();
        $user_info = $member_query->getMemberBaseInfo($user_id);
        $user_other_info = $member_query->getOtherDataByUid($user_id);
        $this->assign_data('default_email', $user_info['UserEmail']);
        $this->assign_data('default_mobile', $user_other_info['UserMobile']);
        return true;
    }
    
    protected function buildSubscribeNewPropUrl($id) {
        $id = intval($id);
        return User_Common_Util_Url::buildBaseUrl()."/community/subscribe/newprop/{$id}";
    }

    protected function buildRegisterUri(){
        $url=User_Common_Util_Url::buildBaseUrl('anjuke','user');
        return $url.BASE_URI."/register";
    }

    public static function use_component()
    {
        return array_merge(
            parent::use_component(), array(
            )
        );
    }

    public static function use_boundable_styles()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "NoticeNewPropertyV2.css");
    }

    public static function use_boundable_javascripts()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array(
            $path . "NoticeNewPropertyV2.js"
        );
    }
}

