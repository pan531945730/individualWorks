<?php
/**
 * AdAnjuke component
 *
 * Anjuke 广告组件
 *_Ad_IfxComponent
 */
class User_Component_Promotion_AdAnjukeComponent extends User_Component_AbstractComponent {

    public function getView () {
        //取不到页面名称
        $page_name = $this->get_class_name();
        if(empty($page_name)){
            return false;
        }

        //获取页面广告配置
        $zones = APF::get_instance()->get_config($page_name,'advertisement');

        $ifx_conf_url = APF::get_instance()->get_config('ifx_conf_url');
        $ifx_conf_url = $ifx_conf_url ? $ifx_conf_url : 'http://ifx.fang.anjuke.com';
        if(empty($zones)){
            return false;
        }
        $this->assign_data('zones', $zones);
        $this->assign_data('ifx_conf_url', $ifx_conf_url);

        $cityid = APF::get_instance()->get_request()->getCityId();
        $result_data = @APF::get_instance()->get_request()->get_attribute('RESULT_DATA');
        $region_id = $subregion_id = 0;
        if(!empty($result_data) and isset($result_data['base_info'])){
            $info = $result_data['base_info'];
            $region_id = isset($info['AreaId'])?$info['AreaId']:0;
            $subregion_id = isset($info['BlankId'])?$info['BlankId']:0;
        }

        //获取请求广告的地址
        $baseUrl = $_SERVER[HTTP_HOST];
        if(preg_match("/^my\./",$baseUrl)){
            $url = $this->get_domain($cityid,1).BASE_URI.'/ajax/ad/show/';
        }else{
            $url = $this->get_domain($cityid).BASE_URI.'/ajax/ad/show/';
        }
        $url .= '?pagename='.$page_name;
        $url .= '&cityid='.$cityid;
        $url .= '&region_id='.$region_id;
        $url .= '&subregion_id='.$subregion_id;

        $this->assign_data('RequestUrl', $url);
        return 'AdAnjuke';
    }

//    经纪人页面是my开头的域名，需要特殊处理，否则会跨域访问
    public function get_domain($cityid,$isBroker = 0) {
        $base_domain = APF::get_instance ()->get_config ( "base_domain" );
        if($isBroker){
            return Uri_Http::build_uri ( $base_domain, "my" );
        }
        $city_set = APF::get_instance ()->get_config ( "city_set", "multicity" );
        return User_Util_Url::build_uri ( $base_domain, $city_set[$cityid]['pinyin'] );
    }

    //获取控制器类的名称
    function get_class_name()
    {
        $controller_name = get_class(APF::get_instance()->get_current_controller());
        $page_name = substr($controller_name,0,-10);

        return $page_name;
    }
}
?>