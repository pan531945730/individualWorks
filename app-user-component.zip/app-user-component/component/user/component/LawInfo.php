<?php

class User_Component_LawInfoComponent extends APF_Component 
{    
    public function get_view() 
    {
        $arr_params = $this->get_params();
        
        foreach ($arr_params as $k => $v){
            $this->assign_data($k, $v);
        }

        return 'LawInfo';
    }
    public function get_style(){
        $style = $this->get_param('style');
        if(!$style){
            $matches = APF::get_instance()->get_request()->get_router_matches ();
            if(strtoupper($matches[1]) == 'D'){
                $style = 13;
            }
        }
        return $style;
    }
}