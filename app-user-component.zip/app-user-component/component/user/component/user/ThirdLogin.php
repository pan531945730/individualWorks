<?php

class User_Component_User_ThirdLoginComponent extends User_Component_AbstractComponent
{

    public static function use_boundable_styles()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "UserIconfont.css",
            $path . "ThirdLogin.css"
        );
    }

    public static function use_boundable_javascripts()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "ThirdLogin.js");
    }

    public function getView()
    {
        $this->assign_data('history',$this->get_history());
        return 'ThirdLogin';
    }

    public function getBaseUrl(){
        return User_Common_Util_Url_BaseUrl::buildMemberUrl();
    }

    private function get_history(){
        $history = $this->get_param('history');
        if(empty($history)) {
            $history = $this->get_param('location');
        }
        $base_domain = APF::get_instance()->get_config("base_domain");
        $isChat = $this->get_param('isChat');

        if($isChat){
            $history = base64_encode("http://chat.$base_domain");
        }
        return $history;
    }

    public function is_url($url){
        return preg_match("/^http:\/\/[A-Za-z0-9]+\.[A-Za-z0-9]+[\/=\?%\-&_~`@[\]\':+!]*([^<>\"])*$/", $url);
    }

    public function get_registerfrom() {
        $apf = APF::get_instance();
        $request = $apf->get_request();

        $referer = strpos($_SERVER['HTTP_REFERER'], '?') ? strstr($_SERVER['HTTP_REFERER'], '?', true) : $_SERVER['HTTP_REFERER'];
        #$referer = 'http://sh.yangcui.sp.dev.anjuke.com/shou/6635919';

        $anjuke_base_domain = str_replace('release.', '', $apf->get_config("anjuke_base_domain"));
        $xinfang_base_domain = str_replace('release.', '', $apf->get_config("xinfang_base_domain"));
        $zu_base_domain = str_replace('release.', '', $apf->get_config("zu_base_domain"));
        $xzl_base_domain = str_replace('release.', '', $apf->get_config("xzl_base_domain"));
        $sp_base_domain = str_replace('release.', '', $apf->get_config("sp_base_domain"));

        // 首页
        if(preg_match('/'.$anjuke_base_domain.'\/$/', $referer)){
            if(strpos($referer, $zu_base_domain)){
                return 'Site_Rent_Register_FL';
            }elseif(strpos($referer, $xinfang_base_domain)){
                return 'Site_XF_Register_LL';
            }elseif(strpos($referer, $xzl_base_domain)){
                return 'Site_XZL_Register_RL';
            }elseif(strpos($referer, $sp_base_domain)){
                return 'Site_SP_Register_BL';
            }else{
                return 'Site_Index_Register_ALL';
            }
        }

        // 问答
        if(preg_match('/'.$anjuke_base_domain.'\/(ask|league|fcleague|qaactivity)/', $referer)){
            return 'Site_QA_Register_ALL';
        }

        // 租房
        if(strpos($referer, $zu_base_domain)){
            if(preg_match('/\/xiaoqu\/(\d+)/', $referer)){
                return 'Site_Rent_Register_LP';
            }
            if(preg_match('/\/fangyuan\/(\d+)/', $referer)){
                return 'Site_Rent_Register_FP';
            }
            if(strpos($referer, "/xiaoqu")){
                return 'Site_Rent_Register_LL';
            }
            if(strpos($referer, "/fangyuan") || preg_match('/'.$zu_base_domain.'\/$/', $referer)){
                return 'Site_Rent_Register_FL';
            }
        }

        // 新房
        if(strpos($referer, $xinfang_base_domain)){
            if(preg_match('/\/loupan\/(\d+)/', $referer)){
                return 'Site_XF_Register_LP';
            }
            if(preg_match('/\/fangyuan\/(\d+)/', $referer)){
                return 'Site_XF_Register_FP';
            }
            if(strpos($referer, "/fangyuan/")){
                return 'Site_XF_Register_FL';
            }
            if(strpos($referer, "/loupan/") || preg_match('/'.$xinfang_base_domain.'\/$/', $referer)){
                return 'Site_XF_Register_LL';
            }
        }

        // 商铺
        if(strpos($referer, $sp_base_domain)){
            if(preg_match('/\/shou\/(\d+)/', $referer)){
                return 'Site_SP_Register_BP';
            }
            if(preg_match('/\/zu\/(\d+)/', $referer) || preg_match('/\/gzu\/(\d+)/', $referer)){
                return 'Site_SP_Register_RP';
            }
            if(preg_match('/\/wuye\/(\d+)/', $referer)){
                return 'Site_SP_Register_PP';
            }
            if(strpos($referer, "/shou")){
                return 'Site_SP_Register_BL';
            }
            if(strpos($referer, "/zu")){
                return 'Site_SP_Register_RL';
            }
            if(strpos($referer, "/wuye")){
                return 'Site_SP_Register_PL';
            }
        }

        // 写字楼
        if(strpos($referer, $xzl_base_domain)){
            if(preg_match('/\/shou\/(\d+)/', $referer)){
                return 'Site_XZL_Register_BP';
            }
            if(preg_match('/\/zu\/(\d+)/', $referer)){
                return 'Site_XZL_Register_RP';
            }
            if(preg_match('/\/loupan\/(\d+)/', $referer)){
                return 'Site_XZL_Register_LP';
            }
            if(strpos($referer, "/shou")){
                return 'Site_XZL_Register_BL';
            }
            if(strpos($referer, "/zu")){
                return 'Site_XZL_Register_RL';
            }
            if(strpos($referer, "/loupan")){
                return 'Site_XZL_Register_LL';
            }
        }

        // 二手房
        if(strpos($referer, $anjuke_base_domain)){
            if(preg_match('/prop\/view(yz)?\/(\d+)/', $referer)){
                return 'Site_ESF_Register_FP';
            }
            if(preg_match('/community\/view\/(\d+)/', $referer)){
                return 'Site_ESF_Register_LP';
            }
            if(strpos($referer, "/sale")){
                return 'Site_ESF_Register_FL';
            }
            if(strpos($referer, "/community")){
                return 'Site_ESF_Register_LL';
            }
        }

        return 'Site_Other';
    }

}

