<?php

class User_Component_User_UserHeaderComponent extends User_Component_AbstractComponent
{

    public static function use_boundable_styles()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "UserIconfont.css",
            $path . "UserHeader.css"
        );
    }

    public static function use_boundable_javascripts()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "UserHeader.js");
    }

    public function getView()
    {
        return 'UserHeader';
    }

}

