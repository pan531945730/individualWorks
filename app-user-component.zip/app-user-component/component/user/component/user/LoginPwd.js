window.user = {};
(function(U) {

    function userLogin() {
        var isShowAccountCode = false,
            code_tip = J.g('code-tip'),
            check_tip = J.g('check-tip'),
            check_tip_login_more = J.g('check-tip-login-more'),
            img_pcode_box = J.g('img-pcode-box'),
            img_pcode = img_pcode_box.s('.account-img').eq(0),
            img_pcode_tip,
            //img_pcode_tip = img_pcode_box.s('.error-tip').eq(0),
            account_tab = J.g('account-login'),
            account_img = account_tab.s('.account-img').eq(0),
            phone_tab = J.g('phone-login'),
            phone_img = phone_tab.s('.account-img').eq(0),
            phone_code = J.g('phone-code'),
            img_code = J.g('imgCode'),
            phone_code_tip = phone_code.s('p').eq(0),
            isChat = 0,
            chatLoginAfter;

        var title = J.s('.login-panel .login-title a');
        var cur_title = J.s('.curr-title').eq(0);

        function init(chatArg) {
            bindEvent();
            formValidate();
            if (chatArg) {
                isChat = chatArg.isChat;
                chatLoginAfter = chatArg.afterLogin;
            }
            J.s('.account-name').eq(0).val('');
            J.s('.account-pwd').eq(0).val('');
            J.g('phoneNum').val('');
            img_pcode_tip = document.createElement('p');
            img_pcode_tip = J.g(img_pcode_tip);
            img_pcode_tip.addClass('error-tip');
            img_pcode_tip.html("<i class='user-iconfont'>&#xe60f;</i>图片字符错误");
        }

        function bindEvent() {
            changeTab();

            var input_list = J.s('form .input-box input');
            input_list.each(function(j, w) {
                w.on('focus', function() {
                    check_tip.hide();
                    code_tip.hide();
                    !w.get().readOnly && w.addClass('onFocus');
                    w.removeClass('error-border');
                }).on('blur', function() {
                    w.removeClass('onFocus');
                });
            });

            var code_list = J.s('img');
            var args = Array.prototype.slice.call(J.s('.refresh'));
            Array.prototype.push.apply(code_list, args);

            code_list.each(function(i, v) {
                v.on('click', function() {
                    if (i < 2) {
                        v.attr('src', base_url + '/captcha?r=' + Math.random());
                    } else {
                        v.prev().attr('src', base_url + '/captcha?r=' + Math.random());
                    }

                }).on('mouseover', function() {
                    v.addClass('cur-pointer');
                }).on('mouseout', function() {
                    v.removeClass('cur-pointer');
                });
            });


            var submit_btn = J.s('.submit-btn');
            submit_btn.each(function(j, w) {
                w.on('mouseover', function() {
                    w.addClass('cur-pointer');
                }).on('mouseout', function() {
                    w.removeClass('cur-pointer');
                });
            });
        }

        function changeTab() {
            title.each(function(i, v) {
                v.on('click', function() {
                    if (i == 0) {
                        cur_title.addClass('l-pos');
                        cur_title.removeClass('r-pos');

                        title.eq(1 - i).removeClass('cur-font');
                        v.addClass('cur-font');

                        setTimeout(function() {
                            account_tab.show();
                            phone_tab.hide();
                        }, 300);

                    }
                    if (i == 1) {
                        cur_title.addClass('r-pos');
                        cur_title.removeClass('l-pos');

                        title.eq(1 - i).removeClass('cur-font');
                        v.addClass('cur-font');

                        setTimeout(function() {
                            phone_tab.show();
                            account_tab.hide();
                        }, 300);
                    }
                });

            });
        }

        function formValidate() {
            var pcode = J.g('phoneCode'),
                submit_btn = J.g('phone-submit'),
                t_dom = phone_code.s('em').eq(0),
                t = 59;

            (function() {
                var accountVali = account_tab.validate({
                    auto: false,
                    infoTagName: 'p', // 缺省如果提示信息元素不存在，那么创建的标签名称定义
                    classNames: {
                        error: 'error-tip',
                        success: 'success-tip',
                        tooltip: ''
                    },
                    onSuccess: function() {
                        checkAccountFormVal();
                    },

                    onError: function(formElm) {
                        setTimeout(function() {
                            var error_list = formElm.s('.error-tip');
                            error_list.each(function(j, w) {
                                w.up().s('input').eq(0).addClass('error-border');
                            });

                            checkAccountFormVal();
                        }, 10);
                    },
                    custom: {
                        accountCode: function(ele, callback) {
                            var s = ele.val().length < 4 && ele.val().length > 0 ? -1 : 1;
                            callback({
                                status: s
                            });
                        }
                    },
                    event: {
                        valueChange: function(ele) {
                            var v = ele.val();
                            if (v.length == 4) {
                                ajaxGet('/checkcaptcha/', {
                                        captcha: v
                                    },
                                    checkAccountCaptcha
                                );
                            }
                        }
                    }
                });

                var phoneVali = phone_tab.validate({
                    infoTagName: 'p', // 缺省如果提示信息元素不存在，那么创建的标签名称定义
                    classNames: {
                        info: '',
                        error: 'error-tip',
                        success: 'success-tip',
                        tooltip: ''
                    },
                    onSuccess: function() {
                        checkPhoneFormVal();
                    },

                    onError: function(formElm) {
                        checkPhoneFormVal();

                        var error_list = formElm.s('.error-tip');
                        error_list.each(function(j, w) {
                            var input_box = w.up().s('input').eq(0);
                            input_box.addClass('error-border');
                        });
                    },
                    custom: {
                        phoneNum: function(ele, callback) {
                            var reg = /^1[0-9]{10}$/;
                            var s = reg.test(ele.val()) ? 1 : -1;

                            if (s == 1) {
                                img_code.get().readOnly = '';

                                if (img_code.attr('event') == "false") {
                                    phoneVali.addElement(img_code, 'require$<i class="user-iconfont">&#xe60f;</i>请输入图片字符');
                                    phoneVali.addElement(img_code, 'event$blur|checkImgCode');
                                    phoneVali.addElement(img_code, 'event$focus|imgCodeDec');

                                    if (!+[1, ]) { //ie
                                        phoneVali.addElement(img_code, 'event$propertychange|valueChange');
                                    } else { //not ie
                                        phoneVali.addElement(img_code, 'event$input|valueChange');
                                    }
                                    img_code.attr('event', true);
                                }
                            } else {
                                img_code.get().readOnly = true;
                            }
                            callback({
                                status: s
                            });
                        }
                    },
                    event: {
                        valueChange: function(ele) {
                            var v = ele.val();
                            if (v.length == 4) {
                                ajaxGet('/checkcaptcha/', {
                                        captcha: v
                                    },
                                    checkPhoneCaptcha
                                );
                            }
                        },
                        checkImgCode: function(ele) {
                            if (ele.val() == '') {
                                ele.addClass('error-border');
                            }
                            if (ele.val().length < 4 && ele.val().length > 0) {
                                ele.addClass('error-border');
                                img_pcode.append(img_pcode_tip).show();
                            }
                        },
                        imgCodeDec: function(ele) {
                            img_pcode_tip.remove();
                        },
                        checkPhoneNum: function(ele) {
                            if (ele.val() == '') {
                                ele.addClass('error-border');
                            }
                        }
                    }
                });

                function checkAccountFormVal() {
                    check_tip.hide();
                    if (account_tab.s('.error-tip').length == 0) { //非空
                        ajaxGet('/api/login/submit', {
                                username: J.s('.account-name').eq(0).val(),
                                password: J.s('.account-pwd').eq(0).val(),
                                remember: J.g('account-remember').get().checked,
                                captcha : J.g('accountCode').val()
                            },
                            accountSubmit
                        );
                    }
                }

                function checkPhoneFormVal() {
                    var _href = window.location.href;
                    var _history = '';
                    var _arr = _href.match(/\?[^\#]+/g);
                    if(_arr){
                        var _splitArr = _arr[0].split('&');
                        for(var i = 0 ; i < _splitArr.length; i++){
                            var _strArr = _splitArr[i].match(/history=(.*)$/g);
                            if(_strArr){
                                _history = _strArr[0].replace('history=','');
                            }
                        }
                    }
                    if (phone_tab.s('.error-tip').length == 0) { //非空
                        ajaxGet('/api/login/phonesubmit', {
                                phone: J.g('phoneNum').val(),
                                code: phone_code.s('.code').eq(0).val(),
                                history: _history
                            },
                            phoneSubmit
                        );
                    }
                }

                function ajaxGet(url, data, callback, isEncode) {
                    //isEncode && (data = base64_encode(data));
                    J.get({
                        url: base_url + url, //user->？？member。。。  需要后端提共
                        type: 'jsonp',
                        data: data,
                        callback: 'window.user.callbackDetail'
                    });
                    window.user.callbackDetail = function() {
                        var args = Array.prototype.slice.call(arguments);
                        callback.apply(this, args);
                    }
                }

                function checkAccountCaptcha(rs) {
                    var ele = J.g('accountCode');
                    if (rs.code == 201) {
                        code_tip.show();
                        ele.removeClass('onFocus');
                        ele.addClass('error-border');
                    } else if (rs.code == 200) { //success
                        code_tip.hide();
                        ele.removeClass('onFocus');
                        ele.next().show();
                        ele.removeClass('error-border');
                    }
                }

                function checkPhoneCaptcha(rs) {
                    var ele = J.g('imgCode');
                    if (rs.code == 201) {
                        img_pcode.append(img_pcode_tip).show();
                        ele.removeClass('onFocus');
                        ele.addClass('error-border');
                    } else if (rs.code == 200) { //success
                        ele.removeClass('onFocus'); //???remove
                        ele.up().s('p').eq(0).hide();
                        phone_code.show();
                        pcode.val('');
                        img_pcode_box.removeClass('l-box').addClass('r-box');
                        phoneVali.addElement(pcode, 'require');
                        phoneVali.addElement(pcode, 'event$focus|PhoneCodeDec');
                        ajaxGet('/api/login/sendtophone', {
                                phone: J.g('phoneNum').val(),
                                captcha: ele.val()
                            },
                            sendPhoneCode
                        );
                    }
                }

                function par(url) {
                    var res = {}
                    var seg = url.search.replace(/^\?/, '').split('&'),
                        len = seg.length,
                        i = 0,
                        s;
                    for (; i < len; i++) {
                        if (!seg[i]) {
                            continue;
                        }
                        s = seg[i].split('=');
                        res[s[0]] = s.join('=').replace( new RegExp('^'+s[0]+'='),'');
                    }
                    return res;


                }

                function accountSubmit(rs) {
                    if (rs.status == 1) { //成功
                        J.site.trackEvent('common_login_success');
                        if (isChat) {
                            chatLoginAfter();
                            J.site.trackEvent('chat_login_success');
                        } else {
                            if (rs.url == '') {
                                var historyUrl = par(window.location).history;
                                if (historyUrl) {
                                    window.location.href = J.utils.base.decode(historyUrl);
                                } else {
                                    var referrer = document.referrer;
                                    if (referrer && referrer.indexOf('logout') < 0) {
                                        window.location.href = referrer;
                                    } else {
                                        window.location.href = 'http://anjuke.com';//'http://shanghai.cuizhuochen.dev.anjuke.com';
                                    }
                                }


                            } else {
                                if (rs.data) {
                                    window.location.href = rs.url + '?login_url=' + rs.data.login_url +
                                        '&bbscp=' + rs.data.other_verify_url.bbscp +
                                        '&aifang=' + rs.data.other_verify_url.aifang +
                                        '&anjukemy=' + rs.data.other_verify_url.anjukemy +
                                        '&myzufang=' + rs.data.other_verify_url.myzufang +
                                        '&myjinpu=' + rs.data.other_verify_url.myjinpu;
                                } else {
                                    window.location.href = rs.url;
                                }
                            }
                        }
                    } else if (rs.status == -1) {
                        check_tip.show();

                        if (!isShowAccountCode && rs.data > 5) { //是否出现验证码
                            isShowAccountCode = true;
                            account_img.show();
                            var account_code = J.g('accountCode');
                            accountVali.addElement(account_code, "require$<i class='user-iconfont'>&#xe60f;</i>请输入图片字符$$target$error-code-tip");
                            accountVali.addElement(account_code, "custom$<i class='user-iconfont'>&#xe60f;</i>图片字符错误$$target$error-code-tip");

                            if (!+[1, ]) { //ie
                                accountVali.addElement(account_code, 'event$propertychange|valueChange');
                            } else { //not ie
                                accountVali.addElement(account_code, 'event$input|valueChange');
                            }
                        }
                    } else if (rs.status == 5) {
                       check_tip_login_more.show(); 
                    } else if(rs.status == -100) {

                        // 强制出验证码
                        var error = rs.error;
                        check_tip.html( check_tip.html().replace("帐号或密码不正确", error) );
                        check_tip.show();

                        // 显示验证码
                        isShowAccountCode = true;
                        account_img.show();
                        var account_code = J.g('accountCode');
                        accountVali.addElement(account_code, "require$<i class='user-iconfont'>&#xe60f;</i>请输入图片字符$$target$error-code-tip");
                        accountVali.addElement(account_code, "custom$<i class='user-iconfont'>&#xe60f;</i>图片字符错误$$target$error-code-tip");

                        if (!+[1, ]) { //ie
                            accountVali.addElement(account_code, 'event$propertychange|valueChange');
                        } else { //not ie
                            accountVali.addElement(account_code, 'event$input|valueChange');
                        }
                    }
                }

                function phoneSubmit(rs) {
                    if (rs.status == 1) { //成功
                        J.site.trackEvent('phone_login_success');
                        if (isChat) {
                            J.site.trackEvent('chat_login_success');
                            chatLoginAfter();
                        } else {
                            if (rs.url == '') {
                                var referrer = document.referrer;
                                if (referrer && referrer.indexOf('logout') < 0) {
                                    history.go(-1);
                                } else {
                                    location.href = 'http://anjuke.com'; //'http://shanghai.cuizhuochen.dev.anjuke.com';
                                }
                            } else {
                                if (rs.data) {
                                    window.location.href = rs.url + '?login_url=' + rs.data.login_url +
                                        '&bbscp=' + rs.data.other_verify_url.bbscp +
                                        '&aifang=' + rs.data.other_verify_url.aifang +
                                        '&anjukemy=' + rs.data.other_verify_url.anjukemy +
                                        '&myzufang=' + rs.data.other_verify_url.myzufang +
                                        '&myjinpu=' + rs.data.other_verify_url.myjinpu;
                                } else {
                                    window.location.href = rs.url;
                                }
                            }
                        }
                    } else if (rs.status == 4) { //code error
                        phone_code_tip.attr('class', '').addClass('error-tip').html("<i class='user-iconfont'>&#xe60f;</i>手机验证码错误").show();
                    } else if (rs.status == 3) {
                        phone_code_tip.attr('class', '').addClass('error-tip').html("<i class='user-iconfont'>&#xe60f;</i>手机号码错误").show();
                    } else { //error   ??
                        phone_code_tip.attr('class', '').addClass('error-tip').html("<i class='user-iconfont'>&#xe60f;</i>登陆失败").show();
                    }
                }

                function sendPhoneCode(rs) {
                    var code_input = phone_code.s('.code').eq(0),
                        send_code = phone_code.s('.code-btn').eq(0);

                    if (rs.status == 5) {
                        //phone_code_tip.attr('class', '').addClass('error-tip').show().html('发送失败');
                        //code_input.get().focus();
                        addSendCodeListener(send_code);
                    } else if (rs.status == 4) {
                        phone_code_tip.attr('class', '').addClass('error-tip').html("<i class='user-iconfont'>&#xe60f;</i>您已达验证码发送上限，请明天再试").show();
                        send_code.un('click').attr('event', 'false').html('重新发送验证码');
                    } else if (rs.status == 3) {
                        phone_code_tip.attr('class', '').addClass('error-tip').html("<i class='user-iconfont'>&#xe60f;</i>手机号码错误").show();
                        J.g('phoneNum').get().focus();
                        addSendCodeListener(send_code);
                    } else if (rs.status == 1) {
                        phone_code_tip.attr('class', '').addClass('check-tip tip-font').html('验证码已发送至您手机，请查收！').show();
                        code_input.get().focus();
                        var handler = setInterval(function() {
                            phone_code.s('em').eq(0).html(--t);
                            if (t == 0) {
                                clearInterval(handler);
                                phone_code_tip.hide();
                                addSendCodeListener(send_code);
                            }
                        }, 1000);
                    }
                }

                function addSendCodeListener(send_btn) {
                    send_btn.removeClass('disable-btn').addClass('default-btn').html('重新发送验证码');
                    if (send_btn.attr('event') == 'false') {
                        send_btn.on('click', function() {
                            t = 59;
                            send_btn.removeClass('default-btn').addClass('disable-btn').html('<em>59</em>秒后重新发送');
                            img_pcode_box.s('img').eq(0).get().click();
                            img_pcode_box.s('.ok-tip').eq(0).hide();
                            img_code.val('');
                            phone_code.hide();
                            send_btn.un('click').attr('event', 'false');
                            img_pcode_box.removeClass('r-box').addClass('l-box');
                            phoneVali.removeElement(pcode, 'require');
                        }).attr('event', 'true');
                    }
                }

                img_code.on('click', function() {
                    if (this.readOnly) {
                        submit_btn.get().click();
                    }
                });
            }).require(['ui.validate'], ['ui.validate_def']);
        }

        return {
            init: init
        }
    }
    U.login = userLogin;
})(window.user);