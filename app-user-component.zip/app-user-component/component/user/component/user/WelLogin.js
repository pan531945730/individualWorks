(function(){
    var login = new window.user.login();
    login.init();
})();
