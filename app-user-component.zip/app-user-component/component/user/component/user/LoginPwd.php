<?php

class User_Component_User_LoginPwdComponent extends User_Component_AbstractComponent
{

    public static function use_boundable_styles()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "UserIconfont.css",
            $path . "LoginPwd.css"
        );
    }

    public static function use_boundable_javascripts()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "LoginPwd.js");
    }

    public function getView()
    {
        return 'LoginPwd';
    }

    public function getBaseUrl(){
        return User_Common_Util_Url_BaseUrl::buildMemberUrl();
    }

    public function getUserUrl(){
        return User_Common_Util_Url_BaseUrl::buildUserUrl();
    }

}

