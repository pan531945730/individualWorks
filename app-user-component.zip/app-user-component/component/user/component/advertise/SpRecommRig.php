<?php

class User_Component_Advertise_SpRecommRigComponent extends User_Component_AbstractComponent
{
    public function getView()
    {
        $this->assign_data('history',$this->get_param('history'));
        return 'SpRecommRig';
    }

    public static function use_boundable_styles()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "RecommRig.css"
        );
    }

    public static function use_boundable_javascripts()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "SpRecommSy.js");
    }
  
}

