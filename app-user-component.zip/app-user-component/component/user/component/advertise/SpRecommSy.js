;(function($){
    "use strict";
    APF.Namespace.register('XF.Syrecomm');
    var Syrecomm = XF.Syrecomm = function(op){
        var self = this;
        self.op = $.extend({}, Syrecomm._default, op);
        self._init();
    };
    Syrecomm._default = {
        url      : '',      //请求接口
        dataObj  : {fromCode : 'default'},    //输入参数
        contST   : '',      //容器
        recTep   : '',      //内容模板
        recInfo  : ''       //内容容器
    };
    Syrecomm.prototype._init = function(){
        var self = this, op = self.op;
        self._getInfo();
    };
    Syrecomm.prototype._getInfo = function(){
        var self = this, op=self.op;
        op.cont = $(op.contST);
        op.Info =op.cont.find(op.recInfo);
        var tpl = _.template( $(op.recTep).html() ); 
        $.ajax({
            url: op.url,
            type: 'GET',
            dataType: 'json',
            data: op.dataObj
        })
        .done(function(data) {
            if(data.data.length > 0){
                for (var i =0 ; i < data.data.length; i++ ){
                    data.data[i].from = op.dataObj.fromCode;
                }
                op.cont.show();
                op.Info.html(tpl(data.data)).show();
            }            
        });
        
    };

})(jQuery);


        