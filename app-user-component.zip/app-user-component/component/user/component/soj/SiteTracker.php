<?php
/**
 * 网站公共发送soj统计
 */
apf_require_class("APF_Component");

class User_Component_Soj_SiteTrackerComponent extends APF_Component{

	public function get_view(){
        $pageName = $this->get_param("pageName");
        $pageAliasName = $this->get_param("pageAliasName");
        if(empty($pageName) || empty($pageAliasName)){
            return false;
        }
        $this->assign_data('site', $this->get_param('site'));
		$this->assign_data('pageName', $pageName);
        $this->assign_data('pageAliasName', $pageAliasName);
        if(is_array($this->get_param("customParams"))){
            $customParams = json_encode($this->get_param("customParams"));
        }else{
            $customParams = NULL;
        }
		$this->assign_data('customParams', $customParams);
		$this->assign_data('fixReferer', APF::get_instance()->get_request()->get_attribute('fixReferer'));
		return 'SiteTracker';
	}

	public function getSojDomain(){
        return APF::get_instance()->get_config("soj_base_domain") ? APF::get_instance()->get_config("soj_base_domain") : "s.anjuke.com";
    }


    /**
     * 包含json2.js是为了低版本浏览器不支持json对象转字符串
     * 如果你要json对象转字符串，需要引用
     * @return array
    public static function use_boundable_javascripts(){
		$path = apf_classname_to_path(__CLASS__);
		return array($path.'json2.js');
	}
   */
}