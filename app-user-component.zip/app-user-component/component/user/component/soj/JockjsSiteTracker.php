<?php
/**
 * 网站公共发送soj统计
 */
apf_require_class("APF_Component");

class User_Component_Soj_JockjsSiteTrackerComponent extends APF_Component{

    public function get_view(){
        $pageName = $this->get_param("pageName");
        $pageAliasName = $this->get_param("pageAliasName");
        if(empty($pageName) || empty($pageAliasName)){
            return false;
        }
        $this->assign_data('site', $this->get_param('site'));
        $this->assign_data('pageName', $pageName);
        $this->assign_data('pageAliasName', $pageAliasName);
        if(is_array($this->get_param("customParams"))){
            $customParams = json_encode($this->get_param("customParams"));
        }else{
            $customParams = NULL;
        }
        $this->assign_data('customParams', $customParams);
        $this->assign_data('fixReferer', APF::get_instance()->get_request()->get_attribute('fixReferer'));
        return 'JockjsSiteTracker';
    }

    public function getSojDomain(){
        return APF::get_instance()->get_config("soj_base_domain") ? APF::get_instance()->get_config("soj_base_domain") : "s.anjuke.com";
    }

    public static function use_boundable_javascripts() {
        $path = apf_classname_to_path(__CLASS__);
        return array_merge(
            parent::use_boundable_javascripts(),
            array(
                $path ."bb.js",
                $path . "json2.js"
            )
        );
    }
}