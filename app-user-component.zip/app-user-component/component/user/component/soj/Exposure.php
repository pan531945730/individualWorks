<?php
apf_require_class('APF_Component');

class User_Component_Soj_ExposureComponent extends APF_Component {
    public function get_view() {
        $apf = APF::get_instance();
        $n_pn=$this->get_param("Page");
        $n_page=$this->get_param("PageName");

        $n_guid = $apf->get_config('cookie_n_guid');
        $n_mbid = $apf->get_config('cookie_n_member_id');

        $this->assign_data('n_guid', $n_guid);
        $this->assign_data('n_mbid', $n_mbid);
        $this->assign_data('n_pn', $n_page);
        $this->assign_data('n_page',$n_pn);
        return 'Exposure';
    }
}