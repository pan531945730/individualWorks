<?php

apf_require_class("APF_Component");
class User_Component_Soj_Tracker58Component extends APF_Component{
	public function get_view(){
		return 'Tracker58';
	}
}