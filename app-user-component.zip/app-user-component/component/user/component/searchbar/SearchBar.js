//首屏搜索框交互
(function() {

    var inputObj = J.g('glb_search0');
    var placeholder = (function(){
        var data = '';
        if( !historyData ){ return '' }
        if( historyData.recentComms && historyData.recentComms.length > 0 ){
            data = historyData.recentComms
        }
        if( historyData.hotComms && historyData.hotComms.length > 0 ){
            data = historyData.hotComms
        }
        if( data === '' ){
            return data
        }else{
            var _length = data.length;
            return data[(Math.floor(Math.random() *_length)) % _length].comm_name || '';
        }
    })();
        //defaultText = '请输入楼盘名称，地址或房源特征';//默认提示信息
    var otherBtn = J.g('otherBtn');
    var isCloseTrack = false;//当关闭标签以后的focus不发送统计
    var isDefault = false;
    var close = J.g('home_close');

    init();

    function init() {
        var autoTarget = autocomplete(inputObj);
        inputObj.val() ? close.show():'';

        bindEvent();

        function bindEvent() {
            //input输入框右侧关闭按钮
            close && close.on('click', function(e) {
                e.stop();
                isCloseTrack = true;
                //J.site.trackEvent(close.attr('data-tracker'));
                inputObj.val('');
                close.hide();
                autoTarget.hide();
                inputObj.get().focus();
            });

            //提交按钮submit
            var btnSubmit = J.g('btnSubmit');

            //提交之前做的验证
            btnSubmit && btnSubmit.on('click', function() {
              //  J.site.trackEvent('Ershou_Web_Home_HomePage_searchBtn_click_all');
            });
        }
    }

    function isEmptyObject(obj) {
        for (var i in obj) {
            return false;
        }
        return true;
    }

    function cloneObj(obj) {
        if (typeof(obj) != 'object') {
            return obj;
        }
        var re = {};
        obj.constructor == Array ? re = [] : '';
        for (var i in obj) {
            re[i] = cloneObj(obj[i]);
        }
        return re;
    }

    function autocomplete(inputObj) {
        var is_contain_num = null;

        var r = {
            cache: true,
            width: 478,
            placeholder: placeholder,//inputObj.attr('placeholder'),
            params: {
                c: cityId,//cityID
                n: 10, //获取数据的条数
                g: 2, //后台数据total_info是否传递(以前老接口中的)
                t: type
            },
            offset: {
                x: 0,
                y: 1
            },
            url:  '/v3/ajax/indexautocomplete/', // '/ajax/indexautocomplete/',老框架
            tpl: 'autocomplete_ajk',
            toggleClass: 'on-border',

            source: function(params, response, sendHandler) {
                /*
                 * type = 1: 二手房，有默认数据
                 *       = 2: 新房； =3：租房； =4：买写字楼； =5：租写字楼； =6：买商铺； =7：租商铺，无默认数据
                 * */
                //二手房
                if (type == 1 && !isEmptyObject(historyData) && (!inputObj.val().trim() || inputObj.val().trim() === historyData.defaultKW)) {
                    isDefault = true;//显示的默认数据
                    var cloneHistoryData = cloneObj(historyData);
                    //添加标题
                    if (cloneHistoryData.recentComms && cloneHistoryData.recentComms.length) {
                        cloneHistoryData.recentComms.unshift({
                            name: '<label style="color: #999;">最近看过</label>',
                            isSkip: true
                        });
                    } else {
                        cloneHistoryData.recentComms = [];
                    }
                    if (cloneHistoryData.hotComms && cloneHistoryData.hotComms.length) {
                        cloneHistoryData.hotComms.unshift({
                            name: '<label style="color: #f60;">热门搜索</label>',
                            isSkip: true
                        });
                    }
                    var data = cloneHistoryData.recentComms && cloneHistoryData.recentComms.concat(cloneHistoryData.hotComms);

                    response(data);
                    return;
                }

                //非二手房
                isDefault = false;//非二手房无默认数据
                sendHandler.call(this, params, function(data) {
                    if (!data) return;
                    if (type == 2) {
                        response(data);

                    } else {
                        is_contain_num = data.is_contain_num;
                        response(data.list);
                    }
                });
            },

            onFocus: function() {
                searchWord ? '' : inputObj.val('');
                inputObj.addClass('on-border');

                inputObj.val() ? close.show():close.hide();
                /*(type == 1 && historyData && inputObj.val() == historyData.defaultKW) ? inputObj.val('') : '';
                inputObj.val() == defaultText ? inputObj.val('') : '';*/
               // !isCloseTrack && J.site.trackEvent('Ershou_Web_Home_HomePage_searchInput_focus_all');
                //isCloseTrack = false;
            },

            onBlur: function() {
                inputObj.removeClass('on-border');

                if (type == 1 && !inputObj.val() && historyData) {
                    defVal ? inputObj.val(defVal) : inputObj.val(historyData.defaultKW);
                    return;
                }
                !inputObj.val() && inputObj.val(placeholder);
            },

            onKeyUp: function() {
                var closeObj = J.g('home_close');
                inputObj.val() ? closeObj.show() : closeObj.hide();
            },

            onChange: function(item) {
                inputObj.val(item.v.replace(/<[^>]+>/g, ""));
            },

            itemBuild: function(item) {
                //isDefault表示二手房显示最热搜索等
                item.comm_name ? item.name = item.comm_name : '';
                if (isDefault && item.name) {
                    //标题
                    if (item.isSkip) {
                        return {
                            l: item.l,
                            v: item.v,
                            isSkip: item.isSkip
                        }
                    }
                    item.region = item.area_name + '&nbsp;&nbsp;' + item.block_name;
                    var region = item.region ? ('<label style="color: #999;margin-left: 1em;">' + item.region + '</label>' + '<i style="color: #999">约' + item.props_num + '套</i>') : '';
                    return {
                        l: (item.desc ? item.desc : item.name) + region,
                        v: item.name,
                        isSkip: item.isSkip
                    }
                }
                if (type == 2) {
                    return item;
                }
                var number = item.isFilter ? item.keyword + '<i>' + item.num + '</i>' : (is_contain_num ? item.keyword + '<i>约' + item.num + '套</i>' : item.keyword);
                return {
                    l: number,
                    v: item.keyword
                }
            }
        };

        return inputObj.autocompleteV2(r);
    }

}).require(['ui.autocompleteSite'], ['ui.autocomplete_ajk'], true);