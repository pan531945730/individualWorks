<?php

class User_Component_SearchBar_SearchBarComponent extends User_Component_AbstractComponent
{

    public static function use_boundable_styles()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "SearchBar.css");
    }

    public static function use_boundable_javascripts()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "SearchBar.js");
    }

    public function getView()
    {
        /*
         * type = 1: 二手房，有默认数据
         *       = 2: 新房； =3：租房； =4：买写字楼； =5：租写字楼； =6：买商铺； =7：租商铺，无默认数据
         *
         */

        //$this->assign_data('searchType', $this->get_param('searchType'));

        return "SearchBar";
    }

}

?>
