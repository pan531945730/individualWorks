<?php
abstract class User_Component_AbstractComponent extends APF_Component {

    /** * * @var APF
     */
    protected $apf;

    /**
     *
     * @var APF_Request
     */
    protected $request;

    /**
     *
     * @var APF_Response
     */
    protected $response;

    public function get_view() {
        $this->apf = Apf::get_instance();
        $this->request = $this->apf->get_request();
        $this->response = $this->apf->get_response();

        $arr_params = $this->get_params();
        foreach ($arr_params as $k => $v){
            $this->assign_data($k, $v);
        }

        return $this->getView();
    }
    
    abstract public function getView();
    
}
