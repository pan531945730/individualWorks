<?php
apf_require_class('APF_Component');

class User_Component_Sojv2_ExposureComponent extends APF_Component {
    public function get_view() {
        return 'Exposure';
    }

    public static function use_boundable_javascripts(){
        $path = apf_classname_to_path(__CLASS__);
        return array($path.'Exposure.js');
    }
}