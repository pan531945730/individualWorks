;
(function($, C, win, apf) {

    C.Exposure = function(op) {
        var defaults = {
            trackTag: 'data-trace',
            delay: 50,
            pageName: apf.info.pageName,
            prefix: 'Exp_'
        };
        this.ops = $.extend(defaults, op);
        this.domCache = []; // 保存内容
        this.pageViewHeight = $(win).height(); // 页面可视区域高度
        this.timer = null;
        this.dataCache = [];
        this.expStatus = false;
        this.init();
    };
    C.Exposure.prototype = {
        constructor: C.Exposure,
        add: function(list) {
            var _this = this;
            this.expStatus = true;
            list.each(function(index, el) {
                _this.domCache.push($(el));
            });
            $(win).scroll();
        },
        init: function() {
            var wd = $(win);
            wd.resize($.proxy(this.resize, this)); // resize
            wd.on('beforeunload', $.proxy(this.beforeunload, this));
            $(win).scroll($.proxy(this.scroll, this));
        },
        resize: function() {
            this.pageViewHeight = $(win).height();
        },
        beforeunload: function() {
            this.buildData();
        },
        scroll: function() {
            if (!this.expStatus) {
                return;
            }
            clearTimeout(this.timer);
            if (this.domCache.length === 0) {
                this.expStatus = false;
                this.buildData();
                return;
            }
            this.timer = setTimeout($.proxy(this.addData, this), this.ops.delay);
        },
        sendExp: function(result) {
            apf.Utils.trackEvent(this.ops.prefix + this.ops.pageName, result);
        },
        addData: function() {
            var pageViewHeight = this.pageViewHeight,
                topY = $(win).scrollTop(),
                botY = topY + pageViewHeight,
                _this = this;
            if (this.domCache.length === 0) {
                return;
            }
            $.each(this.domCache, function(index, val) {
                var _topY,
                    attr;
                if (!val) {
                    return;
                }
                _topY = val.offset ? val.offset().top : 0;
                if (_topY > topY && _topY < botY) {
                    attr = val.attr(_this.ops.trackTag);
                    if (attr) {
                        _this.dataCache.push(attr);
                    }
                    delete _this.domCache[index];
                }
            });
            this.buildData();
        },
        buildData: function() {
            var _this = this,
                result = {},
                r = [],
                exp,
                key,
                length,
                i;
            /**
             * "{aa:'123'}"
             * 这种格式的数据JSON.parse解析不了，必须用eval才能转成json
             */
            if (this.dataCache.length === 0) { // 如果没有数据就不发送
                return;
            }
            exp = eval('([' + this.dataCache.join(',') + '])');
            this.dataCache = []; // 清除要发送的数据
            for (i = 0, length = exp.length; i < length; i++) {
                for (key in exp[i]) {
                    if (!result[key]) {
                        result[key] = [];
                    }
                    result[key].push(exp[i][key]);
                }
            }
            for (key in result) { // 不考虑兼容pc 此循环可以用JSON.stringify替换
                r.push('"' + key + '"' + ':[' + result[key].join(',') + ']');
            }
            this.sendExp('{"exposure":{' + r.join(',') + '}}');
            $.each(this.domCache, function(index, val) {
                if (!val) {
                    _this.domCache.splice(index, 1); // 删除已统计过的dom
                }
            });
        }
    };
})(Zepto, APF.Namespace.register('module.soj'), window, APF);