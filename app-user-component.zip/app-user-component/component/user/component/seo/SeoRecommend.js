(function(){

    if(AJK.SeoRecommend.type == 0){
        var tag = 1;
        var parent_list = getByClassName('tab-'+tag);
        setEvent(parent_list, tag, 1);
    }else if(AJK.SeoRecommend.type == 1){
        var tag = 2;
        var parent_list = getByClassName('parent-'+tag);
        setListEvent(parent_list, tag);
    }

    function setListEvent(parent, tag){

        for(var i = 0; i < parent.length; i++){
            var v = parent[i];
            var cs = v.getElementsByTagName('ul');
            var ps = v.getElementsByTagName('li');
            if(cs.length){
                for(var j = 0; j < ps.length ; j++){
                    var tabLi = ps[j];
                    if(hasClass(tabLi,'tab-' + tag)){
                        (function(cs,ps,j,tabLi){
                            tabLi.onmouseover = function(){
                                for(var z = 0; z < cs.length ; z++){
                                    removeClass(cs[z], 'btn-show');
                                }
                                for(var z = 0; z < ps.length ; z++){
                                    removeClass(ps[z].getElementsByTagName('a')[0],'current-tab');
                                }
                                addClass(cs[j],'btn-show');
                                addClass(tabLi.getElementsByTagName('a')[0],'current-tab');
                            }
                        })(cs,ps,j,tabLi);
                    };
                }
                setListEvent(cs, tag+1);
            }
        }
    }

    function setEvent(parent, tag, isBut){

        if(parent.length){
            var child = new Array(), tempParent = parent[0].parentNode.getElementsByTagName('ul');
            for(var i = 0; i < tempParent.length; i++){
                hasClass(tempParent[i],'parent-'+(tag+1)) && child.push(tempParent[i]);
            }
            if(child.length){
                for(var i = 0; i < parent.length; i++){
                    var v = parent[i];
                    (function(child,parent,i,v,isBut){
                        v.onmouseover = function(){
                            for(var j = 0; j < child.length; j++){
                                removeClass(child[j],'btn-show');
                            }
                            for(var j = 0; j < parent.length; j++){
                                removeClass(parent[j].getElementsByTagName('a')[0],'current-tab');
                            }
                            addClass(child[i],'btn-show');
                            addClass(v.getElementsByTagName('a')[0],'btn-show');
                            if(isBut){
                                for(var k = 0; k < parent.length; k++){
                                    removeClass(parent[k].getElementsByTagName('a')[0],'cur');
                                }
                                addClass(v.getElementsByTagName('a')[0],'cur');
                            }
                        }
                    })(child,parent,i,v,isBut);
                }
                tag++;
                for(var z = 0; z < child.length; z++){
                    var arr = []
                    for(var n = 0; n < child[z].getElementsByTagName('li').length; n++){
                        hasClass(child[z].getElementsByTagName('li')[n],'tab-' + tag) && arr.push(child[z].getElementsByTagName('li')[n]);
                    }
                    setEvent(arr, tag, 0);
                }
            }
        }
    }

    function hasClass(obj, cls) {
        return obj.className.match(new RegExp('(\\s|^)' + cls + '(\\s|$)'));
    }

    function addClass(obj, cls) {
        if (!hasClass(obj, cls)) obj.className += " " + cls;
    }

    function removeClass(obj, cls) {
        if (hasClass(obj, cls)) {
            var reg = new RegExp('(\\s|^)' + cls + '(\\s|$)');
            obj.className = obj.className.replace(reg, '');
        }
    }

    function getByClassName(className){    
        if(document.getElementByClassName){    
            return document.getElementByClassName(className) 
        }    
        var nodes=document.getElementsByTagName("*");
        var arr=[];   
        for(var i=0;i<nodes.length;i++){    
            if(hasClass(nodes[i],className)) arr.push(nodes[i]);    
        }    
        return arr;    
    }  
})();
