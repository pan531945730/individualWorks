<?php
class User_Component_Seo_SeoRecommendComponent extends User_Component_AbstractComponent{
    public static function use_boundable_styles()
    {

        $path = apf_classname_to_path(__CLASS__);
        $type = intval(APF::get_instance()->get_request()->get_attribute("seo_type"));

        if($type == 0){
            // ButtonTpl.css
            // tab样式
            $result= array_merge(
                parent::use_boundable_styles(), array(
                    $path . "Base.css",
                    //$path.$cssFile,
                    $path . 'ButtonTpl.css'
                )
            );
        }else if($type == 2){
            //PartnerTpl.css
            // 友链 对齐
            $result= array_merge(
                parent::use_boundable_styles(), array(
                    $path . "Base.css",
                    //$path.$cssFile,
                    $path . 'PartnerTpl.css'
                )
            );
        }else{
            // ListTpl.css
            // 列表形式
            $result= array_merge(
                parent::use_boundable_styles(), array(
                    $path . "Base.css",
                    //$path.$cssFile,
                    $path . 'ListTpl.css'
                )
            );
        }
        return $result;
    }

    public static function use_boundable_javascripts()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array_merge(parent::use_boundable_javascripts(), array($path . "SeoRecommend.js"));
    }

    public function getView()
    {
        $this->assign_data('seoData', APF::get_instance()->get_request()->get_attribute("new_seo_footer_recommend_data"));
        $type = APF::get_instance()->get_request()->get_attribute("seo_type");
        $this->assign_data('type', $type);

        return "SeoRecommend";
    }
}
