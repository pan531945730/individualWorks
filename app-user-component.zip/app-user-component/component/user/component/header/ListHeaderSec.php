<?php
/**
 * Created by PhpStorm.
 * User: benlinhuo
 * Date: 8/8/14
 * Time: 5:23 PM
 */

class User_Component_Header_ListHeaderSecComponent extends User_Component_AbstractComponent
{

    public static function use_component()
    {
        return array_merge(
            parent::use_component(), array(
                "User_Component_Header_CitySelectorNew",
                "User_Component_Header_TabBarNew",
            )
        );
    }

    public static function getClassNameByTitle($parentTitle, $title)
    {
        if ($parentTitle == '新房' && $title == '新盘') {
            return 'link_xinfang';
        } else if ($parentTitle == '二手房' && $title == '房源') {
            return 'link_ershoufang';
        } else if ($parentTitle == '租房' && $title == '房源') {
            return 'link_zufang';
        } else if ($parentTitle == '商业地产' && $title == '写字楼出租') {
            return 'link_shangyedichan';
        }
        return '';
    }

    public static function use_boundable_styles()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array(
            $path . "ListHeader.css",
            $path . "ListHeaderSec.css"
        );
    }

    public static function use_boundable_javascripts()
    {

        $path = apf_classname_to_path(__CLASS__);
        return array($path . "ListHeaderSec.js");
    }

    public function getView()
    {
        $objAPF = APF::get_instance();
        $objRequest = $objAPF->get_request();
        $cityId = $objRequest->getCityId();
        $actived = $this->get_page()->getActivedTab();
        if ($actived == 'baike') {
            $actived = 'question';
        }

       /* $url = 'http://shanghai.app-ershou-web.benlinhuo.dev.anjuke.com/getNavInfo/';
       $data = Apf_Http_CurlClient::getInstance()->doGet($url, '');
        if($data){
            $cityTabs = json_decode($data, 1);
        }else{
            $cityTabs = $this->getCityTabs($cityId);
        }*/
        $cityTabs = User_Common_Uri_Navigation::getNewCityTabs($cityId);


       // $cityTabs = User_Common_Uri_Navigation::getCityTabs($cityId);

        $currentNavFirst = $this->geCurrentNavFirst($actived, $cityTabs);
        $this->assign_data('currentNavFirst', $currentNavFirst);
        $this->assign_data('isHaveNavSecond', $this->isHaveNavSecond($currentNavFirst, $cityTabs));
        $this->assign_data('actived', $actived);
        $this->assign_data('cityTabs', $cityTabs);

        return 'ListHeaderSec';
    }

    /**
     * 获得导航
     */
    private function getCityTabs($cityId){
        return User_Common_Uri_Navigation::getCityTabs($cityId);
    }

    /**
     * 获得当前焦点的一级导航
     */
    public function geCurrentNavFirst($actived,$cityTabs){
        foreach($cityTabs as $k => $tab){
            if($k==$actived || in_array($actived,array_keys($tab['navSecond']))){
                return $k;
            }
        }
        return false;
    }

    /**
     * 是否有二级导航
     * @param $currentNavFirst
     * @param $cityTabs
     * @return bool
     */
    public function isHaveNavSecond($currentNavFirst,$cityTabs){
        return $currentNavFirst && isset($cityTabs[$currentNavFirst]['navSecond']);
    }

    protected function getCityName()
    {
        $cities = APF::get_instance()->get_config("cities", "multicity");
        $city_id = APF::get_instance()->get_request()->getCityId();
        return $cities[$city_id];
    }

    protected function getCityUrl()
    {
        $city_set = APF::get_instance()->get_config("city_set", "multicity");
        $city_id = APF::get_instance()->get_request()->getCityId();
        $base_domain = APF::get_instance()->get_config('base_domain');
        return User_Common_Util_Url::buildUri($base_domain, $city_set[$city_id]['pinyin']);
    }

    /**
     * 获得第三方登录地址
     * @param string $name
     * @return string
     */
    protected function getExtLoginUrl($name)
    {
        $back_url = "http://" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"];
        $base_domain = "http://" . APF::get_instance()->get_config('base_domain');
        $member_domain = "http://member." . strstr($base_domain, "anjuke.");
        return $name == 'extlogin_qq' ? $member_domain . "/extlogin/?sid=anjuke&url=" . base64_encode($back_url) . "&logintype=qq" : $member_domain . "/extlogin/?sid=anjuke&url=" . base64_encode($back_url) . "&logintype=weibo";
    }

    protected function getHeaderIFX() {
        $ifxs = APF::get_instance()->get_request()->get_attribute("header_IFX");
        return empty($ifxs) ? array() : $ifxs;
    }


}


