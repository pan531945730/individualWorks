<?php
class User_Component_Header_BreadCrumbsBarComponent extends User_Component_AbstractComponent
{
    public static function use_boundable_styles()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array("{$path}BreadCrumbsBar.css");
    }

    public function getView()
    {
    	$this->assign_data('bread_crumbs_data', $this->get_param('bread_crumbs_data'));
        return 'BreadCrumbsBar';
    }
}
