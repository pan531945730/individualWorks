<?php

class User_Component_Header_CitySelectorComponent extends User_Component_AbstractComponent
{

    public static function use_boundable_styles()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "CitySelector.css");
    }

    public static function use_boundable_javascripts()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "CitySelector.js");
    }

    public function getView()
    {
        $this->assign_data('base_domain', APF::get_instance()->get_config("base_domain"));
        $this->assign_data('more_city_url', User_Common_Util_Url::buildMoreCity());
        $actived = $this->get_page()->getActivedTab();
        if ($actived == 'baike') {
            $actived = 'question';
        }
        $cityTabs = $this->getCityTabs();
        $currentNavFirst = $this->geCurrentNavFirst($actived, $cityTabs);
        $this->assign_data('currentNavFirst', $currentNavFirst);
        return "CitySelector";
    }

    public function getCityList()
    {
        $cities = APF::get_instance()->get_config("cities", "multicity");
        $city = array(
            "华北东北" => array(
                User_Common_Const_MultiCity::CITY_ID_BEIJING => $cities[User_Common_Const_MultiCity::CITY_ID_BEIJING],
                User_Common_Const_MultiCity::CITY_ID_TIANJIN => $cities[User_Common_Const_MultiCity::CITY_ID_TIANJIN],
                User_Common_Const_MultiCity::CITY_ID_DALIAN => $cities[User_Common_Const_MultiCity::CITY_ID_DALIAN],
                User_Common_Const_MultiCity::CITY_ID_SHIJIAZHUANG => $cities[User_Common_Const_MultiCity::CITY_ID_SHIJIAZHUANG],
                User_Common_Const_MultiCity::CITY_ID_HAERBIN => $cities[User_Common_Const_MultiCity::CITY_ID_HAERBIN],
                User_Common_Const_MultiCity::CITY_ID_SHENYANG => $cities[User_Common_Const_MultiCity::CITY_ID_SHENYANG],
                User_Common_Const_MultiCity::CITY_ID_TAIYUAN => $cities[User_Common_Const_MultiCity::CITY_ID_TAIYUAN],
                User_Common_Const_MultiCity::CITY_ID_CHANGCHUN => $cities[User_Common_Const_MultiCity::CITY_ID_CHANGCHUN],
//                User_Common_Const_MultiCity::CITY_ID_WEIFANG=>$cities[User_Common_Const_MultiCity::CITY_ID_WEIFANG],
//                User_Common_Const_MultiCity::CITY_ID_HUHEHAOTE=>$cities[User_Common_Const_MultiCity::CITY_ID_HUHEHAOTE],
//                User_Common_Const_MultiCity::CITY_ID_TANGSHAN=>$cities[User_Common_Const_MultiCity::CITY_ID_TANGSHAN],
//                User_Common_Const_MultiCity::CITY_ID_QINHUANGDAO=>$cities[User_Common_Const_MultiCity::CITY_ID_QINHUANGDAO],
//                User_Common_Const_MultiCity::CITY_ID_WEIHAI=>$cities[User_Common_Const_MultiCity::CITY_ID_WEIHAI],
//                User_Common_Const_MultiCity::CITY_ID_JILIN=>$cities[User_Common_Const_MultiCity::CITY_ID_JILIN],
//                User_Common_Const_MultiCity::CITY_ID_LANGFANG=>$cities[User_Common_Const_MultiCity::CITY_ID_LANGFANG],
//                User_Common_Const_MultiCity::CITY_ID_BAODING=>$cities[User_Common_Const_MultiCity::CITY_ID_BAODING],
//                User_Common_Const_MultiCity::CITY_ID_HANDAN=>$cities[User_Common_Const_MultiCity::CITY_ID_HANDAN]
            ),
            "华东地区" => array(
                User_Common_Const_MultiCity::CITY_ID_SHANGHAI => $cities[User_Common_Const_MultiCity::CITY_ID_SHANGHAI],
                User_Common_Const_MultiCity::CITY_ID_HANGZHOU => $cities[User_Common_Const_MultiCity::CITY_ID_HANGZHOU],
                User_Common_Const_MultiCity::CITY_ID_SUZHOU => $cities[User_Common_Const_MultiCity::CITY_ID_SUZHOU],
                User_Common_Const_MultiCity::CITY_ID_NANJING => $cities[User_Common_Const_MultiCity::CITY_ID_NANJING],
                User_Common_Const_MultiCity::CITY_ID_WUXI => $cities[User_Common_Const_MultiCity::CITY_ID_WUXI],
                User_Common_Const_MultiCity::CITY_ID_JINAN => $cities[User_Common_Const_MultiCity::CITY_ID_JINAN],
                User_Common_Const_MultiCity::CITY_ID_QINGDAO => $cities[User_Common_Const_MultiCity::CITY_ID_QINGDAO],
                User_Common_Const_MultiCity::CITY_ID_KUNSHAN => $cities[User_Common_Const_MultiCity::CITY_ID_KUNSHAN],
                User_Common_Const_MultiCity::CITY_ID_NINGBO => $cities[User_Common_Const_MultiCity::CITY_ID_NINGBO],
                User_Common_Const_MultiCity::CITY_ID_NANCHANG => $cities[User_Common_Const_MultiCity::CITY_ID_NANCHANG],
                User_Common_Const_MultiCity::CITY_ID_FUZHOU => $cities[User_Common_Const_MultiCity::CITY_ID_FUZHOU],
                User_Common_Const_MultiCity::CITY_ID_HEFEI => $cities[User_Common_Const_MultiCity::CITY_ID_HEFEI],
//                User_Common_Const_MultiCity::CITY_ID_CHANGZHOU=>$cities[User_Common_Const_MultiCity::CITY_ID_CHANGZHOU],
//                User_Common_Const_MultiCity::CITY_ID_JIAXING=>$cities[User_Common_Const_MultiCity::CITY_ID_JIAXING],
//                User_Common_Const_MultiCity::CITY_ID_YANTAI=>$cities[User_Common_Const_MultiCity::CITY_ID_YANTAI],
//                User_Common_Const_MultiCity::CITY_ID_YANGZHOU=>$cities[User_Common_Const_MultiCity::CITY_ID_YANGZHOU],
//                User_Common_Const_MultiCity::CITY_ID_XUZHOU=>$cities[User_Common_Const_MultiCity::CITY_ID_XUZHOU],
//                User_Common_Const_MultiCity::CITY_ID_NANTONG=>$cities[User_Common_Const_MultiCity::CITY_ID_NANTONG],
//                User_Common_Const_MultiCity::CITY_ID_ZHENJIANG=>$cities[User_Common_Const_MultiCity::CITY_ID_ZHENJIANG],
//                User_Common_Const_MultiCity::CITY_ID_SHAOXING=>$cities[User_Common_Const_MultiCity::CITY_ID_SHAOXING]
            ),
            "华南地区" => array(
                User_Common_Const_MultiCity::CITY_ID_SHENZHEN => $cities[User_Common_Const_MultiCity::CITY_ID_SHENZHEN],
                User_Common_Const_MultiCity::CITY_ID_GUANGZHOU => $cities[User_Common_Const_MultiCity::CITY_ID_GUANGZHOU],
                User_Common_Const_MultiCity::CITY_ID_FOSHAN => $cities[User_Common_Const_MultiCity::CITY_ID_FOSHAN],
                User_Common_Const_MultiCity::CITY_ID_CHANGSHA => $cities[User_Common_Const_MultiCity::CITY_ID_CHANGSHA],
                User_Common_Const_MultiCity::CITY_ID_SANYA => $cities[User_Common_Const_MultiCity::CITY_ID_SANYA],
                User_Common_Const_MultiCity::CITY_ID_HUIZHOU => $cities[User_Common_Const_MultiCity::CITY_ID_HUIZHOU],
                User_Common_Const_MultiCity::CITY_ID_DONGGUAN => $cities[User_Common_Const_MultiCity::CITY_ID_DONGGUAN],
                User_Common_Const_MultiCity::CITY_ID_HAIKOU => $cities[User_Common_Const_MultiCity::CITY_ID_HAIKOU],
                User_Common_Const_MultiCity::CITY_ID_ZHUHAI => $cities[User_Common_Const_MultiCity::CITY_ID_ZHUHAI],
                User_Common_Const_MultiCity::CITY_ID_ZHONGSHAN => $cities[User_Common_Const_MultiCity::CITY_ID_ZHONGSHAN],
                User_Common_Const_MultiCity::CITY_ID_XIAMEN => $cities[User_Common_Const_MultiCity::CITY_ID_XIAMEN],
//                User_Common_Const_MultiCity::CITY_ID_NANNING=>$cities[User_Common_Const_MultiCity::CITY_ID_NANNING],
//                User_Common_Const_MultiCity::CITY_ID_SANYA=>$cities[User_Common_Const_MultiCity::CITY_ID_SANYA],
//                User_Common_Const_MultiCity::CITY_ID_HUIZHOU=>$cities[User_Common_Const_MultiCity::CITY_ID_HUIZHOU],
//                User_Common_Const_MultiCity::CITY_ID_QUANZHOU=>$cities[User_Common_Const_MultiCity::CITY_ID_QUANZHOU],
//                User_Common_Const_MultiCity::CITY_ID_GUILIN=>$cities[User_Common_Const_MultiCity::CITY_ID_GUILIN]
            ),
            "中 西 部" => array(
                User_Common_Const_MultiCity::CITY_ID_CHENGDU => $cities[User_Common_Const_MultiCity::CITY_ID_CHENGDU],
                User_Common_Const_MultiCity::CITY_ID_CHONGQING => $cities[User_Common_Const_MultiCity::CITY_ID_CHONGQING],
                User_Common_Const_MultiCity::CITY_ID_WUHAN => $cities[User_Common_Const_MultiCity::CITY_ID_WUHAN],
                User_Common_Const_MultiCity::CITY_ID_ZHENGZHOU => $cities[User_Common_Const_MultiCity::CITY_ID_ZHENGZHOU],
                User_Common_Const_MultiCity::CITY_ID_XIAN => $cities[User_Common_Const_MultiCity::CITY_ID_XIAN],
                User_Common_Const_MultiCity::CITY_ID_KUNMING => $cities[User_Common_Const_MultiCity::CITY_ID_KUNMING],
                User_Common_Const_MultiCity::CITY_ID_GUIYANG => $cities[User_Common_Const_MultiCity::CITY_ID_GUIYANG],
                User_Common_Const_MultiCity::CITY_ID_LANZHOU => $cities[User_Common_Const_MultiCity::CITY_ID_LANZHOU],
                User_Common_Const_MultiCity::CITY_ID_LUOYANG => $cities[User_Common_Const_MultiCity::CITY_ID_LUOYANG],
//                User_Common_Const_MultiCity::CITY_ID_YICHANG=>$cities[User_Common_Const_MultiCity::CITY_ID_YICHANG],
//                User_Common_Const_MultiCity::CITY_ID_YINCHUAN=>$cities[User_Common_Const_MultiCity::CITY_ID_YINCHUAN],
//                User_Common_Const_MultiCity::CITY_ID_MIANYANG=>$cities[User_Common_Const_MultiCity::CITY_ID_MIANYANG]
            )/* ,
              "港 澳 台"=>array(
              User_Common_Const_MultiCity::CITY_ID_HONGKONG=>$cities[User_Common_Const_MultiCity::CITY_ID_HONGKONG]
              ) */
        );
        return $city;
    }

    public function getCityLink($cityid)
    {
        $city_set = APF::get_instance()->get_config("city_set", "multicity");
        $base_domain = APF::get_instance()->get_config("base_domain");
        return User_Common_Util_Url::buildUri($base_domain, $city_set[$cityid]['pinyin']);
    }

    public function getCitySelectorUrl()
    {
        $base_domain = APF::get_instance()->get_config("base_domain");
        return "http://www." . $base_domain . '/index/';
    }

    protected function getCityName()
    {
        $cities = APF::get_instance()->get_config("cities", "multicity");
        $city_id = APF::get_instance()->get_request()->getCityId();
        return $cities[$city_id];
    }

    /**
     * 获得导航
     */
    private function getCityTabs()
    {
        $cityId = APF::get_instance()->get_request()->getCityId();
        return User_Common_Uri_Navigation::getCityTabs($cityId);
    }

    /**
     * 获得当前焦点的一级导航
     */
    public function geCurrentNavFirst($actived, $cityTabs)
    {
        foreach ($cityTabs as $k => $tab) {
            if ($k == $actived || in_array($actived, array_keys($tab['navSecond']))) {
                return $k;
            }
        }
        return false;
    }

}
