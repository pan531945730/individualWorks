<?php

class User_Component_Header_WideHeaderComponent extends User_Component_AbstractComponent
{

    public static function use_component()
    {
        return array_merge(
            parent::use_component(), array('User_Component_Header_WideTabBar',
            )
        );
    }

    public static function use_boundable_styles()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array(
            $path . "Header.css",
            $path . "WideHeader.css"
            );
    }

    public function getView()
    {
        $this->assign_data('bread_crumbs_data', $this->request->get_attribute('bread_crumbs_data'));
        $this->assign_data("city_id",APF::get_instance()->get_request()->getCityId());
        return 'WideHeader';
    }
}

