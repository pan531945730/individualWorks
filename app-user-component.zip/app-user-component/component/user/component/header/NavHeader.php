<?php
/**
 * Created by PhpStorm.
 * User: benlinhuo
 * Date: 8/8/14
 * Time: 10:59 AM
 */

class User_Component_Header_NavHeaderComponent extends User_Component_AbstractComponent
{
    public function getView()
    {

        $this->assign_data('headerName', self::getComponent());
        return 'NavHeader';
    }

    public static function use_component()
    {
        return array_merge(
            parent::use_component(), array(
                self::getComponent()
            )
        );
    }

    public static function getComponent(){
        $type = APF::get_instance()->get_request()->get_attribute("header_type");
        $name = 'User_Component_Header_';
        $theme = 'Theme_Freshness_';
        //$theme = '';
        switch($type) {
            case 'listSec':
                $name .= $theme . 'ListHeaderSec';
                break;
            case 'listNoSec':
                $name .= $theme . 'ListHeaderSec';//'ListHeaderNoSec';
                break;
            case 'home':
                $name .= 'HomeHeader';
                break;
            case 'map':
                $name .= 'MapHeader';
                break;
            case 'detail':
                $name .= 'DetailHeader';
                break;
            default:
                $name .= 'HomeHeader';
        }
        return $name;
    }

}

