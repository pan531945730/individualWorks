
(function(){
    function init(){
        bindEvent();
    }
    init();

    function bindEvent(){
        J.s('.li_items').each(function(i, v){
            var fstNav = v.down(),
                secNav = v.down(1);
            v.on("mouseenter",function(){
                v.addClass('li_hover');
                fstNav.addClass('a_nav_hover');
                secNav.show();
                fstNav.hasClass('a_curr') ? secNav.addClass('sec_div_curr') : secNav.removeClass('sec_div_curr');
            })
            v.on("mouseleave",function(){
                v.removeClass('li_hover');
                fstNav.removeClass('a_nav_hover');
                secNav.hide();
            })

        })
    }

})();
