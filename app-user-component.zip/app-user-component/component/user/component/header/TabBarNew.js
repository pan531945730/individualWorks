
J.ready(function(){
    function init(){
        bindEvent();
    }
    init();

    function bindEvent(){
        J.s('.li_unselected').each(function(i, v){
            var fstNav = v.down(),
                secNav = v.hasClass('li_itemsnew') ? v.down(1) : null;
            v.on("mouseenter",function(){
                v.addClass('li_hover');
                fstNav.addClass('a_nav_hover');
                secNav && secNav.show();
            });
            v.on("mouseleave",function(){
                v.removeClass('li_hover');
                fstNav.removeClass('a_nav_hover');
                secNav && secNav.hide();
            });
        });

        //下拉框箭头中间位置
        var eles = J.s('.arrow_upnew');
        eles.length && eles.each(function(i, v) {
            var parent = v.up().up(), left = 0;
            parent && (left = (parent.width() - 14) / 2);
            v.get().style.left = left + 'px';
        });

        //58优质房源发soj
        J.g('tab_58yzfy').on("click",function(){
            var st = new J.logger.Tracker("anjuke-npv");
                st.setPage("homepage_esf_navigation");
                st.setPageName("homepage_esf_navigation");
                st.setReferrer(document.referrer);
                st.setNGuid("aQQ_ajkguid");
                st.setNUid("ajk_member_id");            
                try {
                    st.track();
                } catch (err) { console.log(err) }
        });

        //58品牌公寓导航发soj
        J.g('ppgy-58nav').on("click",function(){
            var st = new J.logger.Tracker("anjuke-npv");
                st.setPage("track_zf_daohang_click");
                st.setPageName("track_zf_daohang_click");
                st.setReferrer(document.referrer);
                st.setNGuid("aQQ_ajkguid");
                st.setNUid("ajk_member_id");            
                try {
                    st.track();
                } catch (err) { console.log(err) }
        });
       

    }

});

