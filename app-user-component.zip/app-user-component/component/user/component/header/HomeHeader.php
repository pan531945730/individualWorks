<?php

class User_Component_Header_HomeHeaderComponent extends User_Component_AbstractComponent
{

    public static function use_component()
    {
        return array_merge(
            parent::use_component(), array(
            "User_Component_Header_CitySelectorNew",
            "User_Component_Header_TabBarNew",
            )
        );
    }

    public static function use_boundable_styles()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "HomeHeader.css");
    }

    public function getView()
    {
        $this->assign_data('home_city_type',  APF::get_instance()->get_request()->get_attribute("home_city_type"));
        return 'HomeHeader';
    }

    protected function getCityName()
    {
        $cities = APF::get_instance()->get_config("cities", "multicity");
        $city_id = APF::get_instance()->get_request()->getCityId();
        return $cities[$city_id];
    }
    
    protected function getCityUrl()
    {
        $city_set = APF::get_instance()->get_config("city_set", "multicity");
        $city_id = APF::get_instance()->get_request()->getCityId();
        $base_domain = APF::get_instance()->get_config('base_domain');
        return User_Common_Util_Url::buildUri($base_domain, $city_set[$city_id]['pinyin']);
    }

    /**
     * 获得第三方登录地址
     * @param string $name
     * @return string
     */
    protected function getExtLoginUrl($name)
    {
        $back_url = "http://" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"];
        $base_domain = "http://" . APF::get_instance()->get_config('base_domain');
        $member_domain = "http://member." . strstr($base_domain, "anjuke.");
        return $name == 'extlogin_qq' ? $member_domain . "/extlogin/?sid=anjuke&url=" . base64_encode($back_url) . "&logintype=qq" : $member_domain . "/extlogin/?sid=anjuke&url=" . base64_encode($back_url) . "&logintype=weibo";
    }

    //除杭州和天津，显示产品推广
    protected function isShowChanpin()
    {
        $no_shown_city = array(
            User_Common_Const_MultiCity::CITY_ID_CHANGSHA,
            User_Common_Const_MultiCity::CITY_ID_SHENYANG,
        );
        $url = User_Common_Util_Url_Seo_Aboutus::buildSuffixUrl('home_head_tgy');
        $city_id = APF::get_instance()->get_request()->getCityId();

        if(!in_array($city_id,$no_shown_city)){
            return "<a class='u' href='{$url}' target='_blank' rel='nofollow'>营销中心</a>";
        }

        return false;
    }
}

