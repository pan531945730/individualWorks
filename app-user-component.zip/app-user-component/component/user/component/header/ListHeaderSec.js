//(function() {
//    //不影响用户体验最好改成css
//    var firstWidth = 120,
//        liEles = J.s('.L_tabsnew').eq(0).s('.li_single'),
//        linkEles = J.s('.secNavnew').eq(0).s('.sec_link');
//
//    for (var i = 0; i < liEles.length; i++) {
//        var ele = J.g(liEles[i]);
//        if (ele.hasClass('li_selected')) {
//            firstWidth += ele.width() / 2;
//            break;
//        }
//        firstWidth += ele.width();
//    }
//
//    var secWidth = 0;
//    linkEles.each(function(k, v) {
//        secWidth += (v.width() + 2);
//    });
//    var left = firstWidth - secWidth / 2;
//    linkEles && (linkEles.eq(0).get().style.marginLeft = left + 'px');
//})();

