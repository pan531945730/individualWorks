<?php

class User_Component_Header_SearchBarComponent extends User_Component_AbstractComponent
{

    public function getView()
    {
        return "SearchBar";
    }

}
