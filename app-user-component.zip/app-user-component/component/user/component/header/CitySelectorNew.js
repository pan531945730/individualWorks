J.ready(function(){
    function citySelector(selectorId, panelId, hideTimeout){
        var selector = J.g(selectorId),
            panel = J.g(panelId),
            hideTimeout = hideTimeout,
            timeoutHandle,
            el;
        //mouseover show city list
        selector.on("mouseover", function(e){
            showPanel(e);
        });
        //mouseover hide city list
        selector.on('mouseout', function(){
            hidePanel();
        });

        panel.on('mouseover', function(e) {
            showPanel(e);
        });

        panel.on('mouseout', function() {
            hidePanel();
        });

        function showPanel(e) {
            e.stop();
            window.clearTimeout(timeoutHandle);
            panel.show();
        }

        function hidePanel() {
            window.clearTimeout(timeoutHandle);
            timeoutHandle = window.setTimeout(function(){
                panel.hide();
            }, hideTimeout);
        }

    }
    //register namespace
    J.globalCitySelector = {};
    J.globalCitySelector = citySelector;
});
