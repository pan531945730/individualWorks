;(function() {
    J.g('header').s('.li_selected').each(function(k, v) {
        var ele = v.s('.sec_divnew').length && v.s('.sec_divnew').eq(0);
        v.on('mouseenter', function(e) {
            ele && ele.show();
            e.stop();
        }).on('mouseleave', function(e) {
            ele && ele.hide();
            e.stop();
        });

    });
})();
