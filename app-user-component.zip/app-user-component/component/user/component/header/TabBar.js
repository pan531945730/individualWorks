
(function(){
    function init(){
        bindEvent();
    }
    init();

    function bindEvent(){
        J.s('.li_items').each(function(i, v){
            var fstNav = v.down(),
                secNav = v.down(1);
            v.on("mouseenter",function(){
                v.addClass('li_hover');
                fstNav.addClass('a_nav_hover');
                secNav.show();
                fstNav.hasClass('a_curr') ? secNav.addClass('sec_div_curr') : secNav.removeClass('sec_div_curr');
            })
            v.on("mouseleave",function(){
                v.removeClass('li_hover');
                fstNav.removeClass('a_nav_hover');
                secNav.hide();
            })
            /*v.on("touchstart",function(e){
                var href= v.s("a")[0].href;
                if(href[0] == " "){
                    href = href.substr(1);
                }
                location.href = href;
                e.stop();
            })*/
            /*v.on("click",function(e){
             e.preventDefault();
             changeContent(i);
             })*/
        })

        function changeContent(idx){
            var con = $('secNav' + idx);
            J.s('.secNav').each(function(i,v){
                v.hide();
            })
            con.show();
        }
    }

})();
