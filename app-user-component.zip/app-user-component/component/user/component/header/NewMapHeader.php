<?php
class User_Component_Header_NewMapHeaderComponent extends User_Component_AbstractComponent
{
    public static function use_boundable_styles()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "NewMapHeader.css");
    }

    public static function use_boundable_javascripts()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "NewMapHeader.js");
    }

    public function getView()
    {
        return "NewMapHeader";
    }

    public static function use_component()
    {
        return array_merge(
            parent::use_component(), array(
                "Pc_Common_CitySelector",
                'Pc_Ui_DataCache',
                'Pc_Ui_Select',
                'Pc_Ui_Autocomplete',
            )
        );
    }
}
