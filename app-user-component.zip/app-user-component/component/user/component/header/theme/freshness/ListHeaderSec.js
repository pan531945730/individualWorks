J.ready(function(){
   //58优质房源发soj
    J.g('tab_58yzfy').on("click",function(){
        var st = new J.logger.Tracker("anjuke-npv");
            st.setPage("esf_list_navigation");
            st.setPageName("esf_list_navigation");
            st.setReferrer(document.referrer);
            st.setNGuid("aQQ_ajkguid");
            st.setNUid("ajk_member_id");            
            try {
                st.track();
            } catch (err) { console.log(err) }
    });

});

