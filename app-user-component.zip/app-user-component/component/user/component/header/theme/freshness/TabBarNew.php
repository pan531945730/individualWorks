<?php

class User_Component_Header_Theme_Freshness_TabBarNewComponent extends User_Component_AbstractComponent
{

    public function getView()
    {
        $objAPF = APF::get_instance();
        $objRequest = $objAPF->get_request();
        $cityId = $objRequest->getCityId();
        $actived = $this->get_page()->getActivedTab();
        if ($actived == 'baike') {
            $actived = 'question';
        }
        /*$url = 'http://shanghai.app-ershou-web.benlinhuo.dev.anjuke.com/getNavInfo/';
        //$url = 'http://wwww.anjuke.com/getNavInfo/';
        $data = Apf_Http_CurlClient::getInstance()->doGet($url, '');
        if($data){
            $cityTabs = json_decode($data, 1);
        }else{
              $cityTabs = $this->getCityTabs($cityId);
        }*/
        //var_dump($cityId,'city_id');
      //  $cityTabs = User_Common_Uri_Navigation::getCityTabs($cityId);

        $cityTabs = User_Common_Uri_Navigation::getNewCityTabs($cityId);
        //$cityTabs = $this->getCityTabs($cityId);
        $currentNavFirst = $this->geCurrentNavFirst($actived, $cityTabs);
        $this->assign_data("city_id",APF::get_instance()->get_request()->getCityId());
        $this->assign_data('currentNavFirst', $currentNavFirst);
        $this->assign_data('isHaveNavSecond', $this->isHaveNavSecond($currentNavFirst, $cityTabs));
        $this->assign_data('actived', $actived);
        $this->assign_data('cityTabs', $cityTabs);
        $this->assign_data('simple_nav', false);
        $this->assign_data('base_url', User_Common_Util_Url::buildBaseUrl("anjuke", "user") . '/');
        $this->assign_data('register_source_code', $this->get_param("register_source_code"));

        return "TabBarNew";
    }

    public static function getClassNameByTitle($title)
    {
        if ($title == '新房') {
            return 'div_xinfang';
        } else if ($title == '二手房') {
            return 'div_ershoufang';
        } else if ($title == '租房') {
            return 'div_zufang';
        } else if ($title == '商业地产') {
            return 'div_shangyedichan';
        }
        return '';
    }

    /*
     * 二级导航样式是否出现下划线
     */
    public static function isShowUnderline($title)
    {
        if ($title == '地图找房') {
            return true;
        } else if ($title == '商铺出租') {
            return true;
        }
        return false;
    }

    public static function use_boundable_javascripts()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array(
            $path . "TabBarNew.js"
        );
    }

    public static function use_component()
    {
        return array_merge(parent::use_component(), array(
            "User_Component_Dw_LinkFrom"
        ));
    }

    protected function getUrl($name, $from = '')
    {
        $back_url = "http://" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"];
       // $base_domain = "http://" . APF::get_instance()->get_config('base_domain');
        $base_domain = "http://" . APF::get_instance()->get_config('anjuke_base_domain');
        //$my_domain = "http://my." . APF::get_instance()->get_config('base_domain');
        $user_domain = "http://user." . APF::get_instance()->get_config('anjuke_base_domain');
        $member_domain = "http://member." . strstr($base_domain, "anjuke.");

        //判断是否开通了新房业务
        $intCityID = APF::get_instance()->get_request()->getCityId();
        $navCityConfig = APF::get_instance()->get_config('city_nav', 'navigation');
        $isOpenFang = false;
        if (isset($navCityConfig[$intCityID]) && ($navCityConfig[$intCityID] == 1 || $navCityConfig[$intCityID] == 2)) {
            $isOpenFang = true;
        }

        switch ($name) {
            case 'login_url' :
                echo $user_domain . "/my/login?history=" . base64_encode($back_url);
                echo $from ? '&from=' . $from : '';
                break;
            case 'register_url' :
                echo $user_domain . "/register/";
                echo $from ? '?from=' . $from : '';
                break;
            case 'extlogin_qq' :
                echo $member_domain . "/extlogin/?sid=anjuke&url=" . base64_encode($back_url) . "&logintype=qq";
                echo $from ? '&from=' . $from : '';
                break;
            case 'extlogin_wb' :
                echo $member_domain . "/extlogin/?sid=anjuke&url=" . base64_encode($back_url) . "&logintype=weibo";
                echo $from ? '&from=' . $from : '';
                break;
            case 'my_anjuke' :
                if ($isOpenFang) {
                    $back_url = $user_domain . "/favorite/xinfang/";
                } else {
                    $back_url = $user_domain . "/favorite/fangyuan";
                }
                echo $user_domain . "/my/login?history=" . base64_encode($back_url);
                break;
            case 'my_favorite' :
                if ($isOpenFang) {
                    $back_url = $user_domain . "/favorite/xinfang/";
                } else {
                    $back_url = $user_domain . "/favorite/fangyuan";
                }
                echo $domain . "/my/login?history=" . base64_encode($back_url);
                break;
            case 'my_recommend' :
                if ($isOpenFang) {
                    $back_url = $user_domain . "/fang/loupan-recommend/";
                } else {
                    $back_url = $user_domain . "/prop/collection/";
                }
                echo $user_domain . "/my/login?history=" . base64_encode($back_url);
                break;
            case 'view_history' :
                if ($isOpenFang) {
                    $back_url = $user_domain . "/fang/loupan-viewed/";
                } else {
                    $back_url = $user_domain . "/prop/myviewed/";
                }
                echo $user_domain . "/my/login?history=" . base64_encode($back_url);
                break;
            case 'subscription_management' :
                $back_url = $user_domain . "/subscribe/manage/list/";
                echo $user_domain . "/my/login?history=" . base64_encode($back_url);
                break;
            case 'my_ask' :
                $back_url = $user_domain . "/member/ask/my/";
                echo $user_domain . "/my/login?history=" . base64_encode($back_url);
                break;
            case 'publish_sell' :
                $back_url = $user_domain . "/prop/publish/list/";
                echo $user_domain . "/my/login?history=" . base64_encode($back_url);
                break;
            case 'my_house' :
                $back_url = "http://i." . APF::get_instance()->get_config('base_domain');
                echo $user_domain . "/my/login?history=" . base64_encode($back_url);
                break;
            case 'prop_manage' :
                $back_url = User_Common_Util_Url::buildGpropManageUrl();
                echo $user_domain . "/my/login?history=" . base64_encode($back_url);
                break;
        }
    }
    
    /**
     * 获得导航
     */
    private function getCityTabs($cityId){
        return User_Common_Uri_Navigation::getCityTabs($cityId);
    }

    /**
     * 获得当前焦点的一级导航
     */
    public function geCurrentNavFirst($actived,$cityTabs){
        foreach($cityTabs as $k => $tab){
            if($k==$actived || in_array($actived,array_keys($tab['navSecond']))){
                return $k;
            }
        }
        return false;
   }

    /**
     * 是否有二级导航
     * @param $currentNavFirst
     * @param $cityTabs
     * @return bool
     */
    public function isHaveNavSecond($currentNavFirst,$cityTabs){
        return $currentNavFirst && isset($cityTabs[$currentNavFirst]['navSecond']);
    }


    public static function use_boundable_styles()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array(
            $path . "TabBarNew.css"
        );
    }
}
