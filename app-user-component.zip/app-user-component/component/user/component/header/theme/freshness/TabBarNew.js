J.ready(function(){
    function init(){
        bindEvent();
    }
    init();

    function bindEvent(){
        J.s('.li_unselected').each(function(i, v){
            var fstNav = v.down(),
                secNav = v.hasClass('li_itemsnew') ? v.down(1) : null;
            v.on("mouseenter",function(){
                v.addClass('li_hover');
                fstNav.addClass('a_nav_hover');
                secNav && secNav.show();
            });
            v.on("mouseleave",function(){
                v.removeClass('li_hover');
                fstNav.removeClass('a_nav_hover');
                secNav && secNav.hide();
            });
        });

        //下拉框箭头中间位置
        var eles = J.s('.arrow_upnew');
        eles.length && eles.each(function(i, v) {
            var parent = v.up().up(), left = 0;
            parent && (left = (parent.width() - 14) / 2);
            v.get().style.left = left + 'px';
        });

    }

});

