/**
 * Aifang Javascript Framework.
 * Copyright 2012 ANJUKE Inc. All rights reserved.
 *
 * @path: site/citySelector.js
 * @author: john
 * @version: 1.0.0
 * @date: 2014/1/27
 *
 */

(function(){
    function citySelector(selectorId, panelId, hideTimeout){
        var selector = J.g(selectorId),
            panel = J.g(panelId),
            hideTimeout = hideTimeout,
            timeoutHandle,
            el;
        //mouseover show city list
        selector.on("mouseover", function(){
            window.clearTimeout(timeoutHandle);
            panel.show();
        });
        //mouseover hide city list
        selector.on('mouseout', function(){
            window.clearTimeout(timeoutHandle);
            timeoutHandle = window.setTimeout(function(){
                panel.hide();
            }, hideTimeout);
        });

        panel.on('mouseover', function() {
            window.clearTimeout(timeoutHandle);
            panel.show();
        });

        panel.on('mouseout', function() {
            window.clearTimeout(timeoutHandle);
            timeoutHandle = window.setTimeout(function(){
                panel.hide();
            }, hideTimeout);
        });

        if(selector.s('a').length > 0){
            el = selector.s('a').first();
            if (el != undefined) {
                el.on('click', function(event) {
                    event.preventDefault();
                });
            }
        }

    }
    //register namespace
    J.globalCitySelector = {};
    J.globalCitySelector = citySelector;
})();
