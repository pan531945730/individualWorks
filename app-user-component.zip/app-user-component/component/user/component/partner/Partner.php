<?php

class  User_Component_Partner_PartnerComponent extends User_Component_AbstractComponent{
    public static function use_boundable_styles()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array_merge(
            parent::use_boundable_styles(),
            array($path . "Partner.css")
        );
    }

    public function getView()
    {
	    // add by dy SEO友情链接
	    $mix_friend_link_all_data = $this->get_param('seo_friend_link_all_data');
	    if (isset($mix_friend_link_all_data) && !empty($mix_friend_link_all_data)) {
		    $this->assign_data("seo_friend_link_all_data", $mix_friend_link_all_data);
		    $this->assign_data("seo_friend_link_title", $mix_friend_link_all_data = $this->get_param('seo_friend_link_title'));
	    }
	    // add by dy end
        return 'Partner';
    }
}
