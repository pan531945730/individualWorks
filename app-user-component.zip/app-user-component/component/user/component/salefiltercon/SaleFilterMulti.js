(function($){
	$('#spread').on('click',function(){
		$('#multi-lists-hidden').show(300);
		$(this).hide();
		$('#retract').show();
	});
	$('#retract').on('click',function(){
		$('#multi-lists-hidden').hide(300);
		$(this).hide();
		$('#spread').show();
	});	

	$('#main-tips').on({
		mouseover:function(){
			$('#main-tips-content').show();
		},
		mouseout:function(){
			$('#main-tips-content').hide();
		}
	});

	$('#multi-lists-hidden').on({
		mouseover:function(){
			$(this).next('.multi-tips-content').show();
		},
		mouseout:function(){
			$(this).next('.multi-tips-content').hide();
		}
	},'.multi-tips');

	$('#multi-form').on('change','input',function(){
		if( $(this).prop('checked') ){
			$(this).next('em').addClass('selected');
			$(this).parents().prevAll('.multi-allisok').find('em').removeClass('selected');
		}else{
			$(this).next('em').removeClass('selected');
		}
	});

	$('#multi-form').on('click','.multi-allisok',function(){
		var inputs = $(this).parent().find('input');
		inputs.each(function(){
			$(this).prop('checked', false).trigger('change');
		});
		$(this).find('em').addClass('selected');
	});

	$('#multi-form').on('submit',function(){
		var areainputs = $('.multi-subareas').find('input'),
			flag       = true;
		areainputs.each(function(){
			if($(this).prop('checked')) flag = false;
		});
		if(flag) $('#areainput').prop('disabled',false);
		else 	 $('#areainput').prop('disabled',true);
	});
})(jQuery);
