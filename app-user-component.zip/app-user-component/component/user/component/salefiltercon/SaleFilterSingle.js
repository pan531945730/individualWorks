(function($){
	$('#multi-form').on('click','a.selected',function(){
		return false;
	});
	$('.choose-show').on('mouseover',function(){
		$(this).find('.choose-hidden').show();
	});
	$('.choose-show').on('mouseout',function(){
		$(this).find('.choose-hidden').hide();
	});
	$('.choose-hidden').on('input','input',function(){
		var _reg = /^[1-9]\d*$|^0$/,
			_val = $(this).val();
		if( !_reg.test(_val) )  $(this).val('');
	});
})(jQuery);