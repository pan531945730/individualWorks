
var priceCondition = (function(){

    var from_price = J.g('from_price'),
        to_price = J.g('to_price'),
        button = J.g('pricerange_search');

    function initialize() {
        from_price.on('focus', function() {
            button.show();
        });

        to_price.on('focus', function() {
            button.show();
        });

       /* from_price.on('blur', function() {
            button.hide();
        });
        to_price.on('blur', function() {
            button.hide();
        });*/


        to_price.on('keyup', function() {
            this.value = this.value.replace(/\D/g,'');
            setw(this);
        });

        from_price.on('keyup', function() {
            this.value = this.value.replace(/\D/g,'');
            setw(this);
        });

        button.on('mouseenter', function(){
            button.addClass('hover');
        }).on('mouseout', function(){
                button.removeClass('hover');
            });
    }

    function submit(s){
        var pattern = /^([1-9](\d{0,4})?)(\.\d{1})?|(^0(\.\d{1})?$)/;

        var fromprice = from_price.val().match(pattern);
        var toprice = to_price.val().match(pattern);

        if(fromprice!=null){
            from_price.val(fromprice[0]);
        }else{
            fromprice = 0;
            from_price.val('');
        }
        if(toprice!=null){
            to_price.val(toprice[0]);
        }else{
            toprice = 0;
            to_price.val('');
        }

        if(fromprice==0 && toprice==0){
            from_price.val('');
            to_price.val('');
            return s==1 ? true : false;
        }
        if(Number(fromprice[0])>Number(toprice[0]) && Number(toprice[0])>=0){
            from_price.val(toprice[0]);
            to_price.val(fromprice[0]);
        }
    }

    function hideButton() {
        button.hide();
    }

    function showButton() {
        button.show();
    }

    /**
     * 区域 input框自动填 宽
     * @type {*|boolean}
     */
    function setw(e){
        var len = e.value.length-3;
        if(len>-1){
            e.style.width=24+len*8+'px';
        }
    }

    return {
        initialize: initialize,
        submit: submit,
        hideButton: hideButton,
        showButton: showButton
    };
})();

priceCondition.initialize();

var areaCondition = (function(){
    var from_area = J.g('from_area'),
        to_area = J.g('to_area'),
        button = J.g('arearange_search');

    function initialize(){
        from_area.on('focus', function() {
            button.show();
        });
        to_area.on('focus', function() {
            button.show();
        });
       /* from_area.on('blur', function() {
            button.hide();
        });
        to_area.on('blur', function() {
            button.hide();
        });*/

        to_area.on('keyup', function() {
            this.value = this.value.replace(/\D/g,'');

            setw(this);
        });
        from_area.on('keyup', function() {
            this.value = this.value.replace(/\D/g,'');

            setw(this);
        });

        button.on('mouseenter', function(){
            button.addClass('hover');
        }).on('mouseout', function(){
                button.removeClass('hover');
            });
    }

    function submit(s){
        var pattern = /^([1-9](\d{0,4})?)(\.\d{1})?|(^0(\.\d{1})?$)/;

        var fromarea = from_area.val().match(pattern);
        var toarea = to_area.val().match(pattern);

        if(fromarea!=null){
            from_area.val(fromarea[0]);
        }else{
            fromarea = 0;
            from_area.val('');
        }
        if(toarea!=null){
            to_area.val(toarea[0]);
        }else{
            toarea = 0;
            to_area.val('');
        }

        if(fromarea==0 && toarea==0){
            from_area.val('');
            to_area.val('');
            return s==1 ? true : false;
        }
        if(Number(fromarea[0])>Number(toarea[0]) && Number(toarea[0])>=0){
            from_area.val(toarea[0]);
            to_area.val(fromarea[0]);
        }
    }

    function hideButton() {
        button.hide();
    }

    function showButton() {
        button.show();
    }

    /**
     * 区域 input框自动填 宽
     * @type {*|boolean}
     */
    function setw(e){
        var len = e.value.length-3;
        if(len>-1){
            e.style.width=24+len*8+'px';
        }
    }

    return {
        initialize: initialize,
        submit: submit,
        hideButton: hideButton,
        showButton: showButton
    }
})();

areaCondition.initialize();

(function(){
    J.on(document, 'click', function(e){
        var target = e.target || window.event.srcElement;

        if(target.id === 'arearange_search' || target.id === 'from_area' || target.id === "to_area"){
            areaCondition.showButton();
        } else {
            areaCondition.hideButton();
        }

        if(target.id === 'pricerange_search' || target.id === 'from_price' || target.id === "to_price"){
            priceCondition.showButton();
        } else {
            priceCondition.hideButton();
        }
    });
})();


