;

function pslide(option) {
    var defaults = {

        },
        opts = {};
    opts = J.mix(defaults, option);
    var idx = opts.idx,
        box = opts.box,
        bps = opts.bps,
        sps = opts.sps,
        bConWidth = opts.bConWidth,
        sConWidth = opts.sConWidth,
        spsLi = sps.s('li a'),
        bpicMove = bps.s('.picMove').eq(0),
        spicMove = sps.s('.picMove').eq(0),
        prebtn = bps.s('.btn_pre').eq(0),
        nextbtn = bps.s('.btn_next').eq(0),
        pre = 1,
        cur,
        sLiIdx;

    opts.onIndexChange && J.on(document, 'indexChange', function(e) {
        alert(e.data.index)
    })

    //slider
    function slider(picBox, ConWidth) {
        var picMove = picBox.s('.picMove').eq(0),
            moveLi = picBox.s('.picMove li'),
            picCon = picBox.s('.picCon'),
            len = moveLi.length,
            picMoveWidth = moveLi.length * ConWidth,
            width = ConWidth || picCon.get().width(),
            prebtn = picBox.s('.btn_pre').eq(0),
            nextbtn = picBox.s('.btn_next').eq(0),
            idx = 1;
        //jsvalue
        J.each(moveLi, function(i, v) {
            v.attr('jsvalue', i + 1);//v.setAttribute('jsvalue', i + 1);
            v.jsvalue = i + 1;
        });
        if (picMoveWidth > width) {
            var page = Math.ceil(picMoveWidth / width);
            //一个箭头
            if (page == 2) {
                nextbtn.get().style.visibility = 'visible';
                nextbtn.on('click', function(e) {
                    idx = 1;
                    setLeft(picBox, picMove, idx, width);
                    //picMove.get().style.left = '-' + idx*width + 'px';
                    nextbtn.get().style.visibility = 'hidden';
                    prebtn.get().style.visibility = 'visible';
                    dealspsLi(picBox, spsLi, idx, 1);
                });
                prebtn.on('click', function(e) {
                    idx = 0;
                    setLeft(picBox, picMove, idx, width);
                    //picMove.get().style.left = '-' + idx*width + 'px';
                    nextbtn.get().style.visibility = 'visible';
                    prebtn.get().style.visibility = 'hidden';
                    dealspsLi(picBox, spsLi, idx, 0);
                });
                clickLi(picBox, false); //added by quentin

            } else { //两个箭头
                //append
                prebtn.get().style.visibility = 'visible';
                nextbtn.get().style.visibility = 'visible';
                first = moveLi.eq(0).get(),
                last = moveLi.eq(len - 1).get();
                // nfirst = first.cloneNode(true),
                // nlast = last.cloneNode(true);
                // picMove.get().insertBefore(nlast,first);
                // picMove.get().appendChild(nfirst);
                //reset len
                moveLi = picBox.s('.picMove li'),
                len = moveLi.length;

                //set init width left
                picMove.get().style.width = width * len + 'px';
                picMove.get().style.left = '-' + (idx - 1) * width + 'px'; //>2

                prebtn.on('click', function(e) {
                    pre = idx;
                    idx--;
                    var len = moveLi.length;
                    if (picBox == sps && sLiIdx) {
                        sLiIdx && sLiIdx--;
                        if (sLiIdx == 0) {
                            sLiIdx = len;
                            setLeft(picBox, picMove, sLiIdx, width);
                        } else {
                            setLeft(picBox, picMove, sLiIdx, width);
                        }
                        return;
                    } else {
                        if (idx > 0) {
                            setLeft(picBox, picMove, idx, width);
                        }
                    }
                    if (cur) {
                        idx = cur;
                        idx--;
                        if (idx != 0) {
                            picMove.get().style.left = '-' + (idx - 1) * width + 'px';
                        }
                        var len = moveLi.length;
                        if (room_in_count == 0 || room_out_count == 0) {
                            if (idx == 0) {
                                idx = len;
                                setLeft(picBox, picMove, idx - 1, width);
                            }
                        } else {
                            if (idx < 1) {
                                J.g('photoSlide').s('.tabs a.next').eq(0).get().click();
                                var tabParams = getTabParams("tnow");
                                var len = tabParams.spsLi.length;

                                picBox = tabParams.picBox;
                                spsLi = tabParams.spsLi;
                                tabParams.spsLi.eq(len - 1).get().click(); //
                                idx = len;
                            } else {
                                var tabParams = getTabParams("tnow");
                                picBox = tabParams.picBox;
                                spsLi = tabParams.spsLi;
                            }
                        }
                        cur = idx;
                    } else {
                        if (room_in_count == 0 || room_out_count == 0) {
                            if (idx == 0) {
                                idx = len;
                                setLeft(picBox, picMove, idx - 1, width);
                            }
                        } else {
                            if (idx < 1) {
                                J.g('photoSlide').s('.tabs a.next').eq(0).get().click();
                                //setLeft(picBox, picMove, idx - 1, width);
                                //spicMove.s('a').eq(len - 1).get().click();
                                var tabParams = getTabParams("tnow");
                                var len = tabParams.spsLi.length;
                                picBox = tabParams.picBox;
                                spsLi = tabParams.spsLi;
                                tabParams.spsLi.eq(len - 1).get().click(); //
                                idx = len;
                            } else {
                                var tabParams = getTabParams("tnow");
                                picBox = tabParams.picBox;
                                spsLi = tabParams.spsLi;
                            }

                        }
                    }
                    dealspsLi(picBox, spsLi, idx - 1, 0);

                });
                nextbtn.on('click', function(e) {
                    pre = idx;
                    idx++;
                    var len = moveLi.length;
                    if (picBox == sps && sLiIdx) {
                        //pre
                        sLiIdx && sLiIdx++;
                        if (sLiIdx == len + 1) {
                            sLiIdx = 1;
                            setLeft(picBox, picMove, sLiIdx, width);
                            //picMove.get().style.left = '-' + idx*width + 'px';
                        } else {
                            setLeft(picBox, picMove, sLiIdx, width);
                        }

                        // dealspsLi(spsLi,pre-1);
                        return;
                    } else {
                        setLeft(picBox, picMove, idx - 1, width);
                    }
                    if (cur) {
                        idx = cur;
                        idx++;
                        picMove.get().style.left = '-' + (idx - 1) * width + 'px';
                        var len = moveLi.length;
                        if (room_in_count == 0 || room_out_count == 0) {
                            if (idx == len + 1) {
                                idx = 1;
                                setLeft(picBox, picMove, idx - 1, width);
                            }
                        } else {
                            if (idx > len) {
                                J.g('photoSlide').s('.tabs a.next').eq(0).get().click();
                                var tabParams = getTabParams("tnow");
                                picBox = tabParams.picBox;
                                spsLi = tabParams.spsLi;
                                tabParams.spsLi.eq(0).get().click(); //
                                idx = 1;
                                // setLeft(picBox, picMove, idx - 1, width);
                            } else {
                                var tabParams = getTabParams("tnow");
                                picBox = tabParams.picBox;
                                spsLi = tabParams.spsLi;
                            }
                        }
                        cur = idx;
                    } else {
                        if (room_in_count == 0 || room_out_count == 0) {
                            if (idx == len + 1) {
                                idx = 1;
                                setLeft(picBox, picMove, idx - 1, width);
                            }
                        } else {
                            if (idx > len) {
                                J.g('photoSlide').s('.tabs a.next').eq(0).get().click();
                                var tabParams = getTabParams("tnow");
                                picBox = tabParams.picBox;
                                spsLi = tabParams.spsLi;
                                tabParams.spsLi.eq(0).get().click();
                                idx = 1;

                                // setLeft(picBox, picMove, idx - 1, width);
                            } else {
                                var tabParams = getTabParams("tnow");
                                picBox = tabParams.picBox;
                                spsLi = tabParams.spsLi;
                            }
                        }
                    }
                    dealspsLi(picBox, spsLi, idx - 1, 1);
                });
                clickLi(picBox, true, spsLi);
            }
        }
    }
    //缩略图事件    
    function clickLi(picBox, flag, spsLi) {
        spsLi && spsLi.each(function(i, v) {
            //jsvalue
            var i = flag ? i + 1 : i;
            v.get().setAttribute('jsvalue', i);
            v.jsvalue = i;
            v.eq(0).on('click', function(e) {
                e.preventDefault();
                cur = v.jsvalue;
                if ((picBox != sps) && !flag) {
                    var bNextBtn = bps.s('.btn_next').eq(0),
                        bPreBtn = bps.s('.btn_pre').eq(0);
                    if (cur == 1) {
                        bNextBtn.get().style.visibility = 'hidden';
                        bPreBtn.get().style.visibility = 'visible';
                    } else {
                        bNextBtn.get().style.visibility = 'visible';
                        bPreBtn.get().style.visibility = 'hidden';
                    }
                }
                liCur = !flag ? cur : cur - 1;
                //pub
                dealspsLi(picBox, spsLi, liCur, flag);
                //cur = cur;// (spsLi.length > 10 && spsLi.length <= 20) ? cur + 1 : cur;
                setLeft(bps, bpicMove, cur - 1, bConWidth);
                pre = cur;
                sLiIdx = v.up(0).get().jsvalue;
            });
        });
    }

    //dealLi(picBox,idx,)


    //dealspsLi
    function dealspsLi(picBox, moveLi, idx, flag) {
        if (picBox == sps) {
            return;
        }
        //setClass
        moveLi.each(function(i, v) {
            moveLi.eq(i) && moveLi.eq(i).removeClass('now');
        });
        moveLi.eq(idx) && moveLi.eq(idx).addClass('now');

        //sps setLeft
        var tmp = parseInt((idx + 1) / 10) + 1;
        var nextbtn = sps.s('.btn_next').eq(0),
            prebtn = sps.s('.btn_pre').eq(0);
        if (flag == 1) { //click nextBtn
            if (moveLi.length >= 10) {
                var tmp = moveLi.length > 20 ? tmp : tmp - 1;
                if (idx % 10 != 9) {
                    setLeft(sps, sps.s('.picMove').eq(0), tmp, sConWidth);
                } else {
                    setLeft(sps, sps.s('.picMove').eq(0), tmp - 1, sConWidth);
                }
                if (moveLi.length > 20 || moveLi.length == 10) {
                    return;
                }
                if (tmp == 1) {
                    nextbtn.get().style.visibility = 'hidden';
                    prebtn.get().style.visibility = 'visible';
                }
                if (idx == 0) {
                    nextbtn.get().style.visibility = 'visible';
                    prebtn.get().style.visibility = 'hidden';
                }
            } else {

            }
        } else if (flag == 0) { //click preBtn
            if (moveLi.length >= 10) {
                var tmp = moveLi.length > 20 ? tmp : tmp - 1;
                if (idx % 10 != 9) {
                    setLeft(sps, sps.s('.picMove').eq(0), tmp, sConWidth);
                } else {
                    setLeft(sps, sps.s('.picMove').eq(0), tmp - 1, sConWidth);
                }
                if (moveLi.length > 20 || moveLi.length == 10) {
                    return;
                }
                if (tmp == 0 || idx < 10) {
                    nextbtn.get().style.visibility = 'visible';
                    prebtn.get().style.visibility = 'hidden';
                }
                if (idx >= 10) {
                    nextbtn.get().style.visibility = 'hidden';
                    prebtn.get().style.visibility = 'visible';
                }
            } else {
                setLeft(sps, sps.s('.picMove').eq(0), tmp - 1, sConWidth);
            }
        }


    }

    function setLeft(picBox, picMove, pre, width) {
        picMove.get().style.left = '-' + pre * width + 'px';
    }

    slider(bps, bConWidth);
    slider(sps, sConWidth);

    J.ready(function() {
        var img = bps.s('img');
        img.each(function(i, v) {
            var pic = img.eq(i),
                dataSrc = pic.attr('data-src');
            dataSrc && pic.attr('src', dataSrc).attr('data-src', '');
        });
    })

}
//init pslide
J.s('.tabscon').each(function(i, v) {
    var box = J.s('.tabscon').eq(i);
    if (box.s('.photoslide').length != 2) {
        return;
    }
    var bps = box.s('.photoslide').eq(0),
        sps = box.s('.photoslide').eq(1);
    if (!bps || !sps) return;
    pslide({
        box: box,
        bps: bps,
        sps: sps,
        bConWidth: 600,
        sConWidth: 830,
        onIndexChange: function() {

        }
    });

});
var tabbox = J.g('photoSlide');
tabview(tabbox.s('.tabs a'), tabbox.s('.tabscon'));

function getTabParams(name) {
    var container = J.g("photoSlide").s('.con').eq(0).s('.' + name).eq(0).s('.photoslide');
    return {
        //picBox: J.s('.tabscon').eq(i).s('.photoslide').eq(0),
        picBox: container.eq(0),
        //spsLi: J.s('.tabscon').eq(i).s('.photoslide').eq(1).s("li a")
        spsLi: container.eq(1).s("li a")
    };
}
//tabview
function tabview(tab, con) {
    var tablen = tab.length,
        conlen = con.length,
        pre = 0;
    if (tablen !== conlen) {
        return;
    }
    tab.each(function(i, v) {
        v.on('click', function(e) {
            e.preventDefault();
            if (v.hasClass('now')) {
                return;
            } else {
                J.site.trackEvent('room_click_' + i);
                v.addClass('now');
                tab.eq(pre).removeClass('now');
                tab.eq(pre).addClass('next')
                tab.eq(i).removeClass('next');
                con.eq(i).show();
                con.eq(i).addClass('tnow');
                con.eq(pre).removeClass('tnow');
                con.eq(pre).addClass('next');
                con.eq(i).removeClass('next');
                 con.eq(pre).hide();
                if (room_in_count != 0 && room_out_count != 0) {
                    var tabParams = getTabParams("next");
                    tabParams.spsLi.eq(0).get().click();
                }
                pre = i;
            }
        });
    });
}