<?php

/**
 * 图片轮播组件
 * Class Property_Picture_SwitchShowComponent
 */
class User_Component_Picture_SwitchShowComponent extends User_Component_AbstractComponent
{
    /**
     * 定义小图片尺寸
     * @var array
     */
    private static $small_size_param = array(
        'width' => 67,
        'height' => 50,
        'c' => 'c',
    );

    public static function use_component()
    {
        return array_merge(
            parent::use_component(), array(
            )
        );
    }
    
    public static function use_boundable_javascripts()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "SwitchShow.js");
    }

    public static function use_boundable_styles()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "SwitchShow.css");
    }

    public function getView()
    {
        $this->assign_data('room_and_model_images',$this->get_param('property_images'));
        $this->assign_data('community_images',$this->get_param('community_images'));
        $this->assign_data('small_size_param',self::$small_size_param);
        $this->assign_data('source_type',$this->get_param('source_type'));
        return 'SwitchShow';
    }
}

