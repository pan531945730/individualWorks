;APF.Namespace.register("ajk");
(function($, ns) {
    ns.HouseListV2Class = function(op) {
        var self = this;
        self.defaults = {};
        self.ops = $.extend({}, self.defaults, op);
        self.nodes = {
            ul : $(self.ops.ulSlter)
        };
        self.tracker = new SiteTracker("anjuke-npv");
        self.init();
    }

    ns.HouseListV2Class.prototype.init = function() {
        var self = this;
        self.tracker.setPage("esf_list_fy");
        self.tracker.setPageName("esf_list_fy");
        self.tracker.setReferer(document.referrer);
        self.tracker.setNGuid("aQQ_ajkguid");
        self.tracker.setNUid("ajk_member_id");
        self.bindEvent();
    }
    ns.HouseListV2Class.prototype.bindEvent = function() {
        var self = this;

        // 绑定: 鼠标hover li
        self.nodes.ul.on("mouseenter", "li", function(e) {
            $(this).addClass("over-bg");
            $(this).find(".houseListTitle").addClass('hover');
        });
        self.nodes.ul.on("mouseleave", "li", function(e) {
            $(this).removeClass("over-bg");
            $(this).find(".houseListTitle").removeClass('hover');
        });
        // 绑定： li整块可点，新窗口打开，标记已读
        self.nodes.ul.on("click", "li", function(e) {
            $(this).addClass('visited-bg');
            self.redirect( $(this).find(".houseListTitle").attr("href") );
        });

        // 绑定： 点击li中的a发码
        self.nodes.ul.on("click", ".houseListTitle", function(e) {
            $(this).addClass('visited').removeClass('hover');
            var dataFrom = $(this).attr("data-from");
            if ( dataFrom === "58" || dataFrom === "58m" ) {
                self.tracker.track();
            }
            e.stopPropagation();
        });
    }

    ns.HouseListV2Class.prototype.redirect = function(url) {
        var self = this;
        if (!/*@cc_on!@*/0) {
            window.open(url,'_blank');
        } else {
            var a = document.createElement('a');
            a.href = url;
            a.target = '_blank';
            document.body.appendChild(a);
            a.click();
        }
    }
})(jQuery, ajk);