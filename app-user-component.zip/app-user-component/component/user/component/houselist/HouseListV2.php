<?php

class User_Component_HouseList_HouseListV2Component extends User_Component_AbstractComponent
{

    public static function use_boundable_styles()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "HouseListV2.css");
    }

    public static function use_boundable_javascripts()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "HouseListV2.js");
    }

    public function getView()
    {

        return "HouseListV2";
    }
    public function buildSpiderUrl($url){
        $result_url = $url;
        $is_spider = User_Common_Util_Spider::isSpider();
        if($is_spider){
            $result_url = User_Common_Util_Spider::parsePureUrl($url);
        }
        return $result_url;
    }

}

?>