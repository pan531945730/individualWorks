<?php

class User_Component_HouseList_HouseListComponent extends User_Component_AbstractComponent
{

    public static function use_boundable_styles()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "HouseList.css");
    }

    public static function use_boundable_javascripts()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "HouseList.js");
    }

    public function getView()
    {

        return "HouseList";
    }
    public function buildSpiderUrl($url){
        $result_url = $url;
        $is_spider = User_Common_Util_Spider::isSpider();
        if($is_spider){
            $result_url = User_Common_Util_Spider::parsePureUrl($url);
        }
        return $result_url;
    }

}

?>