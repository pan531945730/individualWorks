/**
 * Created by qigao on 15-6-24.
 */

;
(function(){
    var house_list = J.g('house-list').s('li');
    house_list.each(function(i, v){
        v.on('mouseenter', function(){
            v.addClass('over-bg');
            v.s('a').eq(0).addClass('hover');
        }).on('mouseleave', function(){
            v.removeClass('over-bg');
            v.s('a').eq(0).removeClass('hover');
        }).on('click', function(){
            v.s("a").eq(0).get().click();
        });

        v.s('a').each(function(k, v){
            v.on('click', function(e){
                if (e && e.stopPropagation) {
                    e.stopPropagation();
                } else {
                    window.event.cancelable = true;
                }
            })
        });
    });
})();