<?php
/**
 * Created by PhpStorm.
 * User: qigao
 * Date: 15-6-24
 * Time: 上午9:39
 */

class User_Component_HouseList_HouseListNewComponent extends User_Component_AbstractComponent
{

    public static function use_boundable_styles()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "HouseListNew.css");
    }

    public static function use_boundable_javascripts()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "HouseListNew.js");
    }

    public function getView()
    {

        return "HouseListNew";
    }
    public function buildSpiderUrl($url){
        $result_url = $url;
        $is_spider = User_Common_Util_Spider::isSpider();
        if($is_spider){
            $result_url = User_Common_Util_Spider::parsePureUrl($url);
        }
        return $result_url;
    }

}

?>