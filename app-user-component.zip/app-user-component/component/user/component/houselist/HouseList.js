;
(function(){
    var house_list = J.g('house-list').s('li');
    house_list.each(function(i, v){
        v.on('mouseenter', function(){
            v.addClass('over-bg');
            v.s('a').eq(0).addClass('hover');
        }).on('mouseleave', function(){
                v.removeClass('over-bg');
                v.s('a').eq(0).removeClass('hover');
            }).on('click', function(){
                v.addClass('visited-bg');
                v.s("a").eq(0).get().click();
            });

        v.s('a').each(function(k, v){
            v.on('click', function(e){
                v.addClass('visited').removeClass('hover');
                if (e && e.stopPropagation) {
                    e.stopPropagation();
                } else {
                    window.event.cancelable = true;
                }

                if(v.attr('data-from')=='58' || v.attr('data-from')=='58m'){
                    var st = new J.logger.Tracker("anjuke-npv");
                    st.setPage("esf_list_fy");
                    st.setPageName("esf_list_fy");
                    st.setReferrer(document.referrer);
                    st.setNGuid("aQQ_ajkguid");
                    st.setNUid("ajk_member_id");            
                    try {
                        st.track();
                    } catch (err) { console.log(err) }
                }

            })
        });
    });
})();