<?php
/**
 * 新版分页组件，适用于1180px的列表
 */

class User_Component_Page_ListMultiPageComponent extends User_Component_AbstractComponent {

    public static function use_boundable_styles() {
        return array(apf_classname_to_path(__CLASS__)."ListMultiPage.css");
    }

    public function getView()
    {
        $this->assign_data("multiPage",$this->get_params());
        return "ListMultiPage";
    }

}

?>
