<?php

class User_Component_Page_MultiPageComponent extends User_Component_AbstractComponent
{

    public static function use_boundable_styles()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "MultiPage.css");
    }

    public function getView()
    {
        $params = $this->get_params();
        $params['kw'] = trim($params['kw']);
        if (!$params['url_fix']) {
            $params['url_fix'] = 'sale';
        }
        if ($params['multipage']) {
            $multipage = $params['multipage'];
        } else {
            $multipage = $params;
        }
        $this->assign_data("multipage", $multipage);
        $this->assign_data("params", $params);
        return "MultiPage";
    }

}

?>
