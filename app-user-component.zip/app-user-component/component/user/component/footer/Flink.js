J.ready(function(){
    function FooterCityList(selectorId, panelId){
        var selector = J.g(selectorId),
            panel = J.g(panelId),
            timeoutHandle,
            hideTimeout = 500;
        selector.on("click", function(){
            if(panel.getStyle("display") == "none"){
                panel.show();
            }else{
                panel.hide();
            }
        });

        J.g("topic").on("mouseover",function(){
            if(panel.getStyle("display") != "none"){
                window.clearTimeout(timeoutHandle);
                panel.show();
            }
        });

        J.g("topic").on("mouseout",function(){
            if(panel.getStyle("display") != "none"){
                window.clearTimeout(timeoutHandle);
                timeoutHandle = window.setTimeout(function(){
                    panel.hide();
                }, hideTimeout);
            }
        });

        panel.on("mouseover",function(){
            window.clearTimeout(timeoutHandle);
            panel.show();
        });

        panel.on("mouseout",function(){
            window.clearTimeout(timeoutHandle);
            timeoutHandle = window.setTimeout(function(){
                panel.hide();
            }, hideTimeout);

        });



    }
    //register namespace
    J.globalFooter = {};
    J.globalFooter.FooterCityList = FooterCityList;
});
