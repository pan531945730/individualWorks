<?php
class User_Component_Footer_SeoRecommendListComponent extends User_Component_AbstractComponent
{
    public static function use_boundable_styles()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "SeoRecommendList.css");
    }
    
    public static function use_boundable_javascripts()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "SeoRecommendList.js");
    }
    
    public function getView(){
	    $relative_seo_all_data  = $this->get_param('relative_seo_all_data');
	    $str_special_search_key = 'special';

	    if (isset($relative_seo_all_data[$str_special_search_key]) && !empty($relative_seo_all_data[$str_special_search_key])) {
		    $this->assign_data('seo_special_search_data', $relative_seo_all_data[$str_special_search_key]);
		    unset($relative_seo_all_data[$str_special_search_key]);
	    }

        $this->assign_data("relative_seo_all_data", $relative_seo_all_data);

        return 'SeoRecommendList';
    }
}