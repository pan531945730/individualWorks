<?php
/**
 * 底部共用链接
 */
class User_Component_Footer_FlinkComponent extends User_Component_AbstractComponent
{

    public function getView()
    {
        //$this->assign_data('seo_city_set', $this->get_param('seo_city_set'));
        $this->assign_data('seo_city_set', $this->getSeoCitySet());
        return "Flink";
    }

    public function getSeoCitySet()
    {
        //其它城市数据
        $seo_city_set = array();
        $base_domain = APF::get_instance()->get_config("base_domain");
        $house_web_config = APF::get_instance()->get_config("footer_other_city", "multicity");
        $city_set = APF::get_instance()->get_config("city_set", "multicity");
        foreach($house_web_config as  $value){
            $seo_city_set[] = array(
                'url' => User_Common_Util_Url::buildUri($base_domain, $city_set[$value]['pinyin']) . '/',
                'name' => $city_set[$value]['cityname'] . "房产网",
            );
            $seo_city_set[] = array(
                'url' => User_Common_Util_Url_Ershou_Sale::buildSaleLink($value),
                'name' => $city_set[$value]['cityname'] . "二手房",
            );
        }

        //其它城市手机小区
        $city_mobile = APF::get_instance()->get_config("footer_other_city_mobile", "multicity");
        foreach($city_mobile as $tag => $item){
            foreach($item as $info){
                $url = '';
                if($tag == "city"){
                    $url = User_Common_Util_Url_BaseUrl::buildTouchCityUrl($info[0]). '/';
                }elseif($tag == "xinfang"){
                    $url = User_Common_Util_Url_Ershou_Sale::buildTouchListUrl('xinfang', $info[0]);
                }elseif($tag == "sale"){
                    $url = User_Common_Util_Url_Ershou_Sale::buildErshouTouchSaleUrl('',$info[0]);
                }elseif($tag == "trend"){
                    $url = User_Common_Util_Url_Ershou_Sale::buildTouchListUrl('trendency',$info[0]);
                }elseif($tag == "map"){
                    $url = User_Common_Util_Url_Ershou_Map::buildTWMapUrl($info[0]);
                }elseif($tag == "fang"){
                    $url = User_Common_Util_Url_Ershou_Sale::buildTouchListUrl('taofang/quyufang',$info[0]);
                }elseif($tag == 'other'){
                    $url =  User_Common_Util_Url_BaseUrl::buildTouchCityUrl($info[0]) . $info[2];
                }

                $seo_city_set[] = array(
                    'url' => $url,
                    'name' => $info[1],
                );
            }
        }

        return $seo_city_set;
    }

    public static function use_boundable_javascripts()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "Flink.js");
    }

    public function getCurrentCityUriPrefix()
    {
        return $this->getCityLink($this->request->getCityId());
    }

    public function getCityLink($cityid)
    {
        $city_set = APF::get_instance()->get_config("city_set", "multicity");
        $base_domain = APF::get_instance()->get_config("base_domain");
        return User_Util_Url::build_uri($base_domain, $city_set[$cityid]['pinyin']);
    }

    public function buildSeoCommunityBooks()
    {
        $base_domain = APF::get_instance()->get_config("anjuke_base_domain");
        $city_set = APF::get_instance()->get_request()->load_city_set();
        return "http://www." . $base_domain . '/' . $city_set['pinyin'] . '/cm/';
    }
    public function buildZfSeoCommunityBooks()
    {
        $base_domain = APF::get_instance()->get_config("anjuke_base_domain");
        $city_set = APF::get_instance()->get_request()->load_city_set();
        return "http://www." . $base_domain . '/' . $city_set['pinyin'] . '/cm-zu/';
    }

    public function buildmSeoCommunityBooks()
    {
        $base_domain = APF::get_instance()->get_config("anjuke_base_domain");
        $city_set = $this->request->load_city_set();
        return "http://m.$base_domain/".$city_set['twdomain']."/xiaoqu/";
    }
    
   
    public function buildmSeoMapBooks($param)
    {
        $city_set = $this->request->load_city_set();
        $base_domain = APF::get_instance()->get_config("anjuke_base_domain");
        $path = "http://m.$base_domain/".$city_set['twdomain'].'/sitemap/';
        $path = ($param=='xinfang')?"http://m.$base_domain/".$city_set['twdomain']."/{$param}/sitemap/":$path;
        return $path;
    }
    
    public function buildSeoMapBooks($param)
    {
         $city_set = $this->request->load_city_set();
         $base_domain = APF::get_instance()->get_config("anjuke_base_domain");
         $city_set = $this->request->load_city_set();
         $path = 'http://'.$city_set['pinyin'].".$base_domain/sitemap/";
         $path = ($param=='xinfang')?"http://".$city_set['xfdomain'].".fang.$base_domain/fangsitemap/":$path;
         return $path;  
    }
    
    public function buildSeoHoseBooks($param)
    {
         $city_set = $this->request->load_city_set();
         $base_domain = APF::get_instance()->get_config("anjuke_base_domain");
         
         $path = 'http://';
         switch($param)
         {
             case'ershou': //二手房
             {
                $path = $path.$city_set['pinyin'].".".$base_domain.'/fang/';
                break;
             }
             case'xinfang': //新房
             {
                 $path = $path.$city_set['xfdomain'].'.fang.'.$base_domain.'/fang/';
                 break;
             }
             case 'zufang'://租房
             {
                 $path = $path.$city_set['zfdomain'].'.zu.'.$base_domain.'/fang/';
                 break;
             }
             case 'xzl_zu'://写字楼出租
             {
                 $path = $path.$city_set['xzldomain'].'.xzl.'.$base_domain.'/fang_zu/';
                 break;
             }
             case 'xzl_shou'://写字楼出售
             {
                 $path = $path.$city_set['xzldomain'].'.xzl.'.$base_domain.'/fang_shou/';
                 break ;
             }
             
             case 'sp_zu'://商铺出租
             {
                 $path = $path.$city_set['spdomain'].'.sp.'.$base_domain.'/fang_zu/';
                 break;
             }
             case'sp_shou'://商铺出售
             {
                 $path = $path.$city_set['spdomain'].'.sp.'.$base_domain.'/fang_shou/';
                 break;
             }
             case 'm_ershou'://二手房手机版
             {
                 $path = $path.'m.'.$base_domain.'/'.$city_set['twdomain'].'/'.'propsitemap/esf/';
                 break;
             }
             case 'm_zufang'://租房手机版
             {
                 $path = $path.'m.'.$base_domain.'/'.$city_set['twdomain'].'/'.'propsitemap/zf/';
                 break;
             }
             case 'xinfang_loupan'://新房楼盘大全
             {
                 $path = $path.$city_set['pinyin'] . '/fang.anjuke.com/fangsitemap/A/';
                 break;
             }

             default:$path="";
         }
        
        
        return $path;
        
    }
    
    /**
     * @param int   $cityid 城市ID
     * @param string $type  类型
     * @return boolean 
     */
    public function checkSeoCity($cityid,$type)
    {
        
        $config =  APF::get_instance()->get_config($type,'/multicity/foot_nav');
        if(in_array($cityid,$config))
        {
            return TRUE;
        }
        return FALSE;

    }

    //除杭州和天津，显示产品推广
    public function isShowChanpin()
    {
        $no_shown_city = array(
            User_Common_Const_MultiCity::CITY_ID_CHANGSHA,
            User_Common_Const_MultiCity::CITY_ID_SHENYANG,
        );
        $url = User_Common_Util_Url_Seo_Aboutus::buildSuffixUrl('home_foot_tgy');
        $city_id = $this->request->getCityId();

        if(!in_array($city_id,$no_shown_city)){
            return "<span class='link_span'><a href='{$url}' target='_blank' rel='nofollow'>产品推广</a></span>";
        }

        return false;
    }
    
}
?>
