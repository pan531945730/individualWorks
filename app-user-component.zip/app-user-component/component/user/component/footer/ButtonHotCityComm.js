
J.ready(function(){
    J.s('.seo_tabs').each(function(i,v){
        v.on("mouseover",function(){
            changeContent(i);
            J.s('.seoTabsOn').each(function(i, v){
                v.removeClass('seoTabsOn');
            })
            v.addClass('seoTabsOn');
        })
    });

    function changeContent(idx){
        //每次移动鼠标
        var con = J.g('footer_seo_con' + idx),
            con2 = J.g('footer_seo_city' + idx);
        J.s('.footer_seo_con').each(function(i,v){
            v.hide();
        })
        J.s('.footer_seo_city').each(function(i,v){
            v.hide();
        })
        con.show();
        con2&&con2.show();
    }
/*
    if (J.g("relative_ershoufang")) {
        J.g("relative_ershoufang").s("a").each(function(i, v) {
            v.on("click", function(e) {
                e = window.event || e;
                e.preventDefault ? e.preventDefault() : (e.returnValue == false);
                J.g("relative_ershoufang").s("a").each(function(i, v) {
                    v.removeClass("first");
                });
                v.addClass("first");
                J.g("relative_plate_list").s("div").each(function(i, v) {
                    v.hide();
                });
                J.g("relative_plate_list").s("div").eq(i).show();
            });
        });
    }*/
    var seoTagId=document.getElementById("relative_ershoufang");
    var seoListId=document.getElementById("relative_plate_list");
    var seoTag=seoTagId&&seoTagId.getElementsByTagName("a");
    var seoList=seoListId&&seoListId.getElementsByTagName("div");
    if(seoTag){
        for(var i=0;i<seoTag.length;i++){
        
            (function(i){
                seoTag[i].onclick=function(){
                    for(var j=0;j<seoList.length;j++){
                        seoList[j].style.display="none";
                        seoTag[j].className='';
                    }
                    j=i;
                    seoTag[i].className='first'
                    seoList[j].style.display="block";
                }
            })(i);
        
        }
    }
});
