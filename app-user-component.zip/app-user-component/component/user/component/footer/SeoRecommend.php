<?php
class User_Component_Footer_SeoRecommendComponent extends User_Component_AbstractComponent
{
    public static function use_boundable_styles()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "SeoRecommend.css");
    }
    
    public static function use_boundable_javascripts()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "SeoRecommend.js");
    }
    
    public function getView()
    {
        $this->assign_data("menu_list", $this->get_param('menu_list'));

	    ############### add by dy start ###############
	    $seoExtensionData = $this->request->get_attribute('seo_all_extension_data');
	    $arrMenuList      = $this->get_param('menu_list');
	    $relativeXfKey    = '';
	    // 如果存在'相关房产信息'，则修改'相关房产信息'为'相关楼盘信息'
	    if (!empty($arrMenuList)) {
		    foreach ($arrMenuList as $key=>$sub) {
			    if (isset($sub['tab_name']) && ($sub['tab_name'] == '相关房产信息')) {
				    $relativeXfKey = $key;
				    $arrMenuList[$key]['tab_name'] = '相关楼盘信息';
				    break;
			    }
		    }
	    }
	    // 存在'相关房产信息'，修改对应的List数据为新房数据
	    if (!empty($relativeXfKey)) {
		    if (isset($seoExtensionData) && ! empty($seoExtensionData) && !empty($seoExtensionData['xf'])) {
			    $arrMenuList[$relativeXfKey]['list'] = $seoExtensionData['xf']['list'];
			    unset($seoExtensionData['xf']);
		    }
	    }else{
		    // 不存在则添加相关楼盘信息
		    if (isset($seoExtensionData) && ! empty($seoExtensionData) && !empty($seoExtensionData['xf'])) {
			    $intCount                           = count($arrMenuList);
			    $arrMenuList[$intCount]['tab_name'] = '相关楼盘信息';
			    $arrMenuList[$intCount]['list']     = $seoExtensionData['xf']['list'];
			    unset($seoExtensionData['xf']);
		    }
	    }
	    $arrSeoSpecialData = '';
	    // 将过滤后的$seoExtensionData数据合并到menu_list中
	    if (isset($seoExtensionData) && ! empty($seoExtensionData)) {
		    if (isset($seoExtensionData['xf'])) {
			    $seoExtensionData['xf']['tab_name'] = '相关楼盘信息';
		    }
		    // 单独处理特殊找房数据
		    if (!empty($seoExtensionData['special'])) {
			    $arrSeoSpecialData = $seoExtensionData['special'];
			    unset($seoExtensionData['special']);
		    }
		    $this->assign_data("menu_list", array_merge($arrMenuList, $seoExtensionData));
	    }
	    // assign特色找房数据
	    if (isset($arrSeoSpecialData) && !empty($arrSeoSpecialData)) {
		    $this->assign_data("seo_special_extension_data", $arrSeoSpecialData);
	    }
	    ############### add by dy end ###############

	    // add by dy start 添加友情链接 2014.10.29 - 13:26
	    $seo_friend_link_all_data = $this->request->get_attribute('seo_friend_link_all_data');
	    $seo_friend_link_title    = $this->request->get_attribute('seo_friend_link_title');
	    if (isset($seo_friend_link_all_data) && !empty($seo_friend_link_all_data)) {
		    $this->assign_data("seo_friend_link_all_data", $seo_friend_link_all_data);
		    $this->assign_data("seo_friend_link_title", $seo_friend_link_title);
	    }

	    // 获取一个城市的所有区域及对应区域下的所有板块
	    $arr_all_areas_and_blocks = $this->request->get_attribute('seo_all_areas_and_blocks');
	    if (!empty($arr_all_areas_and_blocks)) {
		    $this->assign_data("seo_all_areas_and_blocks", $arr_all_areas_and_blocks);
	    }

	    // 获取一个区域下的20个小区大全 三天更新一次
	    $recommend_comms_in_same_area = $this->request->get_attribute('recommend_comms_in_same_area');
	    if (!empty($recommend_comms_in_same_area)) {
		    $this->assign_data("recommend_comms_in_same_area", $recommend_comms_in_same_area);
	    }
	    // add by dy end

        return 'SeoRecommend';
    }
}
?>
