<?php
class User_Component_Footer_ButtonHotCityCommComponent extends User_Component_AbstractComponent {

    public function getView () {
    	$params = $this->get_params();
		$footerSeoLinkList = $params['footerSeoLinkList'];
		$this->assign_data("footerSeoLinkList", $footerSeoLinkList);
	    // add by dy start
	    $seo_relative_data = $params['seo_relative_data'];
	    $seo_special_search_data = $params['seo_special_search_data'];
	    if (!empty($seo_relative_data)) {
		    $this->assign_data('seo_relative_data', $seo_relative_data);
	    }

	    if (!empty($seo_special_search_data)) {
		    $this->assign_data('seo_special_search_data', $seo_special_search_data);
	    }

	    $seo_hot_community_info = $params['seo_hot_community_info'];
	    if (!empty($seo_hot_community_info)) {
		    $this->assign_data('seo_hot_community_info', $seo_hot_community_info);
	    }
	    // add by dy end
        return "ButtonHotCityComm";
    }

    public static function use_boundable_javascripts() {
        $path = apf_classname_to_path(__CLASS__);
        return array($path."ButtonHotCityComm.js");
    }

    public static function use_boundable_styles() {
        $path = apf_classname_to_path(__CLASS__);
        return array($path."ButtonHotCityComm.css");
    }
}
?>
