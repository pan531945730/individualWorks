
J.ready(function() {
	var footBox = J.g('footseo-boxer');
	var dom = J.g("footer_seo_tab") || false;
	doms = dom.s("li");
	dom && doms.each(function(k, v) {
		v.on("mouseenter", function() {
			var rel = v.attr("rel");
			J.s(".footseo_list").each(function(k, v) {
				v.hide();
			});
			doms.each(function(k, v) {
				v.removeClass("tab_on");
			});
			v.addClass("tab_on");
			J.g("footseo_list_" + rel).show();
		});
	});
	var footBox=J.g('footseo-boxer');
	var footTitle = footBox.s('.footseo_list_first').eq(0) ;
	var footTitleLi = footTitle.s('li');
	var footCon = footBox.s('.footseo_list_second').eq(0) ;
	var footConUl = footCon.s('ul');
	footTitleLi.each(function(i, v) {
		v.on('click', function(e) {
			e = window.event || e;
			e.preventDefault ? e.preventDefault() : (e.returnValue == false);
			footTitleLi.each(function(a, b) {
				b.removeClass('on')
			})
			footConUl.each(function(m, n) {
				n.setStyle({'display':'none'})
			})
			v.addClass('on');
			footConUl.eq(i).setStyle({'display':'block'})
		})
	})
	var footer_seo_tab_dong = J.g("footseo_list_1");

	if (footer_seo_tab_dong.length && footer_seo_tab_dong.down(1).html() == '') {
		J.g("tab_1").setStyle({
			display: "none"
		});
	}

	var showcitymores = J.s(".showcitymore");
	showcitymores.length && showcitymores.each(function(k, v) {
		v.on("click", function() {
			var rel = v.attr("rel");
			J.s(".diff_footseo_list_li_" + rel).each(function(k, v) {
				v.show();
			});
			J.g("hiddencitymore_" + rel).show();
			v.hide();
		});
	});


	var hiddencitymore = J.s(".hiddencitymore");
	hiddencitymore.length && hiddencitymore.each(function(k, v) {
		v.on("click", function() {

			var rel = v.attr("rel");
			J.s(".diff_footseo_list_li_" + rel).each(function(k, v) {
				v.hide();
			});
			J.g("showcitymore_" + rel).show();
			v.hide();
		});
	});
});
