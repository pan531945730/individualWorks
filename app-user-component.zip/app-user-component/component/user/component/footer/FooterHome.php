<?php

class User_Component_Footer_FooterHomeComponent extends User_Component_AbstractComponent {
	
	public $letters = array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','1','2','3','4','5','6','7','8','9','0');
	
    public static function use_component(){
        return array_merge(
            parent::use_component(),
            array(
              //  "Global_LawInfo"
            )
        );
    }
    
    public static function use_boundable_styles() {
        $path = apf_classname_to_path(__CLASS__);
        return array($path."Footer.css");
    }
    
    public static function use_boundable_javascripts() {
        $path = apf_classname_to_path(__CLASS__);
        return array($path."FooterHome.js");
    }

    public function getView() {
    	$apf = @APF::get_instance()->get_request();
        $HomeFLink= @$apf->get_attribute("foot_f_link");
        if(User_Common_Util_Mobile::isRedirectTw()){
            $this->assign_data('twe', User_Common_Util_Mobile::TWE_MANUAL);
        }
        $this->assign_data('HomeFLink', $HomeFLink);
        $this->assign_data('des',@APF::get_instance()->get_request()->get_attribute("des"));
        $this->assign_data('display',@APF::get_instance()->get_request()->get_attribute("display"));
        $this->assign_data("letters", $this->letters);

        $city_set = APF::get_instance()->get_request()->load_city_set();
        $allcity = APF::get_instance()->get_config("city_set","multicity");
        $base_domain = APF::get_instance()->get_config("base_domain");
        $cityid = APF::get_instance()->get_request()->getCityId();
        /*对城市按城市名字数，ID进行排序*/
        $seo_city_set = $len_array = $city_array = array();
        foreach($allcity as $key=>$value){
        	if($value['open'] & $city_set['cityid']!=$key){
        		if(!in_array(strlen($value['cityname']) , $len_array)){
        			$len_array[] = strlen($value['cityname']);
        		}
        		$city_array[strlen($value['cityname'])][$value['cityid']] = $value;
        	}
        }
        //$len_array = array(12,9,6);
        sort($len_array);//按字数,ID进行排序
        foreach($len_array as $len){
        	ksort($city_array[$len]);
        	foreach($city_array[$len] as $city_value){
        		$seo_city_set[] = array('url'=>'http://'.$city_value['pinyin'].'.'.$base_domain,
                            'name'=>$city_value['cityname']);
        	}
        }
        $this->assign_data("seo_city_set",$seo_city_set);
        
        $calculatorlink = "http://"."www".".".$base_domain.BASE_URI."/calculator/loan";
		$this->assign_data("calculatorlink", $calculatorlink);
        $this->assign_data("city_id", $cityid);
        return "FooterHome";
    }

    public function build_letter_url($letter) {
    	apf_require_controller("SEO_LetterIndex");
    	$cityid = APF::get_instance()->get_request()->getCityId();
    	return SEO_LetterIndexController::build_url($cityid, $letter);
    }
    public function get_uri_prefix () {
        $base_domain = APF::get_instance()->get_config("base_domain");
        $city_set = APF::get_instance()->get_request()->load_city_set();
        $base_uri = "http://".$city_set['pinyin'].".".$base_domain."";
        return $base_uri;
    }
    public function get_current_city_uri_prefix () {
        return $this->get_city_link(APF::get_instance()->get_request()->getCityId());
    }
    public function get_city_link ($cityid) {
         $city_set = APF::get_instance()->get_config("city_set","multicity");
         $base_domain = APF::get_instance()->get_config("base_domain");
         return Uri_Http::build_uri($base_domain,$city_set[$cityid]['pinyin']);
    }
    public function get_city_list () {
        $cities = APF::get_instance()->get_config("cities","multicity");
        return $cities;
    }

    public function get_friend_link () {
        $base_uri = $this->get_current_city_uri_prefix();
        $tab = $this->get_page()->get_actived_tab();
        if("sale" == $tab) {
            return $base_uri."/friendlink.php?chanel_id=2";
        } else if("rent" == $tab) {
            return $base_uri."/friendlink.php?chanel_id=3";
        } else {
            return $base_uri."/flinks.html";
        }
    }
    
    public function get_city_isopen($cityid){
    	$city_set = APF::get_instance()->get_config("city_set","multicity");
    	return $city_set[$cityid]["open"];
    }
    
    public function get_haozu_link($params=array(), $flg=false){
        $city_set = APF::get_instance()->get_request()->load_city_set();
        $base_uri = "http://".$city_set['pinyin'].".haozu.com/";
        if($flg){
        	return $base_uri . "listing/broker/".APF_Util_StringUtils::encode_seo_parameters($params);;
        }
        return $base_uri;
    }
    
    public function get_rand_search_keyword($cityid){
    	$daoclass = APF::get_instance()->get_config("daoKeyWord");
    	apf_require_class($daoclass);
    	$dao = new $daoclass();
    	return $dao->get_rand_search_keyword($cityid);
    }
}
?>
