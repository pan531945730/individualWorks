<?php

class User_Component_Footer_FooterComponent extends User_Component_AbstractComponent
{

    public $letters = array('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0');

    public static function use_boundable_styles()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "Footer.css");
    }

    public static function use_component()
    {
        $seo_type = APF::get_instance()->get_request()->get_attribute('seo_type');
        APF::get_instance()->get_request()->set_attribute("seo_type", $seo_type);// 必须在use_component中设定内链样式 1:列表 2:友链 0:table样式
        $components = array_merge(
            parent::use_component(),
            array(
                "User_Component_Footer_Flink"
            )
        );
        $new_internal_links_data = APF::get_instance()->get_request()->get_attribute('new_seo_footer_recommend_data');
        if (!empty($new_internal_links_data)) {
            $components = array_merge($components, array('User_Component_Seo_SeoRecommend'));
        }
        return $components;
    }

    public function getView()
    {
        $allcity = APF::get_instance()->get_config("city_set", "multicity");
        // 临时关闭新开城市
        foreach ($allcity as $key=>$city_info) {
            if ($key > User_Common_Const_MultiCity::CITY_ID_JIANGMEN) {
                unset($allcity[$key]);
            }
        }
        /* 对城市按城市名字数，ID进行排序 */
        $seo_city_set = $len_array = $city_array = array();
        foreach ($allcity as $key => $value) {
            if ($value['open'] & $seo_city_set['cityid'] != $key) {
                if (!in_array(strlen($value['cityname']), $len_array)) {
                    $len_array[] = strlen($value['cityname']);
                }
                $city_array[strlen($value['cityname'])][$value['cityid']] = $value;
            }
        }
        $base_domain = APF::get_instance()->get_config("base_domain");
        //$len_array = array(12,9,6);
        sort($len_array); //按字数,ID进行排序
        foreach ($len_array as $len) {
            ksort($city_array[$len]);
            foreach ($city_array[$len] as $city_value) {
                $seo_city_set[] = array('url' => User_Common_Util_Url::buildUri($base_domain, $city_value['pinyin']),
                    'name' => $city_value['cityname']);
            }
        }

        $this->assign_data("seo_city_set", $seo_city_set);
        $this->assign_data("is_show_seo_recommend", $this->get_param('is_show_seo_recommend'));
        $this->assign_data("seo_recommend_data", $this->get_param('seo_recommend_data'));

        $internal_links = $this->get_param('new_seo_footer_recommend_data');
        if (!empty($internal_links)) {
            $this->assign_data("new_seo_footer_recommend_data", $internal_links);
        }

        //右侧工具是否显示
        $this->assign_data("is_show_rightbar", $this->request->get_attribute('is_show_rightbar'));

        //hide weiliao
        $hide_wei = ($this->request->get_attribute("hide_wei")) ? true : false;
        $this->assign_data("hide_wei", $hide_wei);
        return 'Footer';
    }

}

?>
