/*J.ready(function() {
	if (J.g("relative_ershoufang")) {
		J.g("relative_ershoufang").s("a").each(function(i, v) {
			v.on("click", function(e) {
				e = window.event || e;
				e.preventDefault ? e.preventDefault() : (e.returnValue == false);
				J.g("relative_ershoufang").s("a").each(function(i, v) {
					v.removeClass("first");
				});
				v.addClass("first");
				J.g("relative_plate_list").s("div").each(function(i, v) {
					v.hide();
				});
                J.g("relative_plate_list").s("div").eq(i).show();
			});
		});
	}
});*/

window.onload=function(){
	var seoTagId=document.getElementById("relative_ershoufang");
	var seoListId=document.getElementById("relative_plate_list");
	var seoTag=seoTagId&&seoTagId.getElementsByTagName("a");
    var seoList=seoListId&&seoListId.getElementsByTagName("div");
    if(seoTag){
    	for(var i=0;i<seoTag.length;i++){
        
	        (function(i){
	            seoTag[i].onclick=function(){
	                for(var j=0;j<seoList.length;j++){
	                    seoList[j].style.display="none";
	                    seoTag[j].className='';
	                }
	                j=i;
	                seoTag[i].className='first'
	                seoList[j].style.display="block";
	            }
	        })(i);
        
    	}
    }
    
}

