<?php

class User_Component_TimerAni_TimerAniComponent extends User_Component_AbstractComponent
{

    public static function use_boundable_styles()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "TimerAni.css");
    }

    public static function use_boundable_javascripts()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "TimerAni.js");
    }

    public function getView()
    {

        return "TimerAni";
    }

}

?>