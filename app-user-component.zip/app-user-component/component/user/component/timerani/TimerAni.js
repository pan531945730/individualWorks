
;
(function() {
    function TimerAni(option) {
        var defOptions = {
            id: '', //the container id 0
            onChange: '', //every item innerhtml handler
            afterInsert: '', // insert to the conaiter handler
            items: 5, // items num
            lessItems: '', //less opts.items handler
            equalItems: '',
            data: [],
            title: '',
            onMouseEnter: '',
            onMouseLeave: '',
            onItemClick: '',
            fixed: false,
            dataTacker: '',
            maxLimit: true
        }, opts = {}, container;
        var headerHtml = '';
        var footerHtml = '';
        var innerHtml = '';
        var left, right, list, INX, left_key = 0,
            right_key, timer; //left:leftButton,right:right button,list:the list target name of li .

        var offsetY, offsetX, botY, containerH, isIE6, page;

        (function() {
            opts = J.mix(defOptions, option);

            container = J.g(opts.id);
            if (!container) {
                return;
            };
            hide();
            if (!opts.data.length || opts.maxLimit && (opts.data.length < opts.items)) {
                lessItems();
                return;
            }

            right_key = opts.items - 1;

            var strPage = "<span class='page'>第1页，共" + Math.ceil(opts.data.length / opts.items) + "页</span>";
            headerHtml = '<div class="ajax_prop"><div class="title"><h4>' + opts.title + '</h4>' + strPage + '</div> <div class="box"><ul class="clearfix">';
            footerHtml = '</ul><a onclick="return false;"  class="left" href="javascript:void(0)"/><a class="right"  href="javascript:void(0)" onclick="return false;"></a></div></div></div>';

            container.html(headerHtml + innerHtml + footerHtml);

            left = container.s("a").eq(0).get();
            right = container.s("a").eq(1).get();
            page = container.s(".page").eq(0);
            if (opts.data.length <= opts.items) {
                left.style.display = "none";
                right.style.display = "none";
                container.s(".page").eq(0).hide();
            }
            equalItems(left, right);
            bindEvent();
            list = container.get().getElementsByTagName("li");
            var load = [];
            load.push(0);
            for (var i = 0; i < opts.data.length; i++) {
                (function(i) {
                    var img = new Image();
                    img.onload = function() {}
                    img.src = opts.data[i].IMAGESRC;
                })(i);

            }
        })();

        function lessItems() {
            opts.lessItems && opts.lessItems(container);
            hide();
        }

        function equalItems(left, right, data) {
            opts.equalItems && opts.equalItems(left, right);
            INX = 0;
            container.s("ul").eq(0).html(loop(INX, opts.maxLimit ? opts.items : opts.data.length));
            opts.afterInsert && opts.afterInsert(INX, sendSoj);
            show();
        }

        function onChange(data, i) {
            var squ = data.ROOMNUM + "室" + data.HALLNUM + "厅，" + data.AREANUM + "平米";

            return (opts.onChange && opts.onChange(data, i)) || '<img class="rec_common_img" title="' + data.TITLE + '" width="180" height="135"  src="' + data.IMAGESRC + '"><a class="rec_common_title" onclick="return false;" data-trace="{viewandview_' + (i + 1) + ':' + data.PROID + '}" title="' + data.TITLE + '"  href="' + data.LINK + '?from=anjuke_page_rec' + data.SOJ + '">' + data.TITLE + '</a><p class="rec_common_price">' + data.PROPRICE + '<span>万</span></p><p class="rec_common_info">' + squ + '</p>' +
                '<p class="rec_common_name">' + data.COMMNAME + '</p>';
        }

        function show() {
            container.get().style.display = "";
        }

        function hide() {
            container.get().style.display = "none";
        }

        function loop(i, LEN) {
            var tmp = null,
                html = '';
            for (; i < LEN; i++) {
                var tmp = opts.data[i];
                html += '<li class="rec_common_con">' + onChange(tmp, i) + '</li>';
            }
            return html;
        }

        function insertHtml() {
            container.innerHTML = headerHtml + innerHtml + footerHtml;
            show();
        }

        function bindEvent() {
            left.onclick = leftHandler;
            right.onclick = rightHandler;
            var list = J.g(opts.id).s("li");
            list.each(function(k, v) {
                v.on('mouseenter', function() {
                    v.addClass("hover");
                });
                v.on('mouseleave', function() {
                    v.removeClass("hover");
                });
                v.on('click', function() {
                    v.s("a").eq(0).get().click();
                });
                v.s("a").each(function(k, v) {
                    v.on('click', function(e) {
                        if (e && e.stopPropagation) {
                            e.stopPropagation();
                        } else {
                            window.event.cancelable = true;
                        }
                    });
                })
            });
            if (true || !opts.fixed || !container.hasClass("fix_con")) {
                return;
            }
            var dom = J.s(".img_txt").eq(0);
            var emptyDom = J.create('div', {
                style: 'float:left;width:1px;height:' + (container.height() + 55) + "px"
            })
            dom.append(emptyDom);
            isIE6 = !-[1, ] && !window.XMLHttpRequest;
            J.on(window, 'scroll', function() {
                offsetX = container.offset().x;
                offsetY = J.s(".img_txt").eq(0).offset().y;
                containerH = container.height();
                botY = offsetY + J.s(".img_txt").eq(0).height();
                J.ui.timerAni.offsetBotY = botY - containerH;
                J.ui.timerAni.offsetLeft = offsetX;
                J.un(window, 'scroll', arguments.callee);
            })
            J.on(window, 'resize', function() {
                offsetX = J.s(".img_txt").eq(0).offset().x;
                container.setStyle({
                    left: offsetX + "px"
                });
                J.ui.timerAni.offsetLeft = offsetX;
                fixPostion();
            });
            J.on(window, 'scroll', fixPostion)
        }

        function fixPostion() {
            var content = J.s(".img_txt").eq(0);
            var dom = J.s(".img_txt").eq(0);
            var scrollTop = J.page.scrollTop();
            if (scrollTop > offsetY) {
                if (scrollTop + container.height() + 10 >= botY) {
                    if (isIE6) {
                        container.removeClass("fixed").removeClass("static").addClass("iefixed");
                        return;
                    }
                    if (container.get().style.position === "fixed") {
                        container.setStyle({
                            position: 'absolute',
                            top: (botY - containerH - 20) + "px"
                        })
                    }
                    return;
                }
                isIE6 ? (container.removeClass("iefixed").removeClass("static").addClass("fixed"), container.setStyle({
                    left: offsetX + "px"
                })) : container.setStyle({
                    position: 'fixed',
                    top: 30 + 'px',
                    left: offsetX + "px"
                });
            } else {
                isIE6 && (container.removeClass("fixed").removeClass("iefixed").addClass("static"));
                container.setStyle({
                    position: '',
                    top: '',
                    left: ""
                })
            }
        }

        function leftHandler(e) {
            var LEN = opts.items;
            if (INX == 0) { //如果点到了最左边
                INX = Math.ceil(opts.data.length / LEN) * LEN;
            }
            left.onclick = null;
            var index_key = INX + left_key - LEN;
            var tmp = opts.data[index_key];
            list[left_key].style.visibility = tmp ? (list[left_key].innerHTML = (onChange(tmp, index_key)), "visible") : (list[left_key].innerHTML = '', "hidden");
            left_key++;
            if (left_key >= LEN) {
                opts.dataTacker && J.site.trackEvent(opts.dataTacker);
                left.onclick = leftHandler;
                left_key = 0;
                page.html(page.html().replace(/\d+/, function(d) {
                    return Math.ceil(INX / opts.items);
                }))
                INX -= opts.items;
                opts.afterInsert && opts.afterInsert(INX, sendSoj);
                var lis = container.s("li");
                lis.each(function(k, v) {
                    v.s("a").each(function(k, v) {
                        v.on('click', function(e) {
                            if (e && e.stopPropagation) {
                                e.stopPropagation();
                            } else {
                                window.event.cancelable = true;
                            }
                        });
                    })
                });
                return;
            }
            timer = setTimeout(leftHandler, tmp ? 50 : 0);
        }

        function rightHandler(e) {
            var LEN = opts.items;
            var tmpCeil = Math.ceil(opts.data.length / LEN);
            if (Math.ceil((INX + LEN) / LEN) >= tmpCeil) {
                INX = -LEN;
            }
            right.onclick = null;
            var index_key = LEN + INX + right_key;
            var tmp = opts.data[index_key];
            list[right_key].style.visibility = tmp ? (list[right_key].innerHTML = (onChange(tmp, index_key)), "visible") : (list[right_key].innerHTML = '', "hidden");
            right_key--;
            if (right_key < 0) {
                opts.dataTacker && J.site.trackEvent(opts.dataTacker);
                right_key = LEN - 1;
                page.html(page.html().replace(/\d+/, function(d) {
                    return Math.ceil(INX / opts.items) + 2;
                }))
                INX += LEN;
                right.onclick = rightHandler;
                opts.afterInsert && opts.afterInsert(INX, sendSoj);
                var lis = container.s("li");
                lis.each(function(k, v) {
                    v.s("a").each(function(k, v) {
                        v.on('click', function(e) {
                            if (e && e.stopPropagation) {
                                e.stopPropagation();
                            } else {
                                window.event.cancelable = true;
                            }
                        });
                    })
                });
                return;
            }
            timer = setTimeout(rightHandler, tmp ? 50 : 0);
        }

        function sendSoj(sojData) {
            if (sojData.propParam == '') {
                return;
            }
            var st = new J.logger.Tracker("anjuke-npv");
            st.setPage("View_Property_ViewPropRecommend");
            st.setPageName("Anjuke_Hp_View");
            st.setReferrer(document.referrer);
            st.setNGuid("aQQ_ajkguid");
            st.setNUid("ajk_member_id");
            try {
                var userId = J.getCookie("ajk_member_id") || 0;
                var userType = J.getCookie("usertype") || 0;
                var entry = sojData.entry ?  sojData.entry : 2 ;
                var jsonTag = '"entry":"' + entry + '","proids":"' + sojData.propParam + '","tradeType":"1"';
                cp = '{"v":"' + sojData.v + '","hp":"' + sojData.hp + '","hpPage":"Anjuke_Hp_View","channel":"1","userType":"' + userType + '","userid":"' + userId + '",' + jsonTag + '}';
                st.setCustomParam(cp);
                st.track();
            } catch (err) {}
        }

        // function sendSoj(sojData) {
        //     if (sojData.propParam == '') {
        //         return;
        //     }
        //     var st = new SiteTracker("anjuke-npv");
        //     st.setPage("View_Property_ViewPropRecommend");
        //     st.setPageName("Anjuke_Hp_View");
        //     st.setReferer(document.referrer);
        //     st.setNGuid("aQQ_ajkguid");
        //     st.setNUid("ajk_member_id");
        //     try {
        //         var userId = J.getCookie("ajk_member_id") || 0;
        //         var userType = J.getCookie("usertype") || 0;
        //         var entry = sojData.entry ?  sojData.entry : 2 ;
        //         var jsonTag = '"entry":"' + entry + '","proids":"' + sojData.propParam + '","tradeType":"1"';
        //         cp = '{"v":"' + sojData.v + '","hp":"' + sojData.hp + '","hpPage":"Anjuke_Hp_View","channel":"1","userType":"' + userType + '","userid":"' + userId + '",' + jsonTag + '}';
        //         st.setCustomParam(cp);
        //         st.track();
        //     } catch (err) {}
        // }
    }
    J.ui.timerAni = TimerAni;
})();
