<?php
class User_Component_Module_SmallListComponent extends User_Component_AbstractComponent
{

    public function getView()
    {
        $title = $this->get_param('title');
        $this->assign_data('title',$title);
        return 'SmallList';
    }

    public static function use_component()
    {
        return array_merge(
            parent::use_component(), array(
            )
        );
    }

    public static function use_boundable_styles()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "SmallList.css");
    }

    public static function use_boundable_javascripts()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array(
            $path . "SmallList.js"
        );
    }
}

