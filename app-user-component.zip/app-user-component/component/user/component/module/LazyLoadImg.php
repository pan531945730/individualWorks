<?php
apf_require_class('APF_Component');
class User_Component_Module_LazyLoadImgComponent extends APF_Component {
    
    public function get_view () {
        return "";
    }

    public static function use_boundable_javascripts() {
        $path = apf_classname_to_path(__CLASS__);
        return array_merge(
            parent::use_boundable_javascripts(),
            array($path . "LazyLoadImg.js")
        );
    }
}