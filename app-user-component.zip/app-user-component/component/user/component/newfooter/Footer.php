<?php
/**
 * 独立的footer组件，不含内链和友链
 * Class User_Component_Newfooter_FooterComponent
 */
class User_Component_Newfooter_FooterComponent extends User_Component_AbstractComponent
{
    public static function use_boundable_styles()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "Footer.css");
    }
    
    public static function use_component()
    {
        return array();
    }

    public function getView()
    {
        return 'Footer';
    }

}
