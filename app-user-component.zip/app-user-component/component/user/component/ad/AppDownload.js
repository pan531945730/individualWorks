J.ready(function(){
    var app_download_ad = J.g('app_download_ad'),
        close_btn = app_download_ad.s('.app_download_close').eq(0),
        phone_num = app_download_ad.s('.phone_num').eq(0),
        get_btn = app_download_ad.s('.free_get').eq(0),
        code_box = J.g('code_box'),
        re_code = code_box && code_box.s('.re_code_box').eq(0),
        base_url = J.g("app_ad_post_url"),
        //is_re_code = 0,
        is_disable_get = 0;


    J.g('app_ad_user_id').val(J.getCookie('aQQ_ajkguid'));

    app_download_ad.length && app_download_ad.on('click', function(){
        window.open("http://www.anjuke.com/mkt/1409dzp?from= wangzhan5");
    });

    J.g("app_download_info").length && J.g("app_download_info").on('click', function(e){
        e.stop();
    });

    close_btn.length && close_btn.on('click', function(e){
        e.stop();

        J.setCookie(J.getCookie('aQQ_ajkguid'), 1, 7, baseUrl);

        app_download_ad.remove();
        J.site.trackEvent('Track_AppDownload_Click_0');

        /* var url = base_url && base_url.val() + "?r=" + Math.random();
        J.post({
            url: url,
            type: 'json',
            async: false,
            data: {
                flag:1,
                ad_user_id: J.g("app_ad_user_id").val()
            },
            onSuccess: function() {
                app_download_ad.remove();
                J.site.trackEvent('Track_AppDownload_Click_0');
            }
        });*/
    });

    phone_num.length && phone_num.on('focus', function(){
        phone_num.removeClass('border_err');
        phone_num.addClass('border_rig');
    });

    re_code.length && re_code.on('focus', function(){
        phone_num.removeClass('border_err');
        phone_num.addClass('border_rig');
    });

    phone_num.length && phone_num.on('blur', function(){
        var phone_num_value = phone_num.val();

        if(phone_num_value && !testPhoneNum(phone_num_value)){
            /*error*/
            phone_num.removeClass('border_rig');
            phone_num.addClass('border_err');
        }else{
            phone_num.removeClass('border_err');
            phone_num.addClass('border_rig');
        }
    });

    J.s('.re-code-link')[0] && J.s('.re-code-link').eq(0).on('click', function() {
        J.s('.re-code-img').eq(0).attr('src', '/seccode?k=seccode&x=101&y=26&s=24&x1=2&y1=30&x2=12&y2=26&t=' + (new Date().getTime()));
        return false;
    });

    get_btn.length && get_btn.on('click', getApp);

    function getApp(e){
        if(is_disable_get){
            return;
        }

        e.stop();
        J.site.trackEvent('Track_AppDownload_Click_1');

        var url = base_url && base_url.val() + "?r=" + Math.random();
        J.post({
            url: url,
            type: 'json',
            async: true,
            data: {
                flag:3,
                ad_user_id: J.g("app_ad_user_id").val()
            },
            onSuccess: function(rs) {
                // if(!is_re_code && rs.status == -6){//同一个用户 && 点击3次以上>=3
                //     is_re_code = 1;

                //     code_box.setStyle({display:'block'});
                //     J.s('.app_download_content').eq(0) && J.s('.app_download_content').eq(0).setStyle({marginTop:"-18px"});
                // }

                if(!is_disable_get && rs.status == -5){//超过下载次数   ??第6次点击的时候
                    is_disable_get = 1;

                    get_btn.addClass('free_get_disable');
                    phone_num.val('号码超过下载次数');
                    phone_num.addClass('phone_num_disable');
                }
            }
        });


        var phone_num_value = phone_num.val();

        if(!phone_num_value || !testPhoneNum(phone_num_value)){
            //num empty or error
            //phone_num.get().focus();
            phone_num.removeClass('border_rig');
            phone_num.addClass('border_err');
            return;
        }

        // if(is_re_code){

        if(!testEwmCode(re_code.val()) ){
            re_code.removeClass('border_rig');
            re_code.addClass('border_err');
            re_code.get().focus();
            return;
        }else{
            re_code.removeClass('border_err');
            re_code.addClass('border_rig');
        }
        //}

        sendToPhone();
    }


    function testPhoneNum(num){
        var pwdReg = /^1\d{10}$/;
        if (!pwdReg.test(num)) {
            return 0;
        } else {
            return 1;
        }
    }

    function testEwmCode(code){
        var code_reg = /^\d{4}$/;
        if (!code || !code_reg.test(code)) {
            return 0;
        } else {
            return 1;
        }
    }

    function sendToPhone() {
        J.site.trackEvent('Track_AppDownload_Click_2');
        var url = base_url && base_url.val() + "?r=" + Math.random();

        J.post({
            flag: 2,
            url: url,
            type: 'json',
            async: false,
            data: {
                ad_user_id: J.g("app_ad_user_id").val(),
                phone: J.g("phone_num").val(),
                seccode: re_code.val(),
                from_page: J.g("app_ad_from_page").val()
            },
            onSuccess: function(rs) {
                if(rs.status == 1){
                    re_code.removeClass('border_rig');
                    re_code.addClass('border_err');
                    re_code.get().focus();
                    J.g("mess_tip").get().innerHTML = '验证码错误';
                }else if(rs.status == 0){
                    J.g("mess_tip").get().innerHTML = '发送成功';
                }else {
                    J.g("mess_tip").get().innerHTML = '发送失败';
                }
            }
        });
    }

    var funPlaceholder = function(element) {
        var placeholder = '';
        if (element && !("placeholder" in document.createElement("input")) && (placeholder = element.getAttribute("placeholder"))) {
            element.onfocus = function() {
                if (this.value === placeholder) {
                    this.value = "";
                }
                this.style.color = '';
            };
            element.onblur = function() {
                if (this.value === "") {
                    this.value = placeholder;
                    this.style.color = 'graytext';
                }
            };

            //样式初始化
            if (element.value === "") {
                element.value = placeholder;
                element.style.color = 'graytext';
            }
        }
    };

    phone_num && phone_num.length && funPlaceholder(phone_num.get());
    re_code && re_code.length && funPlaceholder(re_code.get());
});
