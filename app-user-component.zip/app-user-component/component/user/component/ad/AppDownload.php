<?php

class User_Component_Ad_AppDownloadComponent extends User_Component_AbstractComponent {
    public function getView() {
        $this->assign_data('ad_user_id',$this->get_param('ad_user_id'));
        $this->assign_data('from',$this->get_param('from'));
        $this->assign_data('ad_posturl',$this->build_url());

        $apf = APF::get_instance();
        $this->assign_data('base_domain',$apf->get_config("base_domain"));
        return "AppDownload";
    }

    public static function use_component()
    {
        return array_merge(
            parent::use_component(), array(
            )
        );
    }

    public static function use_boundable_styles()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "AppDownload.css");
    }

    public static function use_boundable_javascripts()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array(
            $path . "AppDownload.js"
        );
    }

    /**
     * 获取底部广告ajax的post地址
     * @return string
     */
    public static function build_url() {
        $apf = APF::get_instance();
        $base_domain = $apf->get_config("base_domain");
        $request = $apf->get_request();
        $city_set = $request->load_city_set();
        $city_domain = $city_set['pinyin'];
        $schema = $apf->get_request()->is_secure() ? "https" : "http";

        return "{$schema}://{$city_domain}.{$base_domain}/ajax/adappsendtophone/";
    }

}

?>
