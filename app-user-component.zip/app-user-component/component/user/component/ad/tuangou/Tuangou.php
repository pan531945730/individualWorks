<?php

class User_Component_Ad_Tuangou_TuangouComponent extends User_Component_AbstractComponent {

    public function getView() {
        $num = $this->get_param('num');
        $city_id = $this->get_param('city_id');
        $num = is_numeric($num) && $num > 0 ? $num : 5;
        $v = $this->get_param('v');
        $adCode = $this->get_param('adCode');
        $base_url = User_Common_Util_Url_BaseUrl::buildBaseUrl($city_id);
        $url = $base_url.'/ajax/aifang/tuangou/api/?num='.$num.'&cityId='.$city_id.'&adCode='.$adCode;
        $this->assign_data('tuanGouUrl', $url);
        if($v=='v2'){
            return "Tuangou2";
        }else{
            return "Tuangou";
        }
    }

    public static function use_boundable_styles() {
        $path = apf_classname_to_path(__CLASS__);
        return array($path."Tuangou.css");
    }

}
