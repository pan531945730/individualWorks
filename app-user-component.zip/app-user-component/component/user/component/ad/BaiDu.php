<?php
/* 2015.05.11  xianjinshi  */
class User_Component_Ad_BaiDuComponent extends User_Component_AbstractComponent {
    public function getView(){
        return 'BaiDu';
    }
}

