<?php
class User_Component_Ad_mediav_mediavComponent extends User_Component_AbstractComponent {
    //默认的account
    const ERSHOUFANG_ACCOUNT = 8;

    public function getView(){
        return 'mediav';
    }
}

