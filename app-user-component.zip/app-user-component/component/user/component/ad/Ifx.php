<?php
/**
 * ifx的js广告组件，可解决js阻塞问题
 * @author majingyun
 */
class User_Component_Ad_IfxComponent extends User_Component_AbstractComponent {
    public function getView() {
        $adUrl = $this->get_param('adUrl');
        $p = $this->get_param('p');
        $out_tag = $this->get_param('out_tag') ? $this->get_param('out_tag') : 'div';
        $adParams = $this->get_param('adParams');
        $comm_id = $this->get_param('comm_id');
        $from = $this->get_param('from');
        $rn = $this->get_param('rn');//region
        $pa = $this->get_param('pa');
        if(empty($adUrl) || !is_string($adUrl) || empty($p)){
            if(empty($adParams['p']) || empty($adParams['c'])){
                return false;
            }
            $adParams['o'] = isset($adParams['o']) ? $adParams['o'] : 1;
            if($comm_id){
                $adParams['m'] = $comm_id;
            }
            if($from){
                $adParams['f'] = $from;
            }
            if($rn){
                $adParams['rn'] = $rn;
            }
            if($pa){
                $adParams['pa'] = $pa;
            }
            $adBaseUrl = $this->get_param('baseurl');
            $adBaseUrl = $adBaseUrl ? $adBaseUrl :  APF::get_instance()->get_config('aifang_ifx_url','api');
            $adUrl = $adBaseUrl.'s?'.http_build_query($adParams);
            $p = $adParams['p'];
        }
        $this->assign_data('adData',array(
            'adUrl' => $adUrl,
            'p' => $p,
            'class' => $this->get_param('class'),
            'style' => $this->get_param('style'),
            'out_tag' => $out_tag,
            'first' => $adParams['first'],
            'cp' => $adParams['cp'],
            'pagename' => $adParams['pagename'],
        ));
        return "Ifx";
    }
}
?>
