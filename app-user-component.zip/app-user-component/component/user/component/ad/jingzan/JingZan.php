<?php
/* 2014.7.14 18:13 tracyzhou  */
class User_Component_Ad_Jingzan_JingZanComponent extends User_Component_AbstractComponent {
    //默认的account
    const ERSHOUFANG_ACCOUNT = 8;

    public function getView(){
        return 'JingZan';
    }
}

