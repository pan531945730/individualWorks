<?php

abstract class User_Component_Dw_LinkFromComponent extends APF_Component
{

    public static function use_boundable_javascripts()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array($path . "LinkFrom.js");
    }

}