;
(function() {
    var tagSoj = '_soj', tagSpd = '_spd', blockClass = 'system-link-track', blockElements = J.s('.' + blockClass);


    function isExtraCodeLink(target) {
        if (target.tagName === 'A') {
            if (target.getAttribute('href') && (target.getAttribute(tagSoj) || target.getAttribute(tagSpd))) {
                return true;
            }
        }
    }

    /**
     * add extra code
     *
     * @param target
     * example:
     *  link.com#action?param=xxx
     *  link.com?param=xxx#action
     *  link.com?from=xxx
     *  link.com
     *  lnk.com/#hoverlink
     */
    function addExtraCode(target) {
        var url = target.href,
            urlParts = url.split('?'),
            urlPartsLen = urlParts.length,
            paramStr = (urlPartsLen > 1) ? urlParts[1] : url,
            paramParts = paramStr.split('#'),
            connector = (urlPartsLen > 1) ? '&' : '?',
            combineParamStr = combineParams(target),
            queryStr = (combineParamStr) ? connector + combineParamStr : '';

        /**
         * combine params
         * @param target
         * @returns {string} e.g.: "from=soj&spred=spd"
         */
        function combineParams(target){
            var url = target.href,
                sojCode = target.getAttribute(tagSoj),
                spdCode = target.getAttribute(tagSpd),
                regSoj = /[?&]from=/,
                regSpd = /[?&]spread=/,
                params = [];

            // if not exist "from="
            if (! regSoj.test(url) && sojCode) {
                params.push('from=' + encodeURIComponent(sojCode));
            }

            // if not exist "spread="
            if (! regSpd.test(url) && spdCode) {
                params.push('spread=' + encodeURIComponent(spdCode));
            }

            return params.join('&');
        }

        if (urlPartsLen > 1 && paramParts.length > 1) {
            // link.com?param=xxx#action
            target.href = urlParts[0] + '?' + paramParts[0] + queryStr + '#' + paramParts[1];
        } else {
            // link.com#action?param=xxx
            // link.com
            target.href += queryStr;
        }
    }

    function removeExtraCode(target) {
        target.setAttribute(tagSoj, '');//target.removeAttribute(tagSoj);
        target.setAttribute(tagSpd, '');//target.removeAttribute(tagSpd);
    }

    function clickHandle(target) {
        if (isExtraCodeLink(target)) {
            // add extra code dynamic.
            addExtraCode(target);

            // remove extra code
            // removeExtraCode(target);
        }
    }

    J.s('body').on('click', function(e) {
        var target = e.srcElement ? e.srcElement : e.target;//link
        clickHandle(target);
    });

    /* Case for block elements */
    function blockClickHandle(e) {
        var currentTarget = e.currentTarget,
            links = J.s('a', currentTarget),
            regx = new RegExp(blockClass);

        if (! regx.test(currentTarget.className)) {
            return;
        }

        if (links.length) {
            J.each(links, function(idx, target) {
                clickHandle(target[0]);
            });
        }

        // remove class: blockClass
        currentTarget.className = currentTarget.className.replace(blockClass, '');
    }
    J.each(blockElements, function(idx, val) {
        val.on('click', blockClickHandle);
    });

})();
