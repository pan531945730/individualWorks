APF.Namespace.register('ajk');
(function(){
    var logger;
    var siteName = (function(){
        var hostData = document.location.host.match(/^(\w+)\.(\w+)\./);
        if( hostData ){
            return 'pc'
        }else{
            return 'unknown'
        }
    })();

    var rAf = function(callback) {
        window.setTimeout(callback, 1000 / 10);
    };

    ajk.Logger = logger = {
        sojSite:'',
        sojPage:'',
        sojPageName:'',
        errorSite:siteName
    };

    logger.setSite = function(site){
        this.sojSite = site||'';
    }
    logger.setPage = function(page){
        this.sojPage = page||'';
    }
    logger.setPageName = function(pagename){
        this.sojPageName = pagename||'';
    }
    logger.setCtid = function(ctid){
        this.ctid = ctid||'';
    }

    logger.config = {
        devLogURL: '<?php echo APF::get_instance()->get_config("dev_soj_domain","soj");?>/ts.html?',
        logURL: 'http://m.anjuke.com/ts.html?',
        devSojURL: '<?php echo APF::get_instance()->get_config("dev_soj_domain","soj");?>/stb',
        isDev: /dev|test/.test(document.domain),
        blackList: ['Player', 'baiduboxapphomepagetag', 'onTouchMoveInPage']
    };

    logger.isblack = function(str) {
        var self = this;
        var i,
            reg,
            length,
            blackList = self.config.blackList;
        if (typeof str !== 'string') { // 对于非字符串默认黑名单
            return true;
        }
        for (i = 0, length = blackList.length; i < length; i++) {
            reg = new RegExp(blackList[i], 'g');
            if (reg.test(str)) {
                return true;
            }
        };
    }

    logger.sendError = function(params) {
        var self = this;
        var errorinfo = 'tp=error&site='+self.errorSite+'&msg=',
            key,
            url,
            arr = [],
            image,
            msg;
        if (typeof params === 'string') {
            msg = params;
        }
        if (typeof params === 'object') {
            for (key in params) {
                if (params.hasOwnProperty(key)) {
                    arr.push(key + ':' + encodeURIComponent(JSON.stringify(params[key])));
                }
            }
            msg = arr.join(',');
        }
        if (self.isblack(msg)) {
            return false;
        }
        image = new Image();
        if (self.config.isDev) {
            url = self.config.devLogURL + errorinfo + msg;
        } else {
            url = self.config.logURL + errorinfo + msg;
        }
        image.src = url;
        return true;
    }

    var getScreen = function() {
        var sinfo = {};
        sinfo.w = $(window).width().toString();
        sinfo.h = $(window).height().toString();
        sinfo.r = (window.devicePixelRatio&&window.devicePixelRatio >= 2 ? 1 : 0).toString();
        getScreen = function() {
            return sinfo;
        };
        return sinfo;
    };

    logger.sendSoj = function(op) {
        var self = this;
        var _site = op.site || self.sojSite,
            soj = new SiteTracker(),
            t_params;
        if (op.customparam) {
            soj.setCustomParam(op.customparam);
        }
        if (self.config.isDev) {
            t_params = {
                'target_url': self.config.devSojURL
            }
        }
        var _page = op.page || self.sojPage, _ctid = self.ctid,
            _pageName = op.pageName || self.sojPageName || _page;
        soj.setPage(_page);
        soj.setPageName(_pageName);
        soj.setSite(_site);
        soj.setScreen(getScreen());
        soj.setNCtid(_ctid);
        soj.setReferer(op.r||document.referrer);
        if( op.NGuid ){
            soj.setNGuid( op.NGuid );
        }
        if( op.NUid ){
            soj.setNUid( op.NUid );
        }
        if(op.h){
            if(!t_params) t_params = {};
            t_params.h = op.h;
        }
        soj.track(t_params);
        // 58 统计
        try{
            if(!/npv/.test(_site)){
                var trackUrl = soj.getParams();
                delete trackUrl.cp;
                delete trackUrl.sc;
                window._trackURL = JSON.stringify(trackUrl);
                loadTrackjs()
            }
        }catch(e){

        }
        function loadTrackjs(){
             var s = document.createElement('script');
             s.type = 'text/javascript';
             s.async = true;
             s.src = 'http://tracklog.58.com/referrer_anjuke_pc.js?_=' + Math.random();
             var b = document.body;
             s.onload = function () {
                soj.setSite(_site+'-npv');
                soj.setPage(_page+"_tracklog");
                soj.setPageName(_pageName+"_tracklog");
                soj.track(t_params);
             }
             s.onerror = function () {
                soj.setSite(_site+'-npv');
                soj.setPage(_page+"_tracklog_error");
                soj.setPageName(_pageName+"_tracklog_error");
                soj.track(t_params);
             }
             b.appendChild(s);
        }

    }

    logger.addLinkSoj = function(selector, attr, param) {
        $('body').on('click', selector, function(e) {

            var soj = $(this).data(attr || 'soj') || $(this).attr(attr || '_soj'), // 默认使用data，如果取不到，使用attr
                _soj = $.trim(soj), // 去空格
                href = $.trim($(this).attr('href')),
                _param = param || 'from', // 默认是from
                _target = $(this).attr('target'),//兼容各种target
                _hasTarget = _target !== undefined ,
                _href;

            if(!_soj){//如果没获取到soj直接退出让它自己执行自己的href
                return;
            }

            if (!href) { // 此处链接不做合法性检查
                return;
            }
            if (href.toLowerCase().indexOf('javascript') === 0) {
                return;
            }
            //if (!_soj) { // 如果无soj,直接跳转
            //    location.href = href;
            //    return ;
            //}
            e.preventDefault();
            e.stopPropagation();
            href = href.replace(/(&from=(.)*$)|(\?from=(.)*$)/,''); //移除原本url中的from
            _href = (href.indexOf('?') !== -1)? href+'&'+_param+'='+_soj : href+'?'+_param+'='+_soj; //拼接url
            if(_hasTarget){  //是否含有target
               if(!/*@cc_on!@*/0){  //若非ie
                    var winoper = window.open(_href,_target);
                    winoper && winoper.focus();
               }else{
                    var _el = document.createElement('a');
                    _el.href = _href;
                    _el.target = _target;
                    $(_el).appendTo('body').get(0).click();
                    $(_el).remove();
               }
            }else{
               location.href = _href;
            }

        });
    }

    logger.Exposure = function(op) {
        var defaults = {
            site:'',
            trackTag: 'data-trace',
            delay: 50,
            page:'',
            pageName: '',
            NUid:'',
            NGuid:'',
            prefix: ''
        };
        this.ops = $.extend(defaults, op);
        this.domCache = []; // 保存内容
        this.pageViewHeight = $(window).height(); // 页面可视区域高度
        this.timer = null;
        this.dataCache = [];
        this.expStatus = false;
        this.init();
    };
    logger.Exposure.prototype = {
        constructor: logger.Exposure,
        add: function(list) {
            var _this = this;
            this.expStatus = true;
            list.each(function(index, el) {
                _this.domCache.push($(el));
            });
        },
        init: function() {
            var wd = $(window), self = this;
            wd.resize($.proxy(this.resize, this)); // resize
            wd.on('beforeunload', $.proxy(this.beforeunload, this));
            rAf(scroll);
            function scroll(){
                rAf(scroll);
                if (!self.expStatus) {
                    return;
                }
                clearTimeout(self.timer);
                if (self.domCache.length === 0) {
                    self.expStatus = false;
                    self.buildData();
                    return;
                }
                self.timer = setTimeout(function(){
                    $.proxy(self.addData, self)();
                }, self.ops.delay);
            }
        },
        resize: function() {
            this.pageViewHeight = $(window).height();
        },
        beforeunload: function() {
            this.buildData();
        },
        scroll: function() {
        },
        sendExp: function(result) {
            logger.sendSoj({
                'NGuid':this.ops.NGuid,
                'NUid':this.ops.NUid,
                'site':this.ops.site,
                'page':this.ops.prefix + this.ops.page,
                'pageName':this.ops.prefix + this.ops.pageName,
                'customparam':result
            });
        },
        addData: function() {
            var pageViewHeight = this.pageViewHeight,
                topY = $(window).scrollTop(),
                botY = topY + pageViewHeight,
                _this = this;
            if (this.domCache.length === 0) {
                return;
            }
            $.each(this.domCache, function(index, val) {
                var _topY,
                    attr;
                if (!val) {
                    return;
                }
                _topY = val.offset ? val.offset().top : 0;
                if (_topY > topY && _topY < botY) {
                    attr = val.attr(_this.ops.trackTag);
                    if (attr) {
                        _this.dataCache.push(attr);
                    }
                    delete _this.domCache[index];
                }
            });
            this.buildData();
        },
        buildData: function() {
            var _this = this,
                result = {},
                r = [],
                exp,
                key,
                length,
                i;
            /**
             * "{aa:'123'}"
             * 这种格式的数据JSON.parse解析不了，必须用eval才能转成json
             */
            if (this.dataCache.length === 0) { // 如果没有数据就不发送
                return;
            }
            exp = eval('([' + this.dataCache.join(',') + '])');
            this.dataCache = []; // 清除要发送的数据
            for (i = 0, length = exp.length; i < length; i++) {
                for (key in exp[i]) {
                    if (!result[key]) {
                        result[key] = [];
                    }
                    result[key].push(exp[i][key]);
                }
            }
            for (key in result) { // 不考虑兼容pc 此循环可以用JSON.stringify替换
                r.push('"' + key + '"' + ':[' + result[key].join(',') + ']');
            }
            this.sendExp('{"exposure":{' + r.join(',') + '}}');
            $.each(this.domCache, function(index, val) {
                if (!val) {
                    _this.domCache.splice(index, 1); // 删除已统计过的dom
                }
            });
        }
    };

    // 初始化 jserror
    window.onerror = function(msg, url, line) {
        logger.sendError({
            message: msg,
            url: url,
            line: line
        });
    }

    // 初始化 from
    $(function(){
        logger.addLinkSoj('a[_soj]');
    });
})();;