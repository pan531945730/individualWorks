<?php
apf_require_class('APF_DecoratorPage');
abstract class Pc_Layout_LayoutPage extends APF_DecoratorPage
{

    /**
     *
     * @var APF
     */
    protected $apf;

    /**
     *
     * @var APF_Request
     */
    protected $request;

    /**
     *
     * @var APF_Response
     */
    protected $response;

    // 额外的模块
    public function getExtraComponent()
    {
        return array();
    }

    public function execute()
    {
        $this->apf = APF::get_instance();
        $this->request = $this->apf->get_request();
        $this->response = $this->apf->get_response();

        $attributes = $this->request->get_attributes();
        if(! empty($attributes)) {
            foreach($attributes as $key => $value) {
                $this->assign_data($key, $value);
            }
        }
        parent::execute();
    }

    public function get_decorator()
    {
        $path = apf_classname_to_path(__CLASS__);
        return $path.'Layout';
    }

    public function getFooter(){
        return 'Pc_Common_Footer';
    }

    public function getHeader(){
        return 'Pc_Common_Header';
    }

    public static function use_component()
    {
        return array(
            self::getHeader(),
            self::getFooter(),
            'Pc_Common_SideBar'
        );
    }

    public static function use_boundable_javascripts()
    {
        $path = apf_classname_to_path(__CLASS__);
        $js = array(
            array('APF.js', PHP_INT_MAX),
            array($path . "Json2.js" , PHP_INT_MAX-1),
            array($path . "Layout.js" , PHP_INT_MAX-2),
            array($path . "Logger.js" , PHP_INT_MAX-3),
        );
        return $js;
    }

    public static function use_boundable_styles()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array(
            array( $path . "Layout.css" ,PHP_INT_MAX),
            array( $path . "Icon.css" ,PHP_INT_MAX),
        );
    }

    public static function use_javascripts()
    {
        return array(
            array(User_Common_Util_PageHelper::getPureStaticUrl("/js/jquery/1.11.3/jquery-underscore.min.js"),PHP_INT_MAX),
            array(User_Common_Util_PageHelper::getPureStaticUrl("/js/bbv5.js"),PHP_INT_MAX),
        );
    }

    public function getSojPageName()
    {
        return get_class($this);
    }

    public function getSojDomain()
    {
        return APF::get_instance()->get_config("soj_base_domain") ? APF::get_instance()->get_config("soj_base_domain") : "s.anjuke.com";
    }

    /**
     * 发送soj前，设置soj client data相关方法
     * @return null
     */
    protected function get_soj_client_data() {
        return null;
    }

    protected function getSojJsUrl()
    {
        $domain = $this->getSojDomain();
        return "http://" . $domain . "/bb.js";
    }

    protected function getPageName(){
        $pn = User_Common_SojProvider::get_instance()->getPageName();
        return !empty($pn) ? $pn : get_class($this);
    }

    protected function getPageAliasName(){
        $pn = User_Common_SojProvider::get_instance()->getPageAliasName();
        return !empty($pn) ? $pn : get_class($this);
    }


    public function getActivedTab()
    {
        return null;
    }

    public function getWebPerformance() {
        $performanceConfig = APF::get_instance()->get_config("web_performance", 'web_performance');
        $currentClass = get_class($this);
        return $performanceConfig[$currentClass] ? $performanceConfig[$currentClass] : $currentClass;
    }

    /**
     * 显示统计曝光
     * @return bool
     */
    public function showExposure(){
        return false;
    }

    /**
     * PC的meta添加百度坐标
     * @return string
     */
    public function getBaiduMapLocationMetaInfo(){
        $city_id   = $this->request->getCityId();
        $city_maps = APF::get_instance()->get_config('baidu_map_conf', 'multicity');
        $map_info  = $city_maps[$city_id];
        $meta_info = '<meta name="location" content="province=';
        $meta_info.=$map_info['province'].';city='.$map_info['cityname'].';';
        $meta_info.='coord='.$map_info['coord'].'">';

        return array($meta_info);
    }

}