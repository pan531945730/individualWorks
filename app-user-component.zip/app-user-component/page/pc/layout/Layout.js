APF.Namespace.register('ajk');
(function($){
    /**
     * [inherit 方法：使得子构造函数继承父构造函数]
     * @param  {[fn]} [构造函数，最后一个参数为子构造函数，之前均为父构造函数，支持多父类继承]
     * @return {[fn]}             [经过继承之后的新构造函数]
     */
    ajk.inherit = function(){
        var splice = Array.prototype.splice,
            args = arguments;
        var childClass = args[ args.length -1 ];
        splice.apply(args,[-1,1]);

        var newConstructor = function(){
            for( var i=0; i<args.length; i++ ){
                if( args[i] ){
                    args[i].apply(this,arguments);
                }
            }
            childClass.apply(this,arguments);
        }
        for( var i=0; i<args.length; i++ ){
            if( args[i] ){
                $.extend( newConstructor.prototype, args[i].prototype);
            }
        }

        $.extend( newConstructor.prototype, childClass.prototype );
        return newConstructor
    }

    /**
     * [Observer 简单的事件观察的构造函数,每个注册的事件命名空间都是一个只增不减的数组]
     * @return {[对象]}             [包含事件触发、绑定、解除绑定的方法]
     */
    ajk.Observer = function(){
        this.ob = {};
    }

    /**
     * [on 按照事件类型挂载回调函数]
     * @param  {[type]}   eventNames [事件名称，可以多事件以空格分隔]
     * @param  {Function} callback   [回调函数]
     * @return {[type]}              [如果是单一事件则返回当前回调所在事件空间的 key 值，如果是多事件则是一个对象，事件名与key相对应 ]
     */
    ajk.Observer.prototype.on = function(eventNames,callback) {
        var _events = eventNames.split(' ');
        var _eventKeys = {};
        for( var i = 0; i < _events.length; i++ ){
            if( !this.ob[_events[i]] ){
                this.ob[_events[i]] = [];
            }
            var _key = this.ob[_events[i]].push(callback);
            _eventKeys[ _events[i] ] = _key - 1; // push 返回数组长度，key是 现有长度减一。
        }
        return _eventKeys;
    }

    /**
     * [off 解除绑回调函数]
     * @param  {[string]} eventName [事件名]
     * @param  {[array]} keys      [指定回调的 key 组成的数组，key会在绑定函数的时候（on方法）返回]
     * @return {[type]}           [description]
     */
    ajk.Observer.prototype.off = function(eventName,keys){
        if( keys !== undefined && !$.isArray(keys) ){
            keys = [keys]
        }
        for (var i = 0; i < this.ob[eventName].length; i++) {
            if( keys === undefined || $.inArray(i,keys) > -1 ){
                this.ob[eventName][i] = undefined;
            }
        }
    }

    /**
     * [trigger 事件触发]
     * @param  {[type]} eventName [事件名]
     * @param  {[type]} args      [希望传递给回调函数的 数组或arguments对象]
     * @return {[type]}           [description]
     */
    ajk.Observer.prototype.trigger = function(eventName,args){
        var r;
        if( !this.ob[eventName] ){
            return r;
        }
        var _arg = args||[];
        for( var i = 0; this.ob[eventName] && i < this.ob[eventName].length; i++ ){
            if( !this.ob[eventName][i] ){
                continue;
            }
            var _r = this.ob[eventName][i].apply(this, _arg);
            r = (r === false)? r:_r;
        }
        return r
    }

    /**
     * [once 只执行一次行为的绑定方法，事件执行后立即解除绑定]
     * @param  {[string]}   eventName [事件名]
     * @param  {Function} callback  [回调函数]
     * @return {[type]}             [description]
     */
    ajk.Observer.prototype.once = function(eventName,callback){
        var self = this;
        var key = self.on(eventName,function(){
            callback.apply(this,arguments);
            self.off(eventName,key[eventName]);
        });
    }

})(jQuery);

