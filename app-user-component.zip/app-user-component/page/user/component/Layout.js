
String.prototype.Trim=function(){
	return this.replace(/(^\s*)|(\s*$)/g,'');
};
String.prototype.chkType=function(type){
	switch(type){
		case 'int':
			return (/^-?[1-9][0-9]+$|^-?[0-9]$/).test(this);
		case 'url':
			return (/^https?:\/\/([a-z0-9-]+\.)+[a-z0-9]{2,4}.*$/).test(this);
		case 'email':
			return (/^[a-z0-9_+.-]+\@([a-z0-9-]+\.)+[a-z0-9]{2,4}$/i).test(this);
		case 'idcard':
			return (/^[0-9]{15}$|^[0-9]{17}[a-zA-Z0-9]/).test(this);
		case 'area':
			return (/^\d+(\.\d{1,2})?$/).test(this);
		case 'money':
			return (/^\d+(\.\d{1,2})?$/).test(this);
		case 'year':
			return (/^(19|20)\d\d$/).test(this);
		case 'input':
			return (/^[\u4e00-\u9fa5A-Za-z0-9_\s\~\@\!\#\$\.\,\/\\\%\^\&\*\(\)_\+\?\>\<《〉》\:：〉、，。？！￥（）\{\}\[\]]+$/).test(this);
	}
	return false;
};

String.prototype.containType=function(type){
	switch(type){
		case 'mobile':
			return (/[0-9]{11}/).test(this);
	}
	return false;
};
/*全角字符转换成半角字符
 * 2011-11-14 add by xiaohuizhou 
 * */
String.prototype.dbcToSbc=function(){
	var result="";
	for (var i = 0; i < this.length; i++){
		if (this.charCodeAt(i)==12288){
			result+= String.fromCharCode(this.charCodeAt(i)-12256);
			continue;
		}
		if (this.charCodeAt(i)>65280 && this.charCodeAt(i)<65375)
			result += String.fromCharCode(this.charCodeAt(i)-65248);
		else 
			result += String.fromCharCode(this.charCodeAt(i));
	}
	return result;
};
Array.prototype.unique=function(){
	var hash={};
	for( var i=0,j=0;i<this.length;i++){
		if(this[i]!==undefined){
			if(!hash[this[i]]){
				this[j++]=this[i];
				hash[this[i]]=true;
			}
		}
	}
	this.length=j;
	return this;
};
Array.prototype.clone=function(){
	var arr=[];
	for( var p in this){
		if(arr[p]===undefined&&typeof this[p]=='string'){
			arr[p]=this[p];
		}
	}
	return arr;
};
Array.prototype.insertAt=function(index,value){
	var part1=this.slice(0,index);
	var part2=this.slice(index);
	part1.push(value);
	return(part1.concat(part2));
};

//prototype.js(实现了[].each)中去除后，需要加上each的实现
Array.prototype.each = function(callback) {
	if (!this.length) {return;}
	if ([].forEach) {
		[].forEach.call(this,callback);
	} else {
		for (var i = 0; i < this.length; i++) {
			callback.call(this[i], this[i], i);
		}
	}
}

window.openNew=function(p_strURL,p_strName){
	var frmNew=document.createElement('form');
	form.action=p_strURL;
	form.target=p_strName;
	form.submit();
};
window.getRadioValue=function(p_strRadioName){
	var arrRadio=document.getElementsByName(p_strRadioName);
	var intLength=arrRadio.length;
	if(0==intLength){
		return null;
	}
	for( var i=0;i<intLength;++i){
		if(arrRadio[i].checked==true){
			return arrRadio[i].value;
		}
	}
	return '';
};

window.cancelBubble=function(e){
	if(e&&e.stopPropagation){
		e.stopPropagation();
	}else{
		window.event.cancelBubble=true;
	}
	return false;
};
J.ready(function(){

    var lazyLoader = {

        //get single image

        getImg: function (img,tag){
            var url =  img.getAttribute(tag);
            img && tag && url && (img.src = url);
        },

        //get images by dom

        getImgsByDom: function (dom,tag){
            var imgs,
                i,
                len,
                url;
            if(dom && tag){
                imgs = dom.getElementsByTagName('img');
                for(i = 0, len = imgs.length; i < len; i++){
                    this.getImg(imgs[i],tag);
                }
            }

        }
    }

    //百度统计
    function hm(){
        var _hmt = _hmt || [];
        window._hmt = _hmt;
        J.load('//hm.baidu.com/hm.js?c5899c8768ebee272710c9c5f365a6d8');
    }
    //入口函数
    function init(){
        lazyLoader.getImgsByDom(document,'data-src');
        hm(); //百度统计
    }

    init();

});





