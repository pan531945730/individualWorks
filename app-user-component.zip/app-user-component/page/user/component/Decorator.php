<?php
apf_require_class('APF_DecoratorPage');
abstract class User_Component_DecoratorPage extends APF_DecoratorPage
{

    /**
     *
     * @var APF
     */
    protected $apf;

    /**
     *
     * @var APF_Request
     */
    protected $request;

    /**
     *
     * @var APF_Response
     */
    protected $response;

    public function execute()
    {
        $this->apf = APF::get_instance();
        $this->request = $this->apf->get_request();
        $this->response = $this->apf->get_response();

        $attributes = $this->request->get_attributes();
        if(! empty($attributes)) {
            foreach($attributes as $key => $value) {
                $this->assign_data($key, $value);
            }
        }
        parent::execute();
    }

    public function get_decorator()
    {
        return $this->getDecorator();
    }

    abstract protected function getDecorator();

    public function get_view()
    {
        return $this->getView();
    }

    abstract protected function getView();
}