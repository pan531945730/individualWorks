<?php

abstract class User_Component_BlankLayoutPage extends User_Component_DecoratorPage
{

    public function getDecorator()
    {
        $path = apf_classname_to_path(__CLASS__);
        return $path . "BlankLayout";
    }

    public static function use_javascripts()
    {
        return array(
          array(User_Common_Util_PageHelper::getPureStaticUrl("/js/jquery/1.11.3/jquery-underscore.min.js"), PHP_INT_MAX),
          array(User_Common_Util_PageHelper::getPureStaticUrl("/js/jquery/1.11.3/avalon.shim.js"), PHP_INT_MAX-1), 
        );
    }

    public static function use_boundable_javascripts()
    {
        $path = apf_classname_to_path(__CLASS__);
        $js = array(
            array('APF.js', PHP_INT_MAX),
            array($path . "BlankLayout.js" , PHP_INT_MAX-1),
            array($path . "Json2.js" , PHP_INT_MAX-2),
            array($path . "Logger.js" , PHP_INT_MAX-3),
        );
        return $js;
    }
    
    public function get_head_sections()
    {
        $base_sections = array(
            '<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">',
            '<META NAME="format-detection" CONTENT="telephone=no" />',
        );

        $bool_need_baidu_location = $this->request->get_attribute('need_baidu_baiyang_location'); // 关闭百度地图位置
        if ($bool_need_baidu_location) {
            $base_sections = array_merge($base_sections, $this->getBaiduMapLocationMetaInfo());
        }

        $tw_meta = $this->request->get_attribute('tw_meta');
        if($tw_meta){
            $base_sections[] = '<meta name="mobile-agent" content="format=html5; url='.$tw_meta.'" />';
        }
        return array_merge(
            $base_sections, parent::get_head_sections()
        );
    }


    public function getSojPageName()
    {
        return get_class($this);
    }

    public function getSojDomain()
    {
        return APF::get_instance()->get_config("soj_base_domain") ? APF::get_instance()->get_config("soj_base_domain") : "s.anjuke.com";
    }

    /**
     * 发送soj前，设置soj client data相关方法
     * @return null
     */
    protected function get_soj_client_data() {
        return null;
    }

    protected function getSojJsUrl()
    {
        $domain = $this->getSojDomain();
        return "http://" . $domain . "/bb.js";
    }

    protected function getPageName(){
        $pn = User_Common_SojProvider::get_instance()->getPageName();
        return !empty($pn) ? $pn : get_class($this);
    }

    protected function getPageAliasName(){
        $pn = User_Common_SojProvider::get_instance()->getPageAliasName();
        return !empty($pn) ? $pn : get_class($this);
    }


    public function getActivedTab()
    {
        return null;
    }

    /**
     * 显示统计曝光
     * @return bool
     */
    public function showExposure(){
        return false;
    }

    /**
     * PC的meta添加百度坐标
     * @return string
     */
    public function getBaiduMapLocationMetaInfo(){
        $city_id   = $this->request->getCityId();
        $city_maps = APF::get_instance()->get_config('baidu_map_conf', 'multicity');
        $map_info  = $city_maps[$city_id];
        $meta_info = '<meta name="location" content="province=';
        $meta_info.=$map_info['province'].';city='.$map_info['cityname'].';';
        $meta_info.='coord='.$map_info['coord'].'">';

        return array($meta_info);
    }

    public static function use_component()
    {
        return array(
            'User_Component_Soj_JockjsSiteTracker'
        );
    }

    public static function use_boundable_styles()
    {
        $path = apf_classname_to_path(__CLASS__);
        return array(
            array($path . "BlankLayout.css", PHP_INT_MAX - 1)
        );
    }
}
